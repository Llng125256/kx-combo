#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""K线导演·复刻监控（自研引擎 + 模拟持仓，纯文本状态页）

【v1.7.19 2026-10-13 01:3x 发版】D-Audit v1.0 审计处置（用户拍板）：①硬顶 60→30 天回撤（扛单指纹双期坐实）②下影40%保留（邻域局部最优）③EMA10 保留不改（EMA8/ATR14 预注册 2026-11 复验）④CCI≤−175 深度标签降级为纯展示（全年 54.5% 弱于主信号 58.3%，「最强子集」未复现；是否改 −150 待终审）⑤死区 0.3×ATR 预注册事件驱动路径回放补审计 ⑥周线趋势赋能正式关闭 ⑦30-60天龄陈旧信号将随硬顶回撤从页面/账本消失（账本统计口径变化如实记录）。
  【v1.7.18 2026-10-12 21:5x 发版】更新频率改版（用户拍板）：定时轮 4→6 轮/天（00:35/04:35/08:35/12:35/16:35/20:35，每4小时，08:35保留为权威定版轮），页面头部文案同步；引擎逻辑/破位判定/离场判定零改动，纯时点与文案变更。
  【v1.7.17 2026-10-12 20:5x 发版】模拟仓占位案（交易分析团队 bull 26 vs bear 50，裁决 B 维持同标不重叠）：展示语义修复三项——①模拟仓卡 note 改仓位自描述（开仓日/现浮/止损），废除引用其他信号建议的错位写法 ②同标跳过事实可见化（N次/最近日期/有牌k次，账本 skip_detail 上送渲染）③新信号卡交叉标注「已有模拟仓，仅在册展示不入账」。账本规则零改动。
  【v1.7.16 2026-10-12 20:3x 发版】用户要求周日信号醒目化：卡片标签位新增大红色「🚫周日·降权0.5·复评中」标注（#ff3b30，独立 span，不占用⚠️破位/有效止损等文本），文本页信号行同步加前缀；澄清：周日裁决为「降权0.5+预注册复评」非「禁止买入」，若用户拍板升格禁买另行裁决。合成场景 26/26（新增 T3 sun_half 旗标、T4b 红标与破位⚠️并存）。
  【v1.7.15 2026-10-12 发版】用户 LRCX 截图质疑 + 交易分析团队裁决（多头 27 分 vs 空头 47 分，研究主管裁定）：
  ①周六新信号下册——展示与模拟账本均不再收周六(UTC)生成的信号（全池回测 n=100 双口径全面负期望：+5日 42%/−1.04%、引擎退出 26.4%/−1.32%；
    10-10 批量日周一 11/12 破位卡集中于周六=「批量日加成依赖工作日机构接力资金」的机理反例）。
    硬性回归项：周五及更早信号的破位/到站状态机照常消费周六日 K 线（合成场景 T1 验证）。
  ②周日信号降权 0.5 + 卡片标注「周日信号·权重0.5·复评中」（n=26 不足以定罪亦不足满权）。
    预注册复评规则：引擎退出口径样本 n≥60 或满一季度（先到者）期望仍负→自动下册不再辩论；期望转正→恢复权重 1.0。
  ③展示层对齐：信号卡新增「有效止损」= 止损 − 0.3×ATR（隐藏死区透明化；LRCX 10-08 收盘跌破显示止损但在死区内 4 天未认定的口径差修复）。
  ④文案如实化：「止损纪律优先」→「确认破位·2日观察期（0.3×ATR 容差+收盘确认，收上信号区上沿即复活）」。
  ⑤口径提示：自本版起周六历史候选不入页面账本与展示（独立回测数据通道不受影响）；全池 12 张破位观察卡零漏检复核——机制未丢破位，纯透明性问题。
  【v1.7.14 2026-10-12 待发】模拟账本收复参考线由死锚价(EMA10+ATR)改为信号区上沿(EMA10-ATR)，与展示机统一（用户质疑+研究主管裁决+三变体回测：C 均值+2.38%/PF1.64 vs A +1.58%/1.46；代价=真破位离场更深-7.57% vs -5.57%，最差单笔相同-32.1%可接受；加严变体(连续2日收复)+1.92%/1.54 备选未采纳）。复活重定级进账本（裁决④）需盘中改仓逻辑与独立回测，留待下一批。⑥HTML信号卡note补入信号自带备注（数日企稳确认/收复恢复等，此前只显示引擎建议——17:35首跑验收时发现的展示缺口）。⑦禁入卡沉底展示+备注保留破位观察信息+带观察卡标签亮⚠️（用户截图 KORU 指出：无牌信号带⚠️时被排到最前且信息被禁入文案覆盖，双 bug）。
  【v1.7.13 2026-10-12 待发（等技术团队审查）】①haos反向加权：强共振实测唯一亏损子集(PF0.90,n=175)
  却持1.2倍加成，改强×0.80/弱×0.90/无·超买×1.00 ②展示重构：金银铜→主信号(下影>40%)/深度标签(CCI≤-175)，
  仅深CCI组(+2.01%)经双口径回测证实为A口径副产品，标签仅展示 ③破位口径统一：模拟账本止损与展示机一致
  （容忍1次+2天观察+收复信号区上沿复活），旧「1次即离场」回测证伪（胜率38.1%→47.4% 均值+1.20%→+1.56%），
  观察期出场747笔全部为首破后2天未收复，二次确认0笔 ④G路径(启明星/跨K线确认)：瘫脚触轨后3日内企稳阳柱
  （中间仅十字星/小实体）正式成信号，止损=确认日最低，n=1191 均值+1.44% PF1.41 ⑤_simulate 共用推演函数
  提取（回归29只零漂移）。
  【v1.7.12 2026-10-12】牌级架构重构（用户拍板+金融团队裁决+全池回测验证）：①硬顶 30→60 天（均值+0.76%→+0.94%，PF1.19→1.23，让🏁离场机制接管时间砍仓）②🥈下影阈值 50%→40%（n+255，均值+1.43% vs +1.33%，四档平坦低过拟合）③🥇CCI阈值 -150→-175（修口径后-175最优PF1.23；-250均值转负，钻石档方向证伪）④🥉（10日跌>10%）剔除——全表垫底PF1.09~1.21⑤新成员制=下影>40%（主信号）或 CCI≤-175（深度标签），仅深CCI组实测最强子集(+1.99%/PF1.52)；动态升降级（触轨后3日最深定级）回测三项全弱于静态版，否决封存。全部基于2025-06-01+真实数据窗口、干净口径（剔>8%止损+资金费+同标不重叠）。
  【v1.7.11 2026-10-12】热修：卡片页横幅胜率格式错误（笔数误格式化为百分比显示 900%），改为 win/n_closed 口径与文本页一致。
  【v1.7.10 2026-10-12】热修：purge 清单补入 status/view.html——v1.7.9 暴露 view.html 从不刷缓存、用户最长看 12h 旧页的交付缺陷（一行修复）。
  【v1.7.9 2026-10-12】view.html 升级为卡片版 UI（丁导K线交易系统，用户定稿）：信号卡与模拟仓卡同款字段（锚/止损/死锚出场/距止损/仓位/杠杆/信号区/日期/现浮），CCI 不再上页面（引擎逻辑零改动，仅渲染层）；文本页四文件口径不变。
  【v1.7.0 2026-10-11】推荐即模拟持仓（专家团联合设计，用户拍板）：
  · 评分排序 = 分级分 × 当日层分 × 威廉环境分（全部实测值映射）
      分级 🥇2.0/🥈1.6/·1.1（v1.7.12起无🥉）；层 批量1.5/常规1.0/孤星禁入；环境 强1.2/弱1.0/🥈弱0.8
  · 档位决策表（v1.7.12起无🥉）：🥇批量=重/中仓，🥈批量=中/轻，🥇常规/🥈常规=轻，
    孤星一律禁入，无牌禁入（样本<30的格子按最差邻近处理）
  · 仓位：重10%/中6%/轻3% 名义；杠杆=风险预算÷(名义×止损距离)，封顶5×；
    风险预算 重1.0%/中0.6%/轻0.3%；止损距离<1.5%按1.5%计，>8%放弃信号
  · 止损=死区下沿+收盘确认（5规则回测帕累托最优：+1.35%，2×ATR方案-10.7%被否）
  · ✅走默认留例外（留须斜率>0+收盘>EMA10+量比>0.8）；✅后连续2日站稳EMA10→止损上移保本
  · 优先级 ⚠️>🏁>✅>30天硬顶；每轮重算只输出单一当前建议，旧建议自动隐藏
  · 【金融团队审计 2026-10-11】①模拟仓确认失败离场（到站后2日确认中收盘≤EMA10→当日平，
    命名「✅确认失败离场」，比设计默认走更早锁盈属保守化）②⚠️破位三确认≥1回填设计
    ③展示「⚠️观察中」时若模拟仓已离场→标注「模拟仓已按风控口径离场」④免责补两句
  ⑤模拟账户<100笔标注「样本不足，不构成有效性证据」
  · 行业分散：name括号解析→因果链归组，同大类≤2只/≤20%，同大类同日新开≤1只；
    解析失败进「未分类」桶同受约束；宽基ETF单列不计行业但计总敞口
  · 熔断：总敞口≤50%、单票≤15%、同日新开≤3只
  · 模拟盘=规则化全量模拟（每条合格信号必开仓、全约束），无幸存者偏差；
    资金费按0.01%/8h粗扣；跌穿止损按实际收盘记亏不美化
  · 市况横幅置顶：孤星日明示「今日不适合抄底」
  【破位口径（v1.7.13 统一）】模拟仓止损已与展示破位机统一：容忍 1 次确认破位
  （2 天观察 + 收复信号区上沿复活），观察期满或再次确认破位才离场。旧口径（1 次即离场）经
  回测证伪（胜率 38.1%→47.4%、均值 +1.20%→+1.56%、中位 −2.34%→−0.40%），历史分歧废弃。
  两处逻辑仍需同步检查。
  【v1.6】卖出并入买入行：✅死锚到站 / 🏁EMA10离场线 / ⚡威廉环境 / 终局驱动展示
  【v1.2】破位/收复状态机：容差0.3×ATR+三确认（爆量/瘫脚/CCI）
  【v1.0】Lucy=肯特纳双轨触及；🥇CCI<-150+收盘位>0.3（样本外验证：仅近期市场状态有效）
  公式搜索结论（2026-10-11）：8候选企稳公式无一通过替换及格线，CCI守位。
"""
from __future__ import annotations

import base64
import logging
import os
import sys
import time
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

import requests
import html
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kx_client import KxClient  # noqa: E402

__version__ = "1.7.19"
GH_API = "https://api.github.com/repos/Llng125256/kx-combo/contents"
FRESH_DAYS = 15
HARD_CAP = 30            # 信号/模拟仓硬顶（天）——v1.7.19 回撤（D-Audit v1.0 扛单指纹双期坐实：30天窗 60.8%/+1.74% vs 60天窗 52.5%/+0.25%，30-60天龄陈旧信号为负贡献；用户拍板 2026-10-13）
FLAG_LINGER = 5
WORKERS = 16
BARS = 150
MAX_LEV = 5.0            # 杠杆封顶
STOP_FAR = 0.08          # 止损距离>8%放弃信号
STOP_NEAR = 0.015        # 止损距离<1.5%按1.5%计
TIERS = {'重仓': (10.0, 1.0), '中仓': (6.0, 0.6), '轻仓': (3.0, 0.3)}  # 名义%, 风险预算%
CAP_TOTAL = 50.0         # 总敞口%
CAP_SECTOR = 20.0        # 单行业敞口%
CAP_SECTOR_N = 2         # 同行业最多仓位数
CAP_DAY_NEW = 3          # 同日新开
CAP_SECTOR_DAY = 1       # 同行业同日新开
FUND_FEE_DAY = 0.0003    # 资金费 0.01%/8h ≈ 0.03%/天（名义占比）

SECTOR_KEYS = [
    ('宽基', ('ETF', '指数', '基金')),
    ('AI科技', ('半导体', '芯片', '光模块', 'AI', '算力', '数据中心', '云计算', '软件', '信息技术', '电子设计', '网络', '互联网')),
    ('汽车', ('汽车', '电动车', '整车', '自动驾驶')),
    ('医疗健康', ('医药', '生物', '医疗', '健康', '制药', '疗法', '诊断', '基因')),
    ('能源', ('石油', '天然气', '油气', '能源', '煤炭', '铀', '核能', '电力', '太阳能', '光伏', '新能源', '油田')),
    ('金融', ('银行', '保险', '证券', '金融', '支付', '交易所', '资管', '信贷')),
    ('消费', ('零售', '餐饮', '食品', '饮料', '咖啡', '服装', '消费', '家居', '电商', '旅游', '酒店', '度假', '博彩', '体育', '鞋', '啤酒', '美容', '化妆品', '宠物')),
    ('工业防务', ('航空', '航天', '国防', '军工', '防务', '机械', '制造', '工程', '建筑', '运输', '物流', '铁路', '卡车', '航运')),
    ('通信', ('电信', '通信', '运营商', '电话')),
    ('原材料', ('矿业', '稀土', '化工', '钢铁', '材料', '化肥', '造纸', '黄金', '白银', '铜', '铝')),
    ('媒体娱乐', ('媒体', '传媒', '影视', '流媒体', '游戏', '音乐', '视频', '娱乐')),
    ('房地产', ('房地产', '地产', 'REIT', '物业')),
]


def sector_of(name: str) -> str:
    """name 字段因果链归组：宽基最优先 → 关键词匹配 → 未分类。"""
    if not name:
        return '未分类'
    if 'ETF' in name or '指数' in name or '基金' in name:
        return '宽基'
    inner = name[name.find('（')+1:name.find('）')] if '（' in name and '）' in name else name
    text = inner + name
    for bucket, keys in SECTOR_KEYS:
        if bucket == '宽基':
            continue
        for kw in keys:
            if kw in text:
                return bucket
    return '未分类'


def ema(x, n):
    a = 2/(n+1); out = np.full(len(x), np.nan); out[0] = x[0]
    for i in range(1, len(x)): out[i] = a*x[i] + (1-a)*out[i-1]
    return out


def ema_nan(x, n):
    a = 2.0/(n+1)
    out = np.full(len(x), np.nan)
    idx = np.where(~np.isnan(x))[0]
    if len(idx) == 0: return out
    s = idx[0]; out[s] = x[s]
    for i in range(s+1, len(x)): out[i] = a*x[i] + (1-a)*out[i-1]
    return out


def wpr(high, low, close, n):
    hh = np.full(len(close), np.nan); ll = np.full(len(close), np.nan)
    for i in range(n-1, len(close)):
        hh[i] = high[i-n+1:i+1].max(); ll[i] = low[i-n+1:i+1].min()
    rng = hh - ll
    out = np.where(rng == 0, -50.0, (hh-close)/np.where(rng == 0, 1, rng)*-100.0)
    out[:n-1] = np.nan
    return out


def t3(x, n, v):
    e1 = ema_nan(x, n); e2 = ema_nan(e1, n); e3 = ema_nan(e2, n)
    e4 = ema_nan(e3, n); e5 = ema_nan(e4, n); e6 = ema_nan(e5, n)
    return (-v**3)*e6 + (3*v**2+3*v**3)*e5 + (-6*v**2-3*v-3*v**3)*e4 + (1+3*v+v**3+3*v**2)*e3


def haos_tag(high, low, close, fresh_days=FRESH_DAYS):
    """⚡强共振=双线当前≤-90；弱共振=仅慢线且进入≤15天。"""
    if len(close) < 120: return ''
    f = t3(wpr(high, low, close, 14), 3, 0.7)
    s = t3(wpr(high, low, close, 96), 3, 0.7)
    if np.isnan(f[-1]) or np.isnan(s[-1]): return ''
    if f[-1] <= -90 and s[-1] <= -90:
        return ' ⚡强共振'
    if s[-1] <= -90:
        j = len(close) - 1
        while j > 0 and not np.isnan(s[j-1]) and s[j-1] <= -90: j -= 1
        if (len(close)-1) - j <= fresh_days:
            return ' ⚡弱共振'
    return ''


def haos_tag_ob(high, low, close):
    """⚡超买共振：双线当前≥-10（止盈环境提醒）。"""
    if len(close) < 120: return ''
    f = t3(wpr(high, low, close, 14), 3, 0.7)
    s = t3(wpr(high, low, close, 96), 3, 0.7)
    if np.isnan(f[-1]) or np.isnan(s[-1]): return ''
    if f[-1] >= -10 and s[-1] >= -10:
        return ' ⚡超买共振'
    return ''



def _simulate(high, low, close, vol, ema10, atr, cci, n, dates, i0, ei, stop, dead, anchor, rec_ref=None):
    """持仓推演（v1.7.13 抽取为共用函数，逻辑与原内联逐字一致）:
    破位=统一容忍口径(1次确认破位进入2天观察, 收复复活[v1.7.14参考线=信号区上沿,与展示机一致], 观察期满/再破离场) >
    到站三条件 > 保本 > 🏁趋势终结 > 硬顶(HARD_CAP, 自信号日 i0 起算)。
    返回 (exit_day, exit_px, reason)。"""
    rec_line = dead if rec_ref is None else rec_ref   # v1.7.14: 收复参考线
    exit_day, exit_px, reason = None, None, '在仓'
    hold, pend, cnt2 = False, 0, 0
    st_j, brk_j = 'live', None
    for j in range(ei, n):
        if np.isnan(atr[j]) or np.isnan(cci[j]): continue
        pen = stop - close[j]
        if pen > 0.3*atr[j]:
            rng_j = high[j]-low[j]+1e-9
            cp_j = (close[j]-low[j])/rng_j
            vr_j = vol[j]/(vol[max(0, j-10):j].mean()+1e-9)
            if (vr_j > 3.0) + (cp_j < 0.3) + (cci[j] < -100) >= 1:
                if st_j in ('live', 'recovered'):
                    st_j, brk_j = 'broken', j
        if st_j == 'broken' and close[j] > rec_line:
            st_j = 'recovered'          # 收复信号区上沿=复活(v1.7.14)
        if st_j == 'broken' and (j - brk_j) > 2:
            exit_day, exit_px, reason = j, close[j], '⚠️破位止损'
            break
        if st_j == 'broken':
            continue    # 审查/Tessa修复: 观察期内破位优先级最高, 不评估到站/保本/🏁
        if not hold and high[j] >= dead:
            if pend == 0:
                slope_ok = (ema10[j]+atr[j]) > (ema10[j-1]+atr[j-1])
                ema_ok = close[j] > ema10[j]
                vr_ok = vol[j]/(vol[max(0, j-10):j].mean()+1e-9) > 0.8
                if not (slope_ok and ema_ok and vr_ok):
                    exit_day, exit_px, reason = j, close[j], '✅到站止盈'
                    break
                pend = 1          # 三条件过，进入连续2日站稳确认
                continue
            else:
                if close[j] > ema10[j]:
                    pend += 1
                    if pend >= 3:  # 到站日 + 2日确认
                        hold = True
                    continue
                else:
                    exit_day, exit_px, reason = j, close[j], '✅确认失败离场'
                    break
        if hold:
            if close[j] < anchor:
                exit_day, exit_px, reason = j, close[j], '保本离场'
                break
            cnt2 = cnt2+1 if close[j] < ema10[j] else 0
            if cnt2 >= 2:
                exit_day, exit_px, reason = j, close[j], '🏁趋势终结'
                break
        if j - i0 >= HARD_CAP:
            exit_day, exit_px, reason = j, close[j], '硬顶'
            break
    return exit_day, exit_px, reason



def _sig_post(sig, high, low, close, openp, vol, atr, cci, ema10, n, dates,
              d_i, lo_i, hi_i, dead_px):
    """展示层信号后处理（v1.7.13 自原内联块提取，普通触轨与 G 路径共用）:
    破位/收复状态机(容忍1次+2天观察+收复信号区上沿复活) > ✅死锚标记 > 🏁趋势终结(FLAG_LINGER 出清)。
    d_i=信号日下标; lo_i=止损线; hi_i=收复参考线(信号区上沿); dead_px=死锚出场价。
    返回 True=保留, False=出清。"""
    state, breaks, brk_j, rec_j = 'live', 0, None, None
    killed = False
    for j in range(d_i+1, n):
        if np.isnan(atr[j]) or np.isnan(cci[j]): continue
        back = close[j] > hi_i
        pen = lo_i - close[j]
        if state == 'broken' and back:
            state, rec_j = 'recovered', j
            continue
        if pen <= 0.3*atr[j]: continue
        rng_j = high[j]-low[j]+1e-9
        cp_j = (close[j]-low[j])/rng_j
        vr_j = vol[j]/(vol[max(0, j-10):j].mean()+1e-9)
        conf = sum([vr_j > 3.0, cp_j < 0.3, cci[j] < -100])
        if conf >= 1 and state != 'broken':
            breaks += 1
            if breaks >= 2:
                killed = True; break
            state, brk_j = 'broken', j
    if killed: return False
    if state == 'broken':
        if (n-1) - brk_j > 2: return False
        sig['warn'] = (sig['warn'] + f' ⚠️破位{dates[brk_j][5:]}观察中').strip()
    elif state == 'recovered':
        rng_r = high[rec_j]-low[rec_j]+1e-9
        sh_r = (np.minimum(close[rec_j], openp[rec_j])-low[rec_j])/rng_r
        g2 = ('🥇' if cci[rec_j] <= -175 else
              '🥈' if sh_r > 0.4 else '·')
        if g2 == '·': return False
        sig['grade'] = g2
        sig['cci'] = cci[rec_j]
        sig['main'] = sh_r > 0.4           # 审查#3: 标签随恢复定级同步
        sig['deep'] = cci[rec_j] <= -175
        sig['note'] = f"（{dates[rec_j][5:]}已收复，恢复{g2}）"
        if _is_sun(sig['day']):    # v1.7.15: 复活分支保留周日降权标注
            sig['note'] = '周日信号·权重0.5·复评中｜' + sig['note']
    sig['dead_px'] = round(float(dead_px), 2)
    dead_j = None
    for j in range(d_i+1, n):
        if high[j] >= dead_px:
            dead_j = j; break
    flag_j = None
    if dead_j is not None:
        sig['dead'] = f" ✅行程已走完({dates[dead_j][5:]})"
        cnt = 0
        for j in range(dead_j+1, n):
            cnt = cnt+1 if close[j] < ema10[j] else 0
            if cnt >= 2:
                flag_j = j
                sig['flag'] = f" 🏁趋势终结({dates[j][5:]})"
                break
    if flag_j is not None and (n-1) - flag_j > FLAG_LINGER:
        return False    # 🏁回看期满 → 出清
    return True


def analyse(sym, bars, now_day):
    """单标的：返回 (最新展示信号|None, 候选列表, 信号日集合, last_close)。

    候选 = HARD_CAP(60) 天窗口内每个合格触及事件 + 单标的全生命周期推演
    （⚠️破位止损 > ✅走默认留例外 > 保本/🏁 > 30天硬顶；组合级约束由 main 叠加）。
    """
    if len(bars) < 40:
        return None, [], set(), 0.0, set()
    dates = [str(b['time'])[:10] for b in bars]
    high = np.array([float(b['high']) for b in bars])
    low = np.array([float(b['low']) for b in bars])
    close = np.array([float(b['close']) for b in bars])
    openp = np.array([float(b['open']) for b in bars])
    vol = np.array([float(b.get('volume') or 0) for b in bars])
    n = len(bars)
    ema10 = ema(close, 10)
    tr = np.maximum(high[1:], close[:-1]) - np.minimum(low[1:], close[:-1])
    tr = np.concatenate([[high[0]-low[0]], tr])
    atr = np.full(n, np.nan)
    for i in range(14, n): atr[i] = tr[i-14:i].mean()
    tp = (high+low+close)/3
    cci = np.full(n, np.nan)
    for i in range(19, n):
        w = tp[i-19:i+1]; m = w.mean(); cci[i] = (tp[i]-m)/(0.015*np.abs(w-m).mean()+1e-9)
    hard = n - HARD_CAP
    f_t3 = t3(wpr(high, low, close, 14), 3, 0.7)
    s_t3 = t3(wpr(high, low, close, 96), 3, 0.7)

    def env_at(i):
        if np.isnan(f_t3[i]) or np.isnan(s_t3[i]): return '无'
        if f_t3[i] <= -90 and s_t3[i] <= -90: return '强'
        if s_t3[i] <= -90: return '弱'
        if f_t3[i] >= -10 and s_t3[i] >= -10: return '超买'
        return '无'

    sigs = []
    candidates = []
    touch_days = set()
    last = -99
    for i in range(20, n-1):
        if np.isnan(ema10[i]) or np.isnan(atr[i]) or np.isnan(cci[i]): continue
        if not (low[i] <= ema10[i]-atr[i]) or i - last <= 2: continue
        rng_i = high[i]-low[i]+1e-9
        cp_i = (close[i]-low[i])/rng_i
        if cp_i <= 0.3:
            # v1.7.13 G路径(启明星/跨K线确认): 瘫脚触轨后3日内出现企稳阳柱
            # (中间仅十字星/小实体), 信号日=确认日j, 锚=确认日次日开盘, 止损=确认日最低。
            # 回测 n=1191 均值+1.44% PF1.41（主信号 n=1601 +2.16% PF1.70）。
            # 审查修复#1: G 触发时设 last(触轨去重)、受 hard 窗口约束、确认日计入 touch_days。
            for j in range(i+1, min(i+4, n-1)):
                body_j = abs(close[j]-openp[j])/(high[j]-low[j]+1e-9)
                cpj = (close[j]-low[j])/(high[j]-low[j]+1e-9)
                if close[j] > openp[j] and cpj > 0.3 and not np.isnan(cci[j]):
                    last = i                    # G 触发同计触轨去重（同一次下跌只记一次）
                    if i < hard: break          # 超窗触轨不产 G 信号（与普通路径一致）
                    touch_days.add(dates[j])    # 确认日=真实买入触发日, 计入孤星/批量统计
                    if _is_sat(dates[j]): break    # v1.7.15: 周六新信号下册（市况统计仍计入）
                    g_g = '🥇' if cci[i] <= -175 else '🥈'
                    anchor_j = float(openp[j+1])
                    stop_j = float(low[j])
                    dead_j = float(ema10[i]+atr[i])
                    engul = close[j] > openp[i]
                    sig_g = {'day': dates[j], 'side': 'buy', 'grade': g_g,
                             'main': True, 'deep': bool(cci[i] <= -175),
                             'anchor': anchor_j, 'zone': f"[{low[i]:.2f}~{ema10[i]-atr[i]:.2f}]",
                             'cci': float(cci[i]), 'warn': '',
                             'note': '（数日企稳确认' + ('+吞没' if engul else '') + '）',
                             'haos': haos_tag(high, low, close) + haos_tag_ob(high, low, close),
                             'env': env_at(j), 'stop': stop_j}
                    sig_g['stop_eff'] = round(float(stop_j - 0.3*atr[j]), 2)    # v1.7.15
                    if _is_sun(dates[j]):
                        sig_g['note'] = ('周日信号·权重0.5·复评中｜' + sig_g['note']).strip('｜')    # v1.7.15
                        sig_g['sun_half'] = True    # v1.7.15
                    # 审查修复#2: G 信号与普通信号同走展示后处理（破位状态机+✅+🏁出清）
                    if _sig_post(sig_g, high, low, close, openp, vol, atr, cci, ema10, n, dates,
                                 j, stop_j, ema10[i]-atr[i], dead_j):
                        sigs.append(sig_g)
                    sd_j = max(0.015, (anchor_j-stop_j)/anchor_j)
                    if sd_j <= 0.08:
                        ed, ep, rs = _simulate(high, low, close, vol, ema10, atr, cci, n, dates,
                                               i0=j, ei=j+1, stop=stop_j, dead=dead_j, anchor=anchor_j,
                                               rec_ref=ema10[i]-atr[i])
                        candidates.append({'day': dates[j], 'grade': g_g, 'env': env_at(j),
                                           'anchor': anchor_j, 'stop': stop_j, 'stop_dist': sd_j,
                                           'idx': j, 'n': n, 'src': 'G',
                                           'exit_day': ed,
                                           'exit_date': dates[ed] if ed is not None else None,
                                           'exit_px': ep, 'reason': rs,
                                           'ret': (ep/anchor_j-1)*100 if ed is not None else None})
                    break
                elif body_j <= 0.3:
                    continue          # 十字星/小实体过渡, 允许
                else:
                    break             # 大实体非企稳 = 下跌中继, 放弃
            continue
        last = i
        if i < hard: continue
        touch_days.add(dates[i])
        if _is_sat(dates[i]): continue    # v1.7.15: 周六新信号下册（市况统计仍计入）
        rng = high[i]-low[i]+1e-9
        cp = (close[i]-low[i])/rng
        shadow = (np.minimum(close[i], openp[i])-low[i])/rng
        vr = vol[i]/(vol[max(0, i-10):i].mean()+1e-9)
        drop = (close[i]/close[max(0, i-10)]-1)*100
        c = cci[i]
        grade = ('🥇' if c <= -175 else
                 '🥈' if shadow > 0.4 else '·')   # v1.7.12 镜像新阈值
        is_main, is_deep = shadow > 0.4, c <= -175
        lo_i, hi_i = low[i], ema10[i]-atr[i]
        anchor = openp[i+1]
        sig = {'day': dates[i], 'side': 'buy', 'grade': grade, 'main': is_main, 'deep': is_deep, 'anchor': anchor,
               'zone': f"[{lo_i:.2f}~{hi_i:.2f}]", 'cci': c,
               'warn': '', 'note': '', 'haos': haos_tag(high, low, close) + haos_tag_ob(high, low, close),
               'env': env_at(i), 'stop': lo_i}
        sig['stop_eff'] = round(float(lo_i - 0.3*atr[i]), 2)    # v1.7.15: 有效止损=止损−0.3×ATR（死区透明化）
        if _is_sun(dates[i]):
            sig['note'] = ('周日信号·权重0.5·复评中｜' + sig['note']).strip('｜')    # v1.7.15
            sig['sun_half'] = True    # v1.7.15: 红色标注旗标（卡片标签位）

        if not _sig_post(sig, high, low, close, openp, vol, atr, cci, ema10, n, dates,
                         i, lo_i, hi_i, ema10[i]+atr[i]):
            continue    # 破位观察期满/二次确认/🏁回看期满 → 出清
        sigs.append(sig)
    sigs.sort(key=lambda s: s['day'], reverse=True)

    # ---- 候选（模拟仓推演，单标的无约束口径）----
    last_c = -99
    for i in range(20, n-1):
        if np.isnan(ema10[i]) or np.isnan(atr[i]) or np.isnan(cci[i]): continue
        if not (low[i] <= ema10[i]-atr[i]) or i - last_c <= 2: continue
        rng = high[i]-low[i]+1e-9
        cp = (close[i]-low[i])/rng
        if cp <= 0.3: continue
        last_c = i
        if i < hard: continue
        if _is_sat(dates[i]): continue    # v1.7.15: 周六新信号不入账本
        shadow = (np.minimum(close[i], openp[i])-low[i])/rng
        drop = (close[i]/close[max(0, i-10)]-1)*100
        grade = ('🥇' if cci[i] <= -175 else
                 '🥈' if shadow > 0.4 else '·')   # v1.7.12: 主信号=下影>40%，深度标签=CCI≤-175，🥉剔除
        anchor = openp[i+1]
        stop = low[i]
        stop_dist = max(STOP_NEAR, (anchor-stop)/anchor)
        cand = {'day': dates[i], 'grade': grade, 'env': env_at(i), 'anchor': anchor,
                'stop': stop, 'stop_dist': stop_dist, 'idx': i, 'n': n, 'src': '触轨'}
        # 生命周期推演（统一容忍口径：⚠️首破观察2天+收复信号区上沿复活，观察期满/再破离场；✅默认走须三条件+连续2日站稳确认）
        exit_day, exit_px, reason = _simulate(
            high, low, close, vol, ema10, atr, cci, n, dates,
            i0=i, ei=i+1, stop=low[i], dead=ema10[i]+atr[i], anchor=anchor,
            rec_ref=ema10[i]-atr[i])
        if exit_day is not None:
            cand.update({'exit_day': exit_day, 'exit_date': dates[exit_day],
                         'exit_px': exit_px, 'reason': reason,
                         'ret': (exit_px/anchor-1)*100})
        else:
            cand.update({'exit_day': None, 'exit_date': None, 'exit_px': None,
                         'reason': '在仓', 'ret': None})
        candidates.append(cand)
    latest = sigs[0] if sigs else None
    return latest, candidates, touch_days, close[-1], set(dates)


def push_summary(lines, webhook, snap_name):
    """企微精简推送（可选，默认关闭）：只推头部+模拟账户+在仓前5+⚠️/🏁行，不推全文。

    目的：jsDelivr 对固定文件名 purge 按路径限流（实测 throttlingReset≈598s），
    页面无法保证分钟级新鲜；推送走企微直达，不受任何 CDN 缓存影响。
    """
    head = lines[:6]
    acct = [l for l in lines if l.startswith('💼')][:1]
    pos = [l for l in lines if l.strip().startswith('▶')][:5]
    alert = [l for l in lines if ('⚠️破位' in l or '🏁' in l or '⛔' in l)][:5]
    body = "\n".join(head + ([""] + acct if acct else []) + (["", "▶ 在仓(前5):"] + pos if pos else [])
                     + (["", "⚡ 需处理:"] + alert if alert else ["", "（无⚠️/🏁告警）"])
                     + ["", f"完整页面: status/{snap_name}（带时间戳，永不缓存）"])
    try:
        r = requests.post(webhook, json={"msgtype": "text", "text": {"content": body[:3800]}},
                          timeout=15)
        print(f"[replica] 企微推送: {'OK' if r.status_code == 200 else f'HTTP {r.status_code}'}")
    except Exception as e:
        print(f"[replica] 企微推送异常: {e}")


def tier_of(grade, lay, env):
    """档位决策表（专家定稿）：重仓/中仓/轻仓/禁入。"""
    if lay == '孤星':
        return '禁入'
    if grade == '🥇':
        if lay == '批量':
            return '重仓' if env == '强' else '中仓'
        return '轻仓'
    if grade == '🥈':
        if lay == '批量':
            return '中仓' if env == '强' else '轻仓'
        return '轻仓'
    return '禁入'


def score_of(grade, lay, env, day=None):
    g = {'🥇': 2.0, '🥈': 1.6}.get(grade, 1.1)
    l = 1.5 if lay == '批量' else 1.0
    if day is not None and _is_sun(day):
        l *= 0.5    # v1.7.15: 周日信号降权 0.5（预注册复评：n≥60 或满一季度仍负→自动下册）
    e = {'强': 0.80, '弱': 0.90}.get(env, 1.00)
    return round(g*l*e, 2)



def _wd(dstr):
    """UTC 日期串 -> weekday()（0=周一..5=周六, 6=周日）。"""
    import datetime as _dt
    return _dt.date(int(dstr[:4]), int(dstr[5:7]), int(dstr[8:10])).weekday()


def _is_sat(dstr):
    return _wd(dstr) == 5


def _is_sun(dstr):
    return _wd(dstr) == 6


def esc(s):
    return html.escape(str(s))


def tag_of(x):
    """v1.7.13: 主信号(下影>40%) / 深度标签(CCI≤-175) 展示标签"""
    t = []
    if x.get('main'): t.append('主信号')
    if x.get('deep'): t.append('深度标签')
    return '+'.join(t) if t else '—'


def render_html(rows, closes, open_pos, st):
    """卡片版 view.html（v1.7.9，丁导K线交易系统）。
    信号卡与模拟仓卡同款字段；纯渲染层，判定逻辑与文本页完全同源。
    v1.7.17: 模拟仓卡 note 改为仓位自描述+同标跳过事实可见化；信号卡交叉标注占位事实。"""
    open_map = {p['sym']: p['day'] for p in open_pos}    # v1.7.17
    skip_map = st.get('skip_by_sym') or {}               # v1.7.17
    G_COLOR = {'🥇': '#f5c542', '🥈': '#c0c7d1', '🥉': '#cd8b52', '·': '#8b93a1'}
    E_COLOR = {'强': '#6ea8ff', '弱': '#9aa4ff', '超买': '#ff9f43'}

    def zone_s(x):
        z = x.get('zone')
        if isinstance(z, (list, tuple)):
            return f"[{z[0]:.2f}~{z[1]:.2f}]" if len(z) == 2 else '~'.join(str(v) for v in z)
        return str(z) if z else '—'

    def dead_s(x):
        v = x.get('dead_px')
        return f"{v:.2f}" if isinstance(v, (int, float)) else '—'

    def advice_of(x, cd):
        if x.get('flag'): return '🏁离场：触发离场线，按纪律出局'
        if x.get('warn'):
            a = '⚠️确认破位·2日观察期：止损含0.3×ATR容差（见有效止损），收盘收上信号区上沿即复活，期满未收复或再破即离场'
            if cd and cd.get('reason') == '⚠️破位止损': a += '（模拟仓已按风控口径离场）'
            return a
        if x.get('dead'): return '✅已到站：默认走；趋势健在则留并上移止损至锚价'
        return '持有中，等 ✅/🏁/⚠️'

    def card(g, sym, env, live, score, anchor, stop, dead, sd, tier, pct, lev, zone, day, note, tag='—', stop_eff='—', red_tag=''):
        gc = G_COLOR.get(g, G_COLOR['·'])
        env_html = f'<span class="env" style="color:{E_COLOR.get(env, "")}">⚡{env}共振</span>' if env else ''
        live_cls = 'grn' if (live or 0) >= 0 else 'red'
        return f'''<div class="card">
  <div class="card-h"><span class="tag" style="color:{gc}">{tag}</span>{f'<span class="tag" style="color:#ff3b30">{red_tag}</span>' if red_tag else ''}
    <b>{esc(sym)}</b> {env_html}
    <span class="live {live_cls}">{live:+.1f}%</span>
    <span class="score">评分 {score}</span></div>
  <div class="grid">
    <div><i>锚 Entry</i><em>{anchor}</em></div>
    <div><i>止损 Stop</i><em class="red">{stop}</em></div>
    <div><i>有效止损</i><em class="red">{stop_eff}</em></div>
    <div><i>死锚出场</i><em class="grn">{dead}</em></div>
    <div><i>距止损</i><em class="red">-{sd}%</em></div>
    <div><i>仓位</i><em class="grn">{tier} {pct}%</em></div>
    <div><i>杠杆</i><em class="grn">{lev}x</em></div>
    <div><i>信号区 Zone</i><em class="sm">{esc(zone)}</em></div>
    <div><i>{day[0]}</i><em>{day[1]}</em></div>
  </div>
  <div class="note">{esc(note)}</div>
</div>'''

    sig_cards = []
    jin_cards = []   # v1.7.14: 禁入卡沉底展示（用户拍板：无仓位建议的卡不占前排）
    for _, sym, x, cd, lay, tier, score in rows:
        lc = closes.get(sym, 0)
        live = (lc / x['anchor'] - 1) * 100 if lc and x['anchor'] else 0.0
        anchor_s = f"{x['anchor']:.2f}" if x['anchor'] < 1000 else f"{x['anchor']:.1f}"
        se = f"{x['stop_eff']:.2f}" if isinstance(x.get('stop_eff'), (int, float)) else '—'    # v1.7.15 有效止损
        rt = '🚫周日·降权0.5·复评中' if x.get('sun_half') else ''    # v1.7.15: 红色标注（标签位，不占用破位等文本）
        tag_d = ('⚠️' if x.get('warn') else '') + tag_of(x)   # 破位观察的卡在标签上直 visibly 亮 ⚠️
        if tier == '禁入':
            note = f"禁入（{x['grade']}|{lay}）{x.get('warn', '')}"   # 保留破位观察信息，不再覆盖
            jin_cards.append(card(x['grade'], sym, x.get('env', ''), live, score,
                                  anchor_s, f"{x['stop']:.2f}", dead_s(x), '—',
                                  '—', '—', '—', zone_s(x), ('信号日', x['day']), note, tag_d, stop_eff=se, red_tag=rt))
            continue
        if cd is None:
            sig_cards.append(card(x['grade'], sym, x.get('env', ''), live, score,
                                  anchor_s, f"{x['stop']:.2f}", dead_s(x), '—',
                                  tier, '—', '—', zone_s(x), ('信号日', x['day']), '（数据不足）', tag_d, stop_eff=se, red_tag=rt))
            continue
        base, risk = TIERS.get(tier, (3.0, 0.3))
        stop_dist = max(STOP_NEAR, (cd['anchor'] - cd['stop']) / cd['anchor'])
        if stop_dist > STOP_FAR:
            sig_cards.append(card(x['grade'], sym, x.get('env', ''), live, score,
                                  anchor_s, f"{cd['stop']:.2f}", dead_s(x), f"{stop_dist*100:.1f}",
                                  tier, '—', '—', zone_s(x), ('信号日', x['day']),
                                  f"⛔止损距离过宽({stop_dist:.1%})，放弃该信号", tag_d, stop_eff=se, red_tag=rt))
            continue
        notional = round(min(base, risk / stop_dist), 1)
        lev = round(max(1.0, min(MAX_LEV, risk / (notional * stop_dist))), 1)
        if _is_sun(x['day']):    # v1.7.15: 周日降权——HTML卡建议名义同步减半（与文本页/账本一致）
            notional = round(notional * 0.5, 1)
            lev = round(max(1.0, min(MAX_LEV, risk / (notional * stop_dist))), 1)
        _cross = ''
        if sym in open_map:    # v1.7.17: 同标已有模拟仓——占位事实交叉标注
            _cross = f"｜该标的已有模拟仓（{open_map[sym]}开），本信号仅在册展示，按同标不重叠不入账"
        sig_cards.append(card(x['grade'], sym, x.get('env', ''), live, score,
                              anchor_s, f"{cd['stop']:.2f}", dead_s(x), f"{stop_dist*100:.1f}",
                              tier, f"{notional:g}", f"{lev:g}", zone_s(x), ('信号日', x['day']),
                              advice_of(x, cd) + esc(x.get('note', '')) + _cross, tag_d, stop_eff=se, red_tag=rt))

    sig_by_sym = {sym: x for _, sym, x, _, _, _, _ in rows}
    sim_cards = []
    for p in sorted(open_pos, key=lambda q: -q['score']):
        x = sig_by_sym.get(p['sym'])
        g = x['grade'] if x else '·'
        env = x.get('env', '') if x else ''
        zone = zone_s(x) if x else '—'
        dead = dead_s(x) if x else '—'
        sd = f"{abs((p['stop']/p['anchor']-1))*100:.1f}" if p['anchor'] else '—'
        # v1.7.17: 旧仓卡只描述仓位自身状态，不引用任何其他信号的建议
        note = f"模拟口径管理中：{p['day']} 开 · 现浮 {p['live_ret']:+.1f}% · 止损 {p['stop']:.2f}"
        sk = skip_map.get(p['sym'])
        if sk:
            note += f"｜同标新触轨 {sk['n']} 次（最近 {sk['last'][5:]}）已按同标不重叠跳过，其中有牌 {sk['graded']} 次"
        se_s = f"{x['stop_eff']:.2f}" if x and isinstance(x.get('stop_eff'), (int, float)) else '—'
        rt_s = '🚫周日·降权0.5·复评中' if x and x.get('sun_half') else ''
        sim_cards.append(card(g, p['sym'], env, p['live_ret'], p['score'],
                              f"{p['anchor']:.2f}", f"{p['stop']:.2f}", dead, sd,
                              p['tier'], f"{p['notional']:g}", f"{p['lev']:g}", zone,
                              ('开仓日', p['day']), note, (tag_of(x) if x else '—'), stop_eff=se_s, red_tag=rt_s))

    sample_note = '' if st['n_closed'] >= 100 else '（样本不足，&lt;100笔不构成有效性证据）'
    banner = f'''<div class="banner"><b>丁导K线交易系统</b><br>
自研引擎 v{st["ver"]} · {esc(st["up_ts"])} 北京时间更新（每天 00:35/04:35/08:35/12:35/16:35/20:35 点更新，此时间变了=发版正常）<br>
{esc(st["market_banner"])} ｜ 扫描 {st["pool_n"]} 标的 · 在册 {st["hit_n"]} · 深度标签 {st["g1"]} · ⚠️ {st["warn"]}<br>
模拟仓: 在仓 {st["n_open"]} / 已平 {st["n_closed"]} ｜ 已平 {st["n_closed"]} 笔 · 胜率 {(st["win"]/st["n_closed"] if st["n_closed"] else 0):.0%} · 单笔均值 {st["avg"]:+.3f}% · 累计 {st["cum"]:+.2f}%（含资金费）{sample_note}<br>
页面读法：⚡环境好 → 主信号对 → ✅到了可走可拿 → 🏁亮了挪仓 → ⚠️亮了=确认破位·2日观察中 ｜ 约束：总敞口≤50% · 单票≤15% · 同日≤3只 · 同行业≤2只 · 孤星日禁入 · 周六信号不入册<br>
📌 每标的仅显示日期最新的一条信号；被顶掉信号的历史持仓收益已计入模拟账本</div>'''

    sim_html = chr(10).join(sim_cards)
    sig_html = chr(10).join(sig_cards + jin_cards)   # 禁入卡沉底
    return f'''<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>丁导K线交易系统</title>
<style>
*{{box-sizing:border-box}}body{{margin:0;background:#0e1117;color:#dbe2ee;
font:15px/1.5 -apple-system,'PingFang SC','Microsoft YaHei',sans-serif;padding:14px}}
.wrap{{max-width:640px;margin:0 auto}}
.banner{{background:#171c26;border:1px solid #232a38;border-radius:12px;padding:14px 16px;
margin-bottom:14px;font-size:13px;color:#7c869c;line-height:1.9}}
.banner b{{color:#dbe2ee;font-size:17px}}
h2{{font-size:16px;margin:20px 0 10px}}
.grid2{{display:grid;grid-template-columns:1fr;gap:14px}}
.card{{background:#171c26;border:1px solid #232a38;border-radius:12px;padding:14px 16px}}
.card-h{{display:flex;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap}}
.tag{{font-size:14px;font-weight:700;border:1px solid #2b3446;border-radius:6px;padding:1px 6px}}.card-h b{{font-size:18px}}
.score{{margin-left:auto;color:#f5c542;font-size:14px;font-weight:700}}
.live{{font-size:16px;font-weight:800}}
.env{{font-size:13px;font-weight:600}}
.grid{{display:grid;grid-template-columns:repeat(4,1fr);gap:8px 10px}}
.grid i{{display:block;font-style:normal;color:#7c869c;font-size:12px}}
.grid em{{font-style:normal;font-weight:700;font-size:15px}}
.grn{{color:#2ecc71}}.red{{color:#e74c3c}}.sm{{font-size:13px}}
.note{{margin-top:10px;color:#7c869c;font-size:13px;border-top:1px dashed #232a38;padding-top:8px}}
</style></head><body><div class="wrap">
{banner}
<h2>💼 模拟账户（在仓 {st["n_open"]}）</h2><div class="grid2">{sim_html}</div>
<h2>📋 在册信号（{len(sig_cards)}）</h2><div class="grid2">{sig_html}</div>
<p class="note">⚠️ 以上为历史统计规则输出，非投资建议；仓位与杠杆自定，极端行情下任何止损价都可能被跳空击穿。模拟成交假设 T+1 开盘价、无滑点与流动性约束；展示口径与模拟口径不同，模拟仓更保守。</p>
</div></body></html>'''

def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    print(f"[replica] 包代码版本 v{__version__}")
    tok = os.environ.get("KX_GH_TOKEN", "")
    cli = KxClient(signal_age_days=16, timeout=30, retries=3, retry_delay=2.0)
    items = cli.get_signals('futures', '1d', 1, 500).get('items') or []
    names = {it['symbol']: (it.get('name') or '') for it in items
             if (it.get('underlying_type') or '') == 'EQUITY' and it.get('symbol')}
    pool = sorted(names)

    def one(sym):
        try:
            d = cli.get_kline(sym, 'futures', '1d', BARS)
            sig, cands, tdays, lc, dset = analyse(sym, d.get('bars') or [], None)
            return sym, sig, cands, tdays, lc, dset
        except Exception:
            return sym, 'ERR', [], set(), 0, set()

    with ThreadPoolExecutor(WORKERS) as ex:
        results = list(ex.map(one, pool))

    now_day = datetime.now(timezone.utc).strftime('%Y-%m-%d')
    day_trig = Counter()
    sym_cands, sigs, closes = {}, {}, {}
    calendar = set()
    for sym, sig, cands, tdays, lc, dset in results:
        if sig == 'ERR': continue
        sigs[sym] = sig
        sym_cands[sym] = cands
        closes[sym] = lc
        calendar |= dset
        for d in tdays: day_trig[d] += 1
    cal = sorted(calendar)
    pool_n = max(1, len(pool))

    def layer_prev(dstr):
        """T-1 自然交易日触发数→层（日历化，零触发日=孤星；归一化：孤星<1.5%池，批量>8%池）。"""
        import bisect
        k = bisect.bisect_left(cal, dstr)
        if k <= 0: return '常规'
        cnt = day_trig.get(cal[k-1], 0)
        if cnt < 0.015*pool_n: return '孤星'
        if cnt > 0.08*pool_n: return '批量'
        return '常规'

    def lay_of_latest():
        """今日市况 = 最近一个已收盘交易日的 T-1。"""
        import bisect
        k = bisect.bisect_left(cal, now_day)
        if k == 0: return '常规'
        ref = cal[k-1] if (k < len(cal) and cal[k] == now_day) else cal[-1]
        k2 = cal.index(ref)
        if k2 <= 0: return '常规'
        cnt = day_trig.get(cal[k2-1], 0)
        if cnt < 0.015*pool_n: return '孤星'
        if cnt > 0.08*pool_n: return '批量'
        return '常规'

    # ---- 组合级模拟（时间序 sweep + 熔断 + 行业分散）----
    # 持仓自开仓日起占用名义额度，直到 exit_date（含）后下一候选日起释放——
    # 保证总敞口/行业敞口在持仓重叠期真实生效（技术评审 #1 修复）。
    active, closed = [], []
    skip_n = Counter()
    skip_detail = {}    # v1.7.17: sym -> [(day, grade), ...] 同标不重叠跳过明细
    sector_state = {}
    day_new = Counter()
    cands_all = []
    for sym, cands in sym_cands.items():
        for cd in cands:
            cd['sym'] = sym
            cd['sector'] = sector_of(names.get(sym, ''))
            cands_all.append(cd)
    cands_all.sort(key=lambda x: (x['day'], x['sym'], 1 if x.get('src') == 'G' else 0))   # 决胜键: 同日同标普通信号优先于G

    def sweep(day):
        """回收 exit_date<=day 的在仓仓位（当日收盘已平，次日额度释放）。"""
        for p in active[:]:
            if p['exit_date'] and p['exit_date'] <= day:
                b = p['sector']
                if b != '宽基':
                    sector_state[b][0] -= 1
                    sector_state[b][1] -= p['notional']
                active.remove(p)

    for cd in cands_all:
        sweep(cd['day'])
        sym = cd['sym']
        if any(p['sym'] == sym for p in active):
            skip_n['已有持仓'] += 1
            skip_detail.setdefault(sym, []).append((cd['day'], cd['grade']))    # v1.7.17: 跳过事实可见化
            continue
        lay = layer_prev(cd['day'])
        tier = tier_of(cd['grade'], lay, cd['env'])
        if tier == '禁入':
            skip_n['禁入'] += 1; continue
        if cd['stop_dist'] > STOP_FAR:
            skip_n['止损过宽'] += 1; continue
        base, risk = TIERS[tier]
        notional = round(min(base, risk/cd['stop_dist']), 1)
        lev = round(max(1.0, min(MAX_LEV, risk/(notional*cd['stop_dist']))), 1)
        if _is_sun(cd['day']):    # v1.7.15: 周日降权——名义减半（杠杆上限不变）
            notional = round(notional*0.5, 1)
            lev = round(max(1.0, min(MAX_LEV, risk/(notional*cd['stop_dist']))), 1)
        used = sum(p['notional'] for p in active)
        if used + notional > CAP_TOTAL:
            skip_n['总敞口满'] += 1; continue
        if day_new[cd['day']] >= CAP_DAY_NEW:
            skip_n['当日限额'] += 1; continue
        b = cd['sector']
        if b != '宽基':
            cnt_b = sum(1 for p in active if p['sector'] == b)
            not_b = sum(p['notional'] for p in active if p['sector'] == b)
            if cnt_b >= CAP_SECTOR_N or not_b + notional > CAP_SECTOR:
                skip_n[f'{b}限额'] += 1; continue
            if day_new[(cd['day'], b)] >= CAP_SECTOR_DAY:
                skip_n[f'{b}当日限额'] += 1; continue
        pos = {'sym': sym, 'day': cd['day'], 'anchor': cd['anchor'], 'tier': tier,
               'notional': notional, 'lev': lev, 'stop': cd['stop'], 'sector': b,
               'score': score_of(cd['grade'], lay, cd['env'], cd['day']),
               'exit_date': cd.get('exit_date'), 'exit_px': cd.get('exit_px'),
               'exit_idx': cd.get('exit_day'),
               'reason': cd.get('reason'), 'ret': cd.get('ret'),
               'open_idx': cd['idx'], 'n': cd['n']}
        active.append(pos)
        day_new[cd['day']] += 1
        if b != '宽基':
            day_new[(cd['day'], b)] += 1
        # 平仓结算：推演已定退出日的，按当时价格入账（占用已由 sweep 释放）
        if pos['exit_date'] is not None:
            days_held = max(1, (pos['exit_idx'] or pos['open_idx']) - pos['open_idx'])
            pos['pnl'] = (pos['ret'] or 0)*notional/100 - notional*FUND_FEE_DAY*days_held
            pos['days_held'] = days_held
            closed.append(pos)
            active.remove(pos)
    # 数据末端仍未退出的 = 真在仓
    open_pos = [p for p in active if p['exit_date'] is None]
    for p in open_pos:
        lc = closes.get(p['sym'], 0)
        p['live_ret'] = (lc/p['anchor']-1)*100 if lc and p['anchor'] else 0.0

    realized = [p['pnl'] for p in closed]
    win = sum(1 for x in realized if x > 0)
    cum = sum(realized)

    # ---- 展示 ----
    hit = {s: v for s, v in sigs.items() if v}
    g1 = sum(1 for v in hit.values() if v['grade'] == '🥇')
    warn = sum(1 for v in hit.values() if v['warn'])
    rank = {'⚠️': 0, '🥇': 1, '🥈': 2, '🥉': 3, '·': 9}
    rows = []
    for sym in sorted(hit):
        x = hit[sym]
        if x['grade'] == '·' and not x['warn']: continue
        cands = sym_cands.get(sym) or []
        cd = next((cc for cc in cands if cc['day'] == x['day']), None)
        lay = layer_prev(x['day'])
        tier = tier_of(x['grade'], lay, x['env'])
        score = score_of(x['grade'], lay, x['env'], x['day'])
        rows.append((rank.get('⚠️' if x['warn'] else x['grade'], 9), sym, x, cd, lay, tier, score))
    rows.sort(key=lambda r: (r[0], r[1]))

    tz8 = timezone(timedelta(hours=8))
    up_ts = datetime.now(tz8).strftime('%Y-%m-%d %H:%M')
    today_lay = lay_of_latest()
    banner = {'孤星': '⛔ 今日孤星市况·不适合抄底，仅观察，勿开新仓',
              '批量': '🟢 今日批量出清市况·β修复窗口，优选评分最高者',
              '常规': '市况：常规日，按评分与档位正常筛选'}[today_lay]

    lines = [f"【K线复刻监控 · 自研引擎 v{__version__}】{now_day} (UTC)",
             f"⏱️ 本次更新: {up_ts} 北京时间（每天 00:35/04:35/08:35/12:35/16:35/20:35 点更新，此时间变了=发版正常）",
             banner,
             f"扫描 {len(pool)} 标的 | 在册 {len(hit)} | 深度标签 {g1} | ⚠️ {warn} | 模拟仓: 在仓 {len(open_pos)} / 已平 {len(closed)}",
             "页面读法：⚡环境好 → 主信号对 → ✅到了可走可拿 → 🏁亮了挪仓 → ⚠️亮了=确认破位·2日观察中",
             "约束：总敞口≤50% | 单票≤15% | 同日≤3只 | 同行业≤2只 | 孤星日禁入 | 周六信号不入册",
             "📌 每标的仅显示日期最新的一条信号；被顶掉信号的历史持仓收益已计入下方模拟账本",
             "=" * 46]
    if closed:
        sample_note = '' if len(closed) >= 100 else '（样本不足，<100笔不构成有效性证据）'
        lines.append(f"💼 模拟账户（规则化全量模拟，无幸存者偏差）: 已平 {len(closed)} 笔 | "
                     f"胜率 {win/len(closed):.0%} | 单笔均值 {np.mean(realized):+.3f}% | 累计 {cum:+.2f}%（含资金费）{sample_note}")
    else:
        lines.append("💼 模拟账户：暂无已平仓位（合格信号出现后自动开仓跟踪）")
    for p in sorted(open_pos, key=lambda x: -x['score']):
        lines.append(f"  ▶ 在仓 {p['sym']} {p['tier']} {p['notional']}% {p['lev']}x 锚{p['anchor']:.2f} "
                     f"止损{p['stop']:.2f} 开仓{p['day'][5:]} 现浮 {p['live_ret']:+.1f}%")
    lines.append("=" * 46)
    for _, sym, x, cd, lay, tier, score in rows:
        price_s = f"{x['anchor']:.2f}" if x['anchor'] < 1000 else f"{x['anchor']:.1f}"
        lines.append(f"{('🚫周日·降权0.5·复评中 ' if x.get('sun_half') else '')}{('⚠️' if x['warn'] else tag_of(x))} {sym} 买入 {x['day']} 锚{price_s} "
                     f"支撑阻力区{x['zone']} 有效止损{x.get('stop_eff', '—')} CCI{x['cci']:.0f}{x['warn']}{x.get('note', '')}{x.get('haos', '')}"
                     f"{x.get('dead', '')}{x.get('flag', '')}")
        if tier == '禁入':
            lines.append(f"   └ 评分{score} {lay}日 禁入（{x['grade']}|{lay} 不满足开仓条件）")
            continue
        if cd is None:
            lines.append(f"   └ 评分{score} {lay}日 {tier}（数据不足）")
            continue
        base, risk = TIERS.get(tier, (3.0, 0.3))
        stop_dist = max(STOP_NEAR, (cd['anchor']-cd['stop'])/cd['anchor'])
        if stop_dist > STOP_FAR:
            lines.append(f"   └ 评分{score} {lay}日 ⛔止损距离过宽({stop_dist:.1%})，放弃该信号")
            continue
        notional = round(min(base, risk/stop_dist), 1)
        lev = round(max(1.0, min(MAX_LEV, risk/(notional*stop_dist))), 1)
        if _is_sun(x['day']):    # v1.7.15: 周日降权——建议名义同步减半
            notional = round(notional*0.5, 1)
            lev = round(max(1.0, min(MAX_LEV, risk/(notional*stop_dist))), 1)
        if x.get('flag'): advice = '🏁离场：触发离场线，按纪律出局'
        elif x.get('warn'):
            advice = '⚠️确认破位·2日观察期：止损含0.3×ATR容差（见有效止损），收盘收上信号区上沿即复活，期满未收复或再破即离场'
            if cd and cd.get('reason') == '⚠️破位止损':
                advice += '（模拟仓已按风控口径离场）'
        elif x.get('dead'): advice = '✅已到站：默认走；趋势健在则留并上移止损至锚价'
        else: advice = '持有中，等 ✅/🏁/⚠️'
        lines.append(f"   └ 评分{score} {lay}日 {tier} {notional}% {lev}x | "
                     f"止损{cd['stop']:.2f}(收盘确认,距锚{stop_dist:.1%}) | {advice}")
    if not rows:
        lines.append("（当前无在册信号）")
    lines.append(f"拦截统计: " + " ".join(f"{k}{v}" for k, v in skip_n.most_common()) if skip_n else "")
    text = "\n".join(lines) + "\n"
    text += ("\n⚠️ 以上为历史统计规则输出，非投资建议；仓位与杠杆自定，极端行情下任何止损价都可能被跳空击穿。\n"
             "⚠️ 模拟成交假设 T+1 开盘价、无滑点与流动性约束；破位统一容忍口径（首破观察2天，收复信号区上沿=复活）；展示与模拟同口径(v1.7.14)。\n")
    print(f"[replica] {now_day} 状态页生成: {len(hit)} 标的 / {len(rows)} 推荐 / {len(text.encode())//1024}KB")

    # ---- v1.7.9 卡片版 view.html（渲染层，判定与文本页同源）----
    html_text = render_html(rows, closes, open_pos, {
        'ver': __version__, 'up_ts': up_ts, 'market_banner': banner,
        'pool_n': len(pool), 'hit_n': len(hit), 'g1': g1, 'warn': warn,
        'n_open': len(open_pos), 'n_closed': len(closed),
        'win': win if closed else 0, 'avg': float(np.mean(realized)) if realized else 0.0,
        'cum': cum,
        'skip_by_sym': {k: {'n': len(v), 'last': max(d for d, _ in v),
                            'graded': sum(1 for _, g in v if g in ('🥇', '🥈'))}
                        for k, v in skip_detail.items()}})    # v1.7.17
    print(f"[replica] view.html 卡片版生成: {len(rows)} 信号卡 / {len(open_pos)} 模拟仓卡 / {len(html_text.encode())//1024}KB")

    if tok:
        hdr = {"Authorization": f"Bearer {tok}"}
        hhmm = datetime.now(tz8).strftime('%m%d-%H%M')
        for fname in (f"status/daily-{hhmm}.txt", "status/view.html", "status/latest.txt", "status/live.txt"):
            try:
                g = requests.get(f"{GH_API}/{fname}", headers=hdr, timeout=15)
                payload = html_text if fname == "status/view.html" else text
                data = {"message": f"replica status {now_day}", "content": base64.b64encode(payload.encode()).decode()}
                if g.status_code == 200 and g.json().get("sha"): data["sha"] = g.json()["sha"]
                p = requests.put(f"{GH_API}/{fname}", headers=hdr, json=data, timeout=30)
                print(f"[replica] 上传 {fname}: {'OK' if p.status_code in (200, 201) else f'HTTP {p.status_code}'}")
            except Exception as e:
                print(f"[replica] 上传 {fname} 异常: {e}")
        time.sleep(15)   # ★ 上传完等 GitHub 提交传播，再 purge 防竞态钉死旧缓存（评审 #10）
        # ---- 缓存交付：四通道统一 purge + 新鲜度自检（SRE 方案 A，2026-10-11）----
        # 根因：jsDelivr 对高频更新的固定文件名，purge 可能被节点钉住/限流；
        # 对策：不再依赖单通道，四通道全刷，并回读校验，哪个通道旧一目了然。
        mirrors = ('cdn.jsdelivr.net', 'fastly.jsdelivr.net',
                   'gcore.jsdelivr.net', 'testingcf.jsdelivr.net')
        # ⚠️ purge 按路径限流（实测 throttlingReset≈600s）：每轮每路径只请求一次，
        #    不做镜像预热 GET——多发只会打满配额让刷新彻底失效（2026-10-11 实测教训）
        for fname in ('status/live.txt', 'status/latest.txt', 'status/view.html'):
            try:
                p = requests.get(f"https://purge.jsdelivr.net/gh/Llng125256/kx-combo@main/{fname}", timeout=15)
                th = 'throttled' if 'throttled' in p.text else 'ok'
                print(f"[replica] purge {fname}: {th}")
            except Exception:
                pass
        expect = f"v{__version__}"
        state = {h: '旧' for h in mirrors}
        for attempt in range(3):        # purge 传播需要时间：三轮轮询，最长约 90 秒判定
            time.sleep(25)
            for host in mirrors:
                if state[host] == '新':
                    continue
                try:
                    r = requests.get(f"https://{host}/gh/Llng125256/kx-combo@main/status/live.txt", timeout=15)
                    state[host] = '新' if expect in r.text[:80] else ('旧' if r.status_code == 200 else '异常')
                except Exception:
                    state[host] = '超时'
            if all(v == '新' for v in state.values()):
                break
        print(f"[replica] 缓存校验: " + " ".join(f"{h.split('.')[0]}={v}" for h, v in state.items())
              + f"（目标版本 {expect}，旧=该通道 CDN 缓存未刷新，页面首行时间戳为准）")
        # 可选直达通道：设置 KX_WECHAT_WEBHOOK 即推精简版到企微，绕过 CDN 缓存
        wh = os.environ.get("KX_WECHAT_WEBHOOK", "")
        if wh:
            push_summary(lines, wh, f"daily-{hhmm}.txt")
    return 0


if __name__ == "__main__":
    sys.exit(main())
