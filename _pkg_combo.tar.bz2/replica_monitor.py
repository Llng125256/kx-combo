#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""K线导演·复刻监控（自研引擎 + 模拟持仓，纯文本状态页）

【v1.7.45 2026-10-23 十席十四轮卡面重构（用户原话逐字上会，CEO 终裁定稿，纯渲染层）】
用户原话（最高纲领）：「把开头丁导交易系统的字段下面的小字都砍了已经过时了，还有把卡片改成箱体引擎这样的渲染每个进度条就是轨道之间距离从轨道底到死锚出场，把保险丝砍了别显示了评分砍了没用了仓位显示砍了，现浮砍了，下面的小标注什么持有中破位观察之类的到站之类的全砍了」
①卡面=箱体引擎三段式：标题行（单字前缀⛔⚠️🏁✅+标的+「箱体锁定」+⚡共振+🆕/⏳+禁入/过宽放弃短标）+ 箱体轨道条（轨底=收盘止损线→轨顶=死锚出场，现价打点红/绿、锚位白刻线）+ 关键数字行（轨底/锚/死锚/信号区/信号日或持仓天数/现价）+ 顶替纯短行「🔁 顶替 MM-DD 旧卡」。
②砍=头行现浮/评分(周日)、8格全套（保险丝/仓位·杠杆/距死锚/距信号区上沿）、状态小标注全套（持有中/死区挣扎/破位观察N/2/到站/趋势终结/禁入说明/放弃长文/同标跳过事实/旧卡状态与浮盈）、横幅「页面读法」「挂单」两行（引用已砍元素=过时）。
③单字前缀保留（⚠️置顶风控区/排序通道依赖）；出清面板/牛闸横幅/敞口行/市况行页面级零改动；判定/账本/候选环零接触，只渲染变。文本页 live.txt 与卡面同口径同步砍。使用说明 v1.7.45 重写卡面章。KX_LOCAL_OUT=目录 本地产出。
【v1.7.44 2026-10-23 十席十二轮施工（CEO 冻结定稿，块一~块四）】
①块一·牛闸 gate：idx=池收盘价等权平均（剔 BSP/FWDI/BBX/BITO/STRC 与 close≤0 脏 bar，当日有效标的≥max(30,池半数)才计入）；ma50=最近50个有效日简单均线；±2% 迟滞状态机（关闸态 idx>ma50×1.02 开闸、开闸态 idx<ma50×0.98 关闸、带内维持）；冷启动有效日<50=关闸；T−1 打标（入场日用前一有效日收盘后状态）；**关闸=只禁建新仓（受理短路 skip_n['牛闸拦截']），出场/止损/仓位零接触**；KX_GATE_ENABLED=0 一键回退。三态横幅 gate_line 文本页+view.html 顶部双通道（红/绿描边）；卡面不加牛闸标注（横幅统一管）。
②块二·判定轮（P0）：W1=one() 收集 dc 加 `_t < now_day` 截断——forming bar 永不入 idx，同 UTC 日内任意轮 idx/ma50/闸态逐位恒定；W2=每次运行落盘 status/gate_freeze.json（{day,idx,ma,open,pool_n,ts}），同日已有快照且数值不一致→以冻结值为准显示+WARN（08:35 定版后全天不该变）；W3=快照缺失/损坏→按截断口径补算+横幅黄标「（快照缺失·按截断口径补算）」不静默不 crash（隔日快照=正常晨间定版路径，补算+落盘不亮标）；W4=横幅追加「idx/ma50 每日08:35定版冻结，盘中轮不动」。
③块三·治理件（T1_T7_rerun.md 定版重做引擎侧三项）：T3=候选观测字段 target_weight/filled_weight/skip_reason 追加（复用 skip_n 通路）+页脚影子覆盖行，下单逐笔零变化；T6=tail15_scale 只读指标（尾笔=已平 ret≥15%，scale=Σ(w·r)/Σr，w=notional/100；<0.90 双通道红字；单档引擎结构性偏低仅披露）；T7=横幅敞口行「📊 敞口: 并发 N/8｜总敞口 x.x%/50%｜当日新开 N/3」（取 portfolio_admit 既有输入，零新逻辑）。
④块四·页面重渲染 v1.7.44（deploy_ui_verdict.md 三/四/五节逐字定稿）：砍=每卡牛闸标/注记线全套(mark_lines 停用)/入场形态备注(sig_note)/📊复活卡标/🚫周日长标(改评分后缀「(周日)」)/卡龄中段/CCI 数字/死区区间数字(改短句)/ATR 倍数括号(随注记线)/顶替血缘长文(改短行)/红框长文压一行/扛单行压短；保留红线=锚/止损/收盘止损线/保险丝/死锚/信号区/状态行/⚠️置顶区/出清面板/敞口行/免责尾注；横幅定稿 10 行；使用说明 v1.7.44 产出 manual.html。KX_LOCAL_OUT=目录 本地产出 live.txt/view.html。引擎 __version__ 不动防污染回归基线。
【v1.7.43.1 2026-10-16 发版】页头文案修订（主管席终裁 agent-1c27a47b，纯展示层，判定/账本/候选环零接触）：①红色系统性质框右尾两数（30天硬顶均值+32%/趋势终结+11%）后加「（旧窗口统计）」并追加括注「现行真实代币窗口（2025-06→今）：胜45.1%·均值+1.42%·PF1.37（只买新卡，样本4.5个月无熊市）」②页面读法「评分含周一桶×1.3」→「评分无任何加成（周一桶加成已暂停，⚡仅展示参考）」③扛单口径回测行补「扛单回测≠实盘」④新增 HEADER_REV="1.7.43.1"（引擎 __version__ 不动避免污染回归基线），页头版本行显示「v1.7.43（文案1.7.43.1）」。文本页+HTML 双通道同步。
【v1.7.43.2 2026-10-16 发版】锚/死锚/信号区展示注记体系（五轮三席终裁 agent-65675953/agent-32459975/agent-a2dab2de6；T1/T2/T3 先验 v0.1+数值行全等级常驻；纯展示层，判定/账本/候选环零接触）：①常量区新增 T2_LINE=0.25/T3_LINE=1.0（×ATR14 先验 v0.1——先验判断值非统计定标，统计定标 v1.0 三条件=预注册普查完成+n≥300+主管终裁；重估≤±25%/≤2次/年；60日 T3 触发率>30%收紧至1.5、<3%放宽至0.75 双人复核）+四套终裁冻结文案模板（T1/T2/T3+数值行，逐字禁改）+口径定义入库（距信号区%=(锚−信号区上沿)/信号区上沿×100；信号区上沿=信号日EMA10−ATR14；死锚=信号日EMA10+ATR14；倒挂绝对差+ATR倍数双呈；ATR14=信号日ATR值 tr[i-14:i].mean() 与引擎同口径）；②渲染层新增 mark_eligible/mark_note/mark_lines 单源函数，HTML 信号卡价格行下方弱化小字号行+文本页卡文本对应位置双通道同步（仅未入场信号卡，持仓卡/结局卡不渲染；单卡单条 T1＞T2＞T3；数值行+「注记线v0.1｜样本n=N」卡眉版本行全等级常驻）；③sig 展示层新增 atr14/zone_hi 两个纯展示字段（信号日落值，判定读取路径零改动）；④HEADER_REV→1.7.43.2（__version__ 不动）；⑤配套只读普查脚本 _zone_dist_census.py（预注册口径冻结：导演池日线缓存+现行引擎候选环口径+主窗≥2025-06-01/对照窗≥2026-06-01，只读分布、不做收益推演、不产策略结论）。
【v1.7.37 2026-10-16 发版】期满真破位卡停留 1 天下架（交易分析团队主管席终裁批准；三席意见：多头驳回/空头批准/主管批准附条件——上线前置条件=验收 📋近日出清面板 完整展示近7日全部结局）：EXPIRE_LINGER 1→0，恢复 v1.7.25 旧行为（期满卡当日即出清、不挂卡），结局可见性由 v1.7.33 📋出清面板（近7日全部结局滚动展示）承接。纯展示层，判定/账本/候选环零接触。
【v1.7.30 2026-10-14 修复】顶替血缘旧卡状态标注修复（用户 10-14 指出 MUUUSDT 死卡标「持有中·浮盈-12.1%」误导观看者——10-07 信号观察期已满按纪律已死；交易分析团队双席辩论 bull22:bear21 + 研究主管蔡定锋终裁；纯展示层，判定/账本/候选环零接触）：
  (a) 状态读取源切换——supersede 血缘旧卡状态从候选环 exit_date（工程取证 9/9 全 None=坏源）改读与卡面同源的 sig 展示层状态（analyse 返回 sig_by_day 按 (sym,day) 索引全量信号含出清卡）；删除「无 exit_date 即渲染持有中」默认分支；
  (b) 状态词四态收敛（终裁矩阵）：live(含复活在仓)→「持有中·浮盈%·距到站%」（原样）｜⚠️破位观察中→「⚠️破位观察中·浮盈%」（无距到站）｜⛔brk_expire/复活后再破(killed)→「⛔真破位·已离场（模拟仓口径）·浮盈—·距到站—」｜✅dead/flag→「✅行程已走完·已平·浮盈—·距到站—」；
  (c) 安全网（空头席设计采纳）——状态不可判定/sig 缺失→中性渲染「顶替 MM-DD 旧卡：锚X/止损Y」不输出状态字段，绝不回退「持有中」默认值；_sig_post killed（复活后再破被杀卡）补挂展示标记（纯展示元数据）。
【v1.7.27 2026-10-13 22:5x 发版】页面开头新增红色系统性质声明（用户拍板）：右偏型趋势跟随系统/约46%交易被止损打掉(平均-7.66%)是必然的数学结果不是系统坏了/利润来自右尾(30天硬顶+32%/趋势终结+11%)/不敢扛浮亏手动干预止损不该用本系统。纯展示层。
  【v1.7.26 2026-10-13 21:4x 发版】横幅新增「扛单口径回测」事实行（用户问能否赚钱→三口径回测+交易分析团队终裁落地展示）：追卡片现价短线无超额（+5日 −0.27%）如实标注；回踩锚位进场+扛单（到站/趋势终结/30天硬顶，含资金费）均值+4.05%（幸存者0.7折+2.83%、验证期+2.44%）如实标注；纯展示层，引擎逻辑/账本零改动。
  【v1.7.29 2026-10-14 发版】跟单视图纪律位修复（用户 10-14 TEM/ORCL 案例指出；投资大师专家团 5 票会诊裁定——塔勒布/芒格/德鲁肯米勒/帕布莱/达摩达兰一致判「设计盲区非故意，P0 立即止血」；纯展示层，判定/账本/回测取数口径零改动）：
  (a) 架构原则（芒格升格）——任何新信息的展示，不得降低旧仓关键信息可达性；禁入/孤星是附加徽标不是替换状态，文本页与 HTML 禁入分支统一为「禁入（grade|lay 不满足开仓条件）｜原状态 advice」，advice 不再被 continue 丢弃（对齐 v1.7.14⑦ HTML 侧先例，文本页侧漏修本次补齐）；
  (b) 顶替明示——展示信号顶替同标旧候选时，新卡附旧卡血缘「顶替 MM-DD 旧卡：锚X/止损Y·持有中·浮盈N%·距到站N%／已平·理由 ret%｜展示位替换≠加仓指令，旧仓按原纪律管理」（旧卡=day 严格早于新信号的最近一条候选；候选补 dead_px 信号日定格死锚作展示元数据，判定逻辑不读）；旧卡在仓时文本页动词「买入→在册监控」（德鲁肯米勒：旧仓存活期禁出加仓暗示；测试套件不断言卡片动词，已核）；
  (c) advice 公共化——state_advice(x, cd) 单源实现，文本页/HTML/禁入三分支零漂移。
  入册未进本版（v1.8.0 候选）：持仓台账面板与信号流物理分离（帕布莱/达摩达兰/塔勒布）、持仓驱动硬状态机（塔勒布根因修复）、死锚 ATR 口径手术式修改+触站收盘价判定（达摩达兰，判定层需预注册）、ATR 膨胀期死锚衰减/效率退出（塔勒布/德鲁肯米勒）、孤星日 1.5% 阈值回溯校准（德鲁肯米勒）。
  【v1.7.25 2026-10-13 15:1x 发版】期满真破位卡结局停留（用户提案「期满别无声消失」，交易分析团队双席辩论 bull8:bear7 终裁）：⚠️观察期满未收复的卡不再瞬间消失，停留 1 天（EXPIRE_LINGER=1，置0回退旧行为）展示结局红旗「⛔真破位·期满已离场（模拟仓口径）」+建议行「已按纪律出清，本卡仅作结局展示」——纯事实陈述无祈使句（v1.7.22(e) 假文案教训+非投资建议免责下禁动作指令，双席共识否决用户原话「请立即离场」措辞）；排序归🏁出清组不占⚠️风控置顶（避免假警报）；归🏁组与 FLAG_LINGER=5 天先例对齐。模拟账本零影响（期满当日已记已平）。
【v1.7.24 2026-10-13 14:2x 发版】G路径企稳备注诚实化（用户拍板「修并且发版」）：「（数日企稳确认+吞没）」改为「（入场形态·触轨MM-DD后数日企稳确认+吞没）」——备注是信号出生时的形态描述、不随后市涨跌更新，URNM 破位卡顶「数日企稳确认」被误读为当前状态系展示语义缺陷；现在明确「入场形态」前缀+触轨日期，杜绝误读。复活分支 note 本就带日期语义无歧义，不动。纯文案改动，引擎逻辑/账本/测试零触碰。
【v1.7.23 2026-10-13 12:5x 发版】展示层六项裁决（研究主管终裁，候选环过滤/账本行为零改动）：\n  E1 评分周一干净桶×1.3立即启用——信号日为周一且前两根bar均未触轨（nan保护）记 mon_clean，信号环普通/G路径与候选环同口径打标；score_of 层系数乘子顺序=批量1.2→周一1.3→周日0.5，合成层封顶1.8（裁决封顶）；\n  E2 在册排序锁死：⚠️置顶(risk)→状态分组(1持有/2✅到站/3🏁离场(dead+flag同有归3)/9禁入沉底)→-评分→-盈亏比rr→-新鲜度(_idx新→旧，analyse不再pop _idx)→字母序；HTML禁入卡沉底不变；\n  E3 数据不足卡展示层直算（裁决A）：同日候选缺失时按信号字段直算止损距离/仓位/杠杆（周日照旧减半），废除「（数据不足）」占位，文本页与HTML卡同步，过宽照旧放弃并标注；\n  E4 HTML企稳备注独立成行：card 增 sig_note 形参，各信号卡/模拟仓卡传 x['note']，note div 内 advice 后换行独立展示；\n  E5 页面读法文案更新（⚠️置顶先处理→主信号卡唯一分级（评分含周一桶×1.3，标签≠推荐强度）→入场区/追高→✅默认走→🏁挪仓→禁入沉底勿捡），文本页与HTML横幅同步；\n  E6 影子观察统计行：从 sym_cands 全部已平候选聚合周一干净桶与G路径 n/胜率/均值，n=0桶略去，文本页置「约束：」后、HTML置页脚免责上一行（标签≠推荐强度）。
  【v1.7.22 2026-10-13 10:4x 发版】健康度大审整改版（交易分析团队双席辩论空头45:多头35，裁决「可用但需整改」，用户拍板全部实施）：\n  (a/b)「再破即离场」口径统一与诚实化——原死分支（文案承诺路径代码不存在）按语义修正规解：「再破」=复活后再破：展示机维持 breaks≥2 杀卡原语义、账本机从「重置观察期再等3天」改为「立即离场」（从严统一，废除双机不一致）；观察期内持续破位不另算（连续阴跌≠二次事件），期满自然离场；文案同步改诚实（「期满未收复即离场，复活后再破立即离场」）；(i)硬顶可观测——模拟仓卡加「持仓 N/30 天」+⏳硬顶将至标注；(c)堵归类泄漏——AI科技桶补关键词（存储/晶圆/传感器等13词，未分类桶同日≤1系既有 CAP_SECTOR_DAY 覆盖，删除审计发现的冗余检查）；(d)⚡环境标签冻结于信号日（修老卡漂移）；(e)无牌信号不再显示「模拟仓已按风控口径离场」假文案；(f)⚡环境乘数停用回退×1.00基线（98.4%信号乘数=1.00且强=反向减仓）；(g)批量层加成1.5→1.2；\n  (h)横幅新增「规则全历史战绩（诚实口径）：N笔/胜率/均值/中位」行+在册卡溢价标注幸存者快照——主口径切换为合并口径（裁决：决策依据诚实性优先）。\n  【v1.7.21 2026-10-13 09:3x 发版】修复硬顶死代码（工程测试席 S8 发现+用户拍板修）：候选扫描窗 n−HARD_CAP→n−2×HARD_CAP（解耦窗口/硬顶基准），硬顶退出 j−i0≥30 恢复可达；30-60天龄信号自此以「硬顶退出」已平仓身份入账本（不再随窗口被动蒸发），展示层不变（已平仓不上卡）；账本胜率/均值将计入这批负贡献信号（更真实）。行为语义与 D-Audit 拍板一致，仅让既定硬顶真实生效。\n  【v1.7.20 2026-10-13 02:4x 发版】用户拍板纯减法版：①CCI 深度标签(CCI≤-175)彻底删除——🥇金标/「深度标签」文本/评分2.0档全部移除，主信号(下影>40%)成为唯一分级（D-Factor v2.0 终审：928因子在超额收益+聚类bootstrap+两期CI严格口径下零存活，v1的65个过筛系市场漂移+名义p假象；深度标签全年54.5%弱于主信号58.3%且梯度双期反向）。②原计划三因子标注全部不上线（D-Factor v2.0 阴性结论）。③账本内原 🥇 深度信号自此按 🥈 主信号档位（轻仓）处理。\n  【v1.7.19 2026-10-13 01:3x 发版】D-Audit v1.0 审计处置（用户拍板）：①硬顶 60→30 天回撤（扛单指纹双期坐实）②下影40%保留（邻域局部最优）③EMA10 保留不改（EMA8/ATR14 预注册 2026-11 复验）④CCI≤−175 深度标签降级为纯展示（全年 54.5% 弱于主信号 58.3%，「最强子集」未复现；是否改 −150 待终审）⑤死区 0.3×ATR 预注册事件驱动路径回放补审计 ⑥周线趋势赋能正式关闭 ⑦30-60天龄陈旧信号将随硬顶回撤从页面/账本消失（账本统计口径变化如实记录）。
  【v1.7.18 2026-10-12 21:5x 发版】更新频率改版（用户拍板）：定时轮 4→6 轮/天（00:35/04:35/08:35/12:35/16:35/20:35，每4小时，08:35保留为权威定版轮），页面头部文案同步；引擎逻辑/破位判定/离场判定零改动，纯时点与文案变更。
  【v1.7.17 2026-10-12 20:5x 发版】模拟仓占位案（交易分析团队 bull 26 vs bear 50，裁决 B 维持同标不重叠）：展示语义修复三项——①模拟仓卡 note 改仓位自描述（开仓日/现浮/止损），废除引用其他信号建议的错位写法 ②同标跳过事实可见化（N次/最近日期/有牌k次，账本 skip_detail 上送渲染）③新信号卡交叉标注「已有模拟仓，仅在册展示不入账」。账本规则零改动。
  【v1.7.16 2026-10-12 20:3x 发版】用户要求周日信号醒目化：卡片标签位新增大红色「🚫周日·降权0.5·复评中」标注（#ff3b30，独立 span，不占用⚠️破位/有效止损等文本），文本页信号行同步加前缀；澄清：周日裁决为「降权0.5+预注册复评」非「禁止买入」，若用户拍板升格禁买另行裁决。合成场景 26/26（新增 T3 sun_half 旗标、T4b 红标与破位⚠️并存）。
  【v1.7.15 2026-10-12 发版】用户 LRCX 截图质疑 + 交易分析团队裁决（多头 27 分 vs 空头 47 分，研究主管裁定）：
  ①周六新信号下册——展示与模拟账本均不再收周六(UTC)生成的信号（全池回测 n=100 双口径全面负期望：+5日 42%/−1.04%、引擎退出 26.4%/−1.32%；
    10-10 批量日周一 11/12 破位卡集中于周六=「批量日加成依赖工作日机构接力资金」的机理反例）。
    硬性回归项：周五及更早信号的破位/到站状态机照常消费周六日 K 线（合成场景 T1 验证）。
  ②周日信号降权 0.5 + 卡片标注「周日信号·权重0.5·复评中」（n=26 不足以定罪亦不足满权）。
    预注册复评规则：引擎退出口径样本 n≥60 或满一季度（先到者）期望仍负→自动下册不再辩论；期望转正→恢复权重 1.0。
  ③展示层对齐：信号卡新增「有效止损」= 止损 − 0.3×ATR（隐藏死区透明化；LRCX 10-08 收盘跌破显示止损但在死区内 4 天未认定的口径差修复）。
  ④文案如实化：「止损纪律优先」→「确认破位·2日观察期（0.3×ATR 容差+收盘确认，收上信号区上沿即复活）」。
  ⑤口径提示：自本版起周六历史候选不入页面账本与展示（独立回测数据通道不受影响）；全池 12 张破位观察卡零漏检复核——机制未丢破位，纯透明性问题。
  【v1.7.14 2026-10-12 待发】模拟账本收复参考线由死锚价(EMA10+ATR)改为信号区上沿(EMA10-ATR)，与展示机统一（用户质疑+研究主管裁决+三变体回测：C 均值+2.38%/PF1.64 vs A +1.58%/1.46；代价=真破位离场更深-7.57% vs -5.57%，最差单笔相同-32.1%可接受；加严变体(连续2日收复)+1.92%/1.54 备选未采纳）。复活重定级进账本（裁决④）需盘中改仓逻辑与独立回测，留待下一批。⑥HTML信号卡note补入信号自带备注（数日企稳确认/收复恢复等，此前只显示引擎建议——17:35首跑验收时发现的展示缺口）。⑦禁入卡沉底展示+备注保留破位观察信息+带观察卡标签亮⚠️（用户截图 KORU 指出：无牌信号带⚠️时被排到最前且信息被禁入文案覆盖，双 bug）。
  【v1.7.13 2026-10-12 待发（等技术团队审查）】①haos反向加权：强共振实测唯一亏损子集(PF0.90,n=175)
  却持1.2倍加成，改强×0.80/弱×0.90/无·超买×1.00 ②展示重构：金银铜→主信号(下影>40%)/深度标签(CCI≤-175)，
  仅深CCI组(+2.01%)经双口径回测证实为A口径副产品，标签仅展示 ③破位口径统一：模拟账本止损与展示机一致
  （容忍1次+2天观察+收复信号区上沿复活），旧「1次即离场」回测证伪（胜率38.1%→47.4% 均值+1.20%→+1.56%），
  观察期出场747笔全部为首破后2天未收复，二次确认0笔 ④G路径(启明星/跨K线确认)：瘫脚触轨后3日内企稳阳柱
  （中间仅十字星/小实体）正式成信号，止损=确认日最低，n=1191 均值+1.44% PF1.41 ⑤_simulate 共用推演函数
  提取（回归29只零漂移）。
  【v1.7.12 2026-10-12】牌级架构重构（用户拍板+金融团队裁决+全池回测验证）：①硬顶 30→60 天（均值+0.76%→+0.94%，PF1.19→1.23，让🏁离场机制接管时间砍仓）②🥈下影阈值 50%→40%（n+255，均值+1.43% vs +1.33%，四档平坦低过拟合）③🥇CCI阈值 -150→-175（修口径后-175最优PF1.23；-250均值转负，钻石档方向证伪）④🥉（10日跌>10%）剔除——全表垫底PF1.09~1.21⑤新成员制=下影>40%（主信号）或 CCI≤-175（深度标签），仅深CCI组实测最强子集(+1.99%/PF1.52)；动态升降级（触轨后3日最深定级）回测三项全弱于静态版，否决封存。全部基于2025-06-01+真实数据窗口、干净口径（剔>8%止损+资金费+同标不重叠）。
  【v1.7.11 2026-10-12】热修：卡片页横幅胜率格式错误（笔数误格式化为百分比显示 900%），改为 win/n_closed 口径与文本页一致。
  【v1.7.10 2026-10-12】热修：purge 清单补入 status/view.html——v1.7.9 暴露 view.html 从不刷缓存、用户最长看 12h 旧页的交付缺陷（一行修复）。
  【v1.7.9 2026-10-12】view.html 升级为卡片版 UI（丁导K线交易系统，用户定稿）：信号卡与模拟仓卡同款字段（锚/止损/死锚出场/距止损/仓位/杠杆/信号区/日期/现浮），CCI 不再上页面（引擎逻辑零改动，仅渲染层）；文本页四文件口径不变。
  【v1.7.0 2026-10-11】推荐即模拟持仓（专家团联合设计，用户拍板）：
  · 评分排序 = 分级分 × 当日层分 × 威廉环境分（全部实测值映射）
      分级 🥇2.0/🥈1.6/·1.1（v1.7.12起无🥉）；层 批量1.5/常规1.0/孤星禁入；环境 强1.2/弱1.0/🥈弱0.8
  · 档位决策表（v1.7.12起无🥉）：🥇批量=重/中仓，🥈批量=中/轻，🥇常规/🥈常规=轻，
    孤星一律禁入，无牌禁入（样本<30的格子按最差邻近处理）
  · 仓位：重10%/中6%/轻3% 名义；杠杆=风险预算÷(名义×止损距离)，封顶5×；
    风险预算 重1.0%/中0.6%/轻0.3%；止损距离<1.5%按1.5%计，>8%放弃信号
  · 止损=死区下沿+收盘确认（5规则回测帕累托最优：+1.35%，2×ATR方案-10.7%被否）
  · ✅走默认留例外（留须斜率>0+收盘>EMA10+量比>0.8）；✅后连续2日站稳EMA10→止损上移保本
  · 优先级 ⚠️>🏁>✅>30天硬顶；每轮重算只输出单一当前建议，旧建议自动隐藏
  · 【金融团队审计 2026-10-11】①模拟仓确认失败离场（到站后2日确认中收盘≤EMA10→当日平，
    命名「✅确认失败离场」，比设计默认走更早锁盈属保守化）②⚠️破位三确认≥1回填设计
    ③展示「⚠️观察中」时若模拟仓已离场→标注「模拟仓已按风控口径离场」④免责补两句
  ⑤模拟账户<100笔标注「样本不足，不构成有效性证据」
  · 行业分散：name括号解析→因果链归组，同大类≤2只/≤20%，同大类同日新开≤1只；
    解析失败进「未分类」桶同受约束；宽基ETF单列不计行业但计总敞口
    （v1.7.39 暂缓执行——无行业数据源，TODO 待接入行业分类后恢复）
  · 熔断（v1.7.39 中间态单档·账本机真执行）：并发≤8、单票≤10%、总敞口≤50%、
    杠杆=风险预算÷止损距离≤5×、止损距离>8%放弃入场；常量单源（pos_size/portfolio_admit）
  · 模拟盘=规则化全量模拟（每条合格信号必开仓、全约束），无幸存者偏差；
    资金费按0.01%/8h粗扣；跌穿止损按实际收盘记亏不美化
  · 市况横幅置顶：孤星日明示「今日不适合抄底」
  【破位口径（v1.7.13 统一）】模拟仓止损已与展示破位机统一：容忍 1 次确认破位
  （2 天观察 + 收复信号区上沿复活），观察期满或再次确认破位才离场。旧口径（1 次即离场）经
  回测证伪（胜率 38.1%→47.4%、均值 +1.20%→+1.56%、中位 −2.34%→−0.40%），历史分歧废弃。
  两处逻辑仍需同步检查。
  【v1.6】卖出并入买入行：✅死锚到站 / 🏁EMA10离场线 / ⚡威廉环境 / 终局驱动展示
  【v1.2】破位/收复状态机：容差0.3×ATR+三确认（爆量/瘫脚/CCI）
  【v1.0】Lucy=肯特纳双轨触及；🥇CCI<-150+收盘位>0.3（样本外验证：仅近期市场状态有效）
  公式搜索结论（2026-10-11）：8候选企稳公式无一通过替换及格线，CCI守位。
"""
from __future__ import annotations

import base64
import json
import logging
import os
import sys
import time
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

import requests
import html
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kx_client import KxClient  # noqa: E402

HEADER_REV = "1.7.45.0"    # v1.7.45.0 箱体引擎卡面重构（十四轮用户原话逐字定稿：标题行+箱体轨道条+关键数字行，砍保险丝/评分/仓位/现浮/状态小标注全套；纯展示层，判定/账本/候选环零接触；引擎 __version__ 不动避免污染回归基线）
__version__ = "1.7.43"    # v1.7.43: 三提案实施（主管席 agent-b3d7f773 终裁：甲→乙→丙，仅代码+本地测试，未上传未发版）：甲=复活卡独立统计标签（批准条件：统计层only+「非决策依据」标注+绑定口径版本号+样本<30不出结论）——_sig_post 收复分支落 revival_stat{revive_date,basis=1.7.42}，卡面渲染「📊复活卡·统计追踪·非决策依据」（文本+HTML），页脚统计区输出复活卡累计数，样本<30 输出「暂不出结论」，无任何胜率/右尾自动结论、不参与排序/剔除；乙=⚠️风控卡置顶固定风控区上限3张（批准条件：固定风控区限3张）——risk_zone_keys 按破位日期（brk_day 新落上）新→旧取3张入风控区 risk=0，其余⚠️卡回落常规排序 risk=1 不删除不隐藏，⛔结局组/✅到站组/常规组既有次序规则零改动；丙=下架主列表「⛔保险丝触发·已按纪律出清」结局卡（四条件全做）——①出清面板行数上限40→动态不截断（选动态化而非提至80：面板窗本身限7日，行数硬上限是唯一丢存量点，近7日窗内全量在册，文本+HTML双通道）②保险丝结局行首⚡醒目标记（多头条件，双通道）③面板保留当日/累计出清计数+最近一单摘要（空头条件）④渲染过滤 is_fuse_ending（brk_expire+exit_kind=fuse）卡不入主列表（与 v1.7.37 期满卡同路径：EXPIRE_LINGER=0 已在 _sig_post 出清主力路径，此处过滤 v1.7.31(a) 顶替升权残留渲染路径），⛔期满卡保持 v1.7.37 现状（已下架）不回退    # v1.7.42: 两项废除令（用户验收 2026-10-16，仅代码+本地测试，未上传未发版）：①废除下影>0.4主信号判定（交易三席终裁 agent-0d6d0908）——_sig_post 恢复定级 sh_r>0.4 复活门与触轨/候选环 shadow>0.4 分级代码路径删除，收复即复活、全信号 ·级；G 路径启明星形态判定（在册机制）零接触 ②废除🥈主信号分级（交易三席终裁 agent-7f2a447d）——TIER_MAIN=1.0 全信号统一乘子、TIER_POS 8/6/4%→单档6%（CAP_TICKER=0.10 硬顶兜底超限截断不递补，衔接 v1.7.39 风控层）、推荐口径=「通过全部禁入门槛的信号全集」（原「主信号子集」）、🥈徽标停用（渲染函数 tag_of 整体停用，卡面每日重推导、存量卡自然出清消化；⚠️/⛔/🆕/⏳/⚡ 标记通道不受影响）、·级无警示卡剔除规则停用；翻案判据=批量日≥30样本p<0.05且样本外通过    # v1.7.41: 取消入场cp>0.3过滤（用户验收2026-10-16，主管席终裁agent-f80e6cea，CI闸门+0.726pp/CI[0.116,1.361]下界>0/7季全正；翻案判据=滚动30票优势<0.5pp即回退）：账本机候选环入场判定=触EMA10−ATR14下轨即成立，删除 cp<=0.3 过滤（tests/prereg_cp_ci.md 预注册+tests/cp_ci_gate.py 闸门通过）；破位机三确认的cp<0.3（出场侧瘫脚判定）与展示机G路径零接触；冷却/扫描窗/周六/只买新卡/批量日/孤星禁入/评分分层v1.7.40定版全保留    # v1.7.40: 评分分层与仓位映射定版（用户验收 2026-10-16，三席终裁 agent-f067a173，翻案判据见交接件）：主信号评分乘子1.6→1.1、无牌1.1→1.0（TIER_MAIN/TIER_DOT 单源），环境乘子强1.2/弱1.0 等全部封存=1.0（ENV_MULT 单源）；仓位映射 10/6/3%→8/6/4%（TIER_POS 单源，pos_size 兜底同源复用）；判定/候选环零接触    # v1.7.39: 中间态风控层真执行进账本机（用户验收 2026-10-16，风控层定版：中间态单档）：模拟仓准入与仓位规则=并发≤CAP_CONCURRENCY(8)/单票名义≤CAP_TICKER(10%)/总敞口≤CAP_GROSS(50%)/杠杆=风险预算÷止损距离≤MAX_LEV(5×)/止损距离>MAX_STOP(8%)放弃入场，常量集中定义单源化（pos_size+portfolio_admit 唯一出处，展示层 direct_calc/常规卡同源复用）；行业分散暂缓——无行业数据源（sector_of 关键词启发式不可靠），CAP_SECTOR*/行业限额块停用并标注 TODO 待接入行业分类后恢复；60 交易日观察期条款（单日DD>20%降杠杆50%/PF<1.0停机/期满PF≥1.3转正）监控指标（交易日进度/单日最大DD/PF）在文本页尾部+HTML页脚输出。判定/候选环零接触    # v1.7.38: 保险丝盘中-only（用户验收 2026-10-16，主管席终裁：盘中触及即走）：_simulate/_sig_post 保险丝判定由「收盘触及」改「盘中 low[j]<=fuse_px 即触发」，离场价=触丝价 fuse_px（按触丝价成交，非收盘价）；forming bar 隔离（v1.7.36 止于最后完整交易日）保留不动；翻案判据=样本外崩盘测试盘中版 maxDD 未优于收盘版或滑点损失>1pp 即回调收盘版    # v1.7.38(前置): ⛔结局红旗标签文案修复（保险丝≠期满）：文本页+HTML 标签此前只判 brk_expire 硬编码「期满已离场」，v1.7.34 起保险丝结局卡（触锚×0.8 后2日内离场）全部错挂期满文案——新增 brk_red_tag 单源按 exit_kind 分流（fuse→⛔保险丝触发·已按纪律出清 / 默认→期满），advice 层判定不动（线上取证 exit_kind 已正确落上）。纯展示层，判定/账本/候选环零接触    # v1.7.37: 期满真破位卡停留 1 天下架（交易分析团队主管席终裁批准，三席：多头驳回/空头批准/主管批准附条件）：EXPIRE_LINGER 1→0，恢复 v1.7.25 旧行为（期满即出清不挂卡）；结局可见性由 📋近日出清面板（v1.7.33）承接，上线前置条件=验收出清面板完整展示近7日全部结局。纯展示层，判定/账本/候选环零接触    # v1.7.36: forming bar 退出卡龄链路（xbi 卡龄标注闪断修复）：末根bar日期=now_day(UTC)判定为当日进行中bar，卡龄 _age 与 _sig_post 破位状态机/复活/期满/死锚🏁判定一律止于最后一个完整交易日 lc_idx——修复晚间拉取含forming bar导致的①卡龄漂移±1（🆕↔卡龄N天边界抖动）②held_old/brk_expire 随盘中价翻转→badge 显示/消失闪断（xbi 实测：forming close 上穿旧卡收复线→旧卡被复活出清→四态矩阵读「持有中」→held_old→🆕消失；盘中午后回落/次日完整收盘→翻转回显示）。与冻结规格「止损只看收盘」「保险丝收盘触及」口径一致；now_day=None 行为与旧版逐位一致（向后兼容）。纯展示层，判定/账本/候选环零接触    # v1.7.35: 撤销v1.7.34深破加速线（交易分析团队真agent复核：多头席全桶无优势+空头席参数脆弱+V3在案警示），保留保险丝无条件生效；箱体页另挂诚实声明    # v1.7.34: 破位观察期深破加速线+保险丝无条件生效（用户拍板2026-10-15，13512事件分桶数据背书，spec=verdict_v6_bombardment.md§7）：①观察期内收盘<显示止损−1.5×ATR→立即离场(⛔深破加速止损)不等期满 ②保险丝(锚×0.8)收盘触及无条件生效(⛔保险丝)——修复ASTS穿丝仍干等漏洞。展示机同步brk_expire结局。判定依据=深破桶697笔(2天制-1.45%≈d1.5-1.52%打平，缩短持刀时间)    # v1.7.33: 📋 近日出清面板（用户拍板 2026-10-15，panel_spec 冻结规格）：近7个交易日全部出清结局（⛔破位/🏁趋势终结/✅到站/⏹硬顶/⚖️保本/❌确认失败）滚动展示，文本页尾部+HTML 底部独立 section，解决期满红旗卡一天蒸发的可见性盲区。纯展示层，判定/账本/候选环零接触    # v1.7.32: 卡龄标注上卡（用户拍板 2026-10-15，badge_spec 冻结规格）：每卡显示 🆕新卡(0-1交易日)/卡龄N天(2-4)/⏳老卡N天·新卡窗口已过(≥5)，文本页标签后+HTML卡主标签正下方同级；⛔期满卡与 held_old 豁免卡不显示。数据依据=卡龄课题 6803 笔配对回测（只买新卡终裁）。纯展示层，判定/账本/候选环零接触    # v1.7.31: 展示层整改（用户 ASTS 质询驱动+交易分析团队终裁）：①「有效止损」改名「收盘止损线」（语义诚实化：收盘跌破它才进观察期）②新增死区挣扎徽章（收盘∈[收盘止损线,止损) 时明示未确认破位照常持有）③新增保险丝单参考价=锚×0.8（券商挂单转换规则：盘中只防崩）④页头挂单规则行⑤期满红旗升权（用户拍板方案a）：被新信号顶替的期满卡同屏展示一天（归🏁出清组），期满次日自动出清——修复「期满红旗线上零出现」的可见性盲区。纯展示层，判定/账本/候选环零接触    # v1.7.30: 顶替血缘旧卡状态标注修复（交易分析团队双席辩论 bull22:bear21+研究主管终裁，用户拍板）：状态读取源从候选环 exit_date（9/9 全 None 坏源）改读与卡面同源的 sig 展示层状态（sig_by_day 全量传递），四态收敛矩阵+不可判定中性渲染安全网，判定/账本/候选环零接触    # v1.7.29: 展示层资本保全修复（投资大师专家团 5 票会诊裁定）：①架构原则——任何新信息的展示不得降低旧仓关键信息可达性；②孤星/禁入标注只追加不覆盖（文本页+HTML 双改， advice 不再被 continue 丢弃）；③顶替明示——新卡附旧卡血缘（日/锚/止损/状态/浮盈%/距到站%），旧卡在仓时动词降级「买入→在册监控」+「展示位替换≠加仓指令」防火墙    # v1.7.27: 页面开头新增红色系统性质声明（右偏趋势跟随/止损是数学必然）    # v1.7.26: 横幅新增扛单口径回测事实行（追现价无超额/锚位扛单正期望·含0.7折与衰减如实标注）    # v1.7.25: 期满真破位卡结局停留1天（红旗+归🏁出清组）
GH_API = "https://api.github.com/repos/Llng125256/kx-combo/contents"
HARD_CAP = 30            # 信号/模拟仓硬顶（天）——v1.7.19 回撤（D-Audit v1.0 扛单指纹双期坐实：30天窗 60.8%/+1.74% vs 60天窗 52.5%/+0.25%，30-60天龄陈旧信号为负贡献；用户拍板 2026-10-13）
FLAG_LINGER = 5
EXPIRE_LINGER = 0        # v1.7.37: 期满停留下架（交易分析团队三席：多头驳回/空头批准/主管批准附条件），结局展示由📋出清面板承接（v1.7.33）；置1=回退v1.7.25停留1天行为
WORKERS = 16
BARS = 150
MAX_LEV = 5.0            # 杠杆封顶（=风险预算÷止损距离，≤5×；v1.7.39 单源）
MAX_STOP = 0.08          # 止损距离>8%放弃入场（v1.7.39 单源，原 STOP_FAR）
STOP_NEAR = 0.015        # 止损距离<1.5%按1.5%计
# v1.7.40 用户验收定版 2026-10-16，三席终裁 agent-f067a173，翻案判据见交接件
# v1.7.42 废除🥈主信号分级（用户验收 2026-10-16，主管席 agent-7f2a447d）：分级/梯度/仓位映射单档化，翻案判据=批量日≥30样本p<0.05且样本外通过
TIER_POS = {'中仓': 0.06}   # 仓位映射单源：名义占比单档 6%（v1.7.42 废除 8/6/4% 梯度）；CAP_TICKER=0.10 硬顶兜底——pos_size 内 min() 超限截断不递补，与 v1.7.39 风控层常量直接衔接
TIERS = {'中仓': (TIER_POS['中仓']*100, 0.6)}   # 名义%, 风险预算%（单档=原中仓 0.6 预算沿用）
TIER_MAIN = 1.0          # v1.7.42 废除（用户验收 2026-10-16，主管席 agent-7f2a447d）——🥈主信号评分乘子 1.1 废除→全信号统一 TIER=1.0（常量单源保留，score_of 在用）；翻案判据=批量日≥30样本p<0.05且样本外通过
ENV_MULT = 1.0           # 环境乘子封存：强1.2/弱1.0 等全部=1.0（v1.7.22(f) 停用后的定版固化）
# ---- v1.7.39 风控层常量（中间态单档·单源化）：模拟仓准入与仓位规则唯一出处，pos_size/portfolio_admit 执行 ----
CAP_CONCURRENCY = 8      # 并发持仓上限（同时在仓≤8只）
CAP_TICKER = 0.10        # 单票名义占比上限（10%净值）
CAP_GROSS = 0.50         # 总敞口占比上限（50%净值）
CAP_TOTAL = CAP_GROSS * 100.0   # 总敞口%（兼容别名，单源=CAP_GROSS）
CAP_DAY_NEW = 3          # 同日新开
# TODO(行业分散·暂缓): 原 CAP_SECTOR=20%/CAP_SECTOR_N=2/CAP_SECTOR_DAY=1 及账本机行业限额块自 v1.7.39
# 停用——无行业数据源（sector_of 关键词启发式不可靠），待接入行业分类数据后恢复行业分散约束（用户验收 2026-10-16）
FUND_FEE_DAY = 0.0003    # 资金费 0.01%/8h ≈ 0.03%/天（名义占比）
# ---- v1.7.44 块一·牛闸常量（十席十二轮 CEO 冻结定稿；T2 生产口径：池=导演全部 EQUITY−GATE_EXCLUDE，无 min_bars 过滤）----
GATE_EXCLUDE = {'BSPUSDT', 'FWDIUSDT', 'BBXUSDT', 'BITOUSDT', 'STRCUSDT'}   # 稀疏 5 只剔除（逐字定版）
GATE_MIN_DAYS = 50       # 冷启动有效日<50=关闸（宁可不赚不赔）
GATE_BAND = 0.02         # ±2% 迟滞带


def pos_size(tier, stop_dist, is_sun=False):
    """v1.7.39: 仓位/杠杆单源计算（中间态单档）——账本机/展示层（direct_calc、常规卡、HTML卡）唯一出处。
    名义 = min(档位基准, 风险预算÷止损距离, 单票上限 CAP_TICKER×100)；
    杠杆 = max(1, min(MAX_LEV, 风险预算÷(名义×止损距离)))；周日名义减半（杠杆上限不变）。
    返回 (notional, lev, reason)：reason 非 None = 放弃入场（当前仅止损距离>MAX_STOP）。"""
    if stop_dist > MAX_STOP:
        return None, None, '止损过宽'
    base, risk = TIERS.get(tier, (TIER_POS['中仓']*100, 0.6))   # v1.7.42: 兜底同源=单档（原轻仓兜底随梯度废除）
    notional = round(min(base, risk / stop_dist, CAP_TICKER * 100), 1)
    lev = round(max(1.0, min(MAX_LEV, risk / (notional * stop_dist))), 1)
    if is_sun:    # v1.7.15: 周日降权——名义减半（杠杆上限不变）
        notional = round(notional * 0.5, 1)
        lev = round(max(1.0, min(MAX_LEV, risk / (notional * stop_dist))), 1)
    return notional, lev, None


def portfolio_admit(active, sym, notional, day_new_n):
    """v1.7.39: 组合级准入单源（中间态单档）——同票不重叠、并发≤CAP_CONCURRENCY、
    总敞口≤CAP_GROSS、同日新开≤CAP_DAY_NEW。行业分散暂缓（无行业数据源，TODO 见常量区）。
    返回 None=准入；否则拒入原因字符串（skip_n 计数键）。"""
    if any(p['sym'] == sym for p in active):
        return '已有持仓'
    if len(active) >= CAP_CONCURRENCY:
        return '并发满'
    if sum(p['notional'] for p in active) + notional > CAP_GROSS * 100:
        return '总敞口满'
    if day_new_n >= CAP_DAY_NEW:
        return '当日限额'
    return None

SECTOR_KEYS = [
    ('宽基', ('ETF', '指数', '基金')),
    ('AI科技', ('半导体', '芯片', '光模块', 'AI', '算力', '数据中心', '云计算', '软件', '信息技术', '电子设计', '网络', '互联网', '存储', '内存', '晶圆', '设备', '测试', '传感器', '机器人', '智能', '数字', '科技', '技术', '数据')),
    ('汽车', ('汽车', '电动车', '整车', '自动驾驶')),
    ('医疗健康', ('医药', '生物', '医疗', '健康', '制药', '疗法', '诊断', '基因')),
    ('能源', ('石油', '天然气', '油气', '能源', '煤炭', '铀', '核能', '电力', '太阳能', '光伏', '新能源', '油田')),
    ('金融', ('银行', '保险', '证券', '金融', '支付', '交易所', '资管', '信贷')),
    ('消费', ('零售', '餐饮', '食品', '饮料', '咖啡', '服装', '消费', '家居', '电商', '旅游', '酒店', '度假', '博彩', '体育', '鞋', '啤酒', '美容', '化妆品', '宠物')),
    ('工业防务', ('航空', '航天', '国防', '军工', '防务', '机械', '制造', '工程', '建筑', '运输', '物流', '铁路', '卡车', '航运')),
    ('通信', ('电信', '通信', '运营商', '电话')),
    ('原材料', ('矿业', '稀土', '化工', '钢铁', '材料', '化肥', '造纸', '黄金', '白银', '铜', '铝')),
    ('媒体娱乐', ('媒体', '传媒', '影视', '流媒体', '游戏', '音乐', '视频', '娱乐')),
    ('房地产', ('房地产', '地产', 'REIT', '物业')),
]


def sector_of(name: str) -> str:
    """name 字段因果链归组：宽基最优先 → 关键词匹配 → 未分类。"""
    if not name:
        return '未分类'
    if 'ETF' in name or '指数' in name or '基金' in name:
        return '宽基'
    inner = name[name.find('（')+1:name.find('）')] if '（' in name and '）' in name else name
    text = inner + name
    for bucket, keys in SECTOR_KEYS:
        if bucket == '宽基':
            continue
        for kw in keys:
            if kw in text:
                return bucket
    return '未分类'


def ema(x, n):
    a = 2/(n+1); out = np.full(len(x), np.nan); out[0] = x[0]
    for i in range(1, len(x)): out[i] = a*x[i] + (1-a)*out[i-1]
    return out


def ema_nan(x, n):
    a = 2.0/(n+1)
    out = np.full(len(x), np.nan)
    idx = np.where(~np.isnan(x))[0]
    if len(idx) == 0: return out
    s = idx[0]; out[s] = x[s]
    for i in range(s+1, len(x)): out[i] = a*x[i] + (1-a)*out[i-1]
    return out


def wpr(high, low, close, n):
    hh = np.full(len(close), np.nan); ll = np.full(len(close), np.nan)
    for i in range(n-1, len(close)):
        hh[i] = high[i-n+1:i+1].max(); ll[i] = low[i-n+1:i+1].min()
    rng = hh - ll
    out = np.where(rng == 0, -50.0, (hh-close)/np.where(rng == 0, 1, rng)*-100.0)
    out[:n-1] = np.nan
    return out


def t3(x, n, v):
    e1 = ema_nan(x, n); e2 = ema_nan(e1, n); e3 = ema_nan(e2, n)
    e4 = ema_nan(e3, n); e5 = ema_nan(e4, n); e6 = ema_nan(e5, n)
    return (-v**3)*e6 + (3*v**2+3*v**3)*e5 + (-6*v**2-3*v-3*v**3)*e4 + (1+3*v+v**3+3*v**2)*e3


def _simulate(high, low, close, vol, ema10, atr, cci, n, dates, i0, ei, stop, dead, anchor, rec_ref=None):
    """持仓推演（v1.7.13 抽取为共用函数，逻辑与原内联逐字一致）:
    破位=统一容忍口径(首破进2天观察, 收上信号区上沿复活, 复活后再破=立即离场[v1.7.22 与展示机统一从严口径], 期满未收复离场) >
    到站三条件 > 保本 > 🏁趋势终结 > 硬顶(HARD_CAP, 自信号日 i0 起算)。
    返回 (exit_day, exit_px, reason)。"""
    rec_line = dead if rec_ref is None else rec_ref   # v1.7.14: 收复参考线
    fuse_px = anchor*0.8 if anchor is not None else None   # v1.7.34: 保险丝=锚×0.8
    exit_day, exit_px, reason = None, None, '在仓'
    hold, pend, cnt2 = False, 0, 0
    st_j, brk_j = 'live', None
    for j in range(ei, n):
        if np.isnan(atr[j]) or np.isnan(cci[j]): continue
        if fuse_px is not None and low[j] <= fuse_px:   # v1.7.38: 保险丝盘中触及即走（用户验收2026-10-16，主管席终裁：盘中-only），离场价=触丝价 fuse_px 非收盘价
            exit_day, exit_px, reason = j, fuse_px, '⛔保险丝'
            break
        pen = stop - close[j]
        if pen > 0.3*atr[j]:
            rng_j = high[j]-low[j]+1e-9
            cp_j = (close[j]-low[j])/rng_j
            vr_j = vol[j]/(vol[max(0, j-10):j].mean()+1e-9)
            if (vr_j > 3.0) + (cp_j < 0.3) + (cci[j] < -100) >= 1:
                if st_j == 'live':
                    st_j, brk_j = 'broken', j          # 首破：进入2日观察
                elif st_j == 'recovered':
                    # v1.7.22(b): 复活后再破=立即离场（与展示机 killed 同步，废除原「重置观察期再等3天」）
                    exit_day, exit_px, reason = j, close[j], '⚠️破位止损'
                    break
                # st_j=='broken'（观察期内持续破位）：不另算，期满自然离场（连续阴跌≠二次事件）
        if st_j == 'broken' and close[j] > rec_line:
            st_j = 'recovered'          # 收复信号区上沿=复活(v1.7.14)
        # v1.7.35: 深破加速线撤销（交易分析团队复核：多头席独立复算全桶无优势+空头席参数脆弱；V3在案警示一致）
        if st_j == 'broken' and (j - brk_j) > 2:
            exit_day, exit_px, reason = j, close[j], '⚠️破位止损'
            break
        if st_j == 'broken':
            continue    # 审查/Tessa修复: 观察期内破位优先级最高, 不评估到站/保本/🏁
        if not hold and high[j] >= dead:
            if pend == 0:
                slope_ok = (ema10[j]+atr[j]) > (ema10[j-1]+atr[j-1])
                ema_ok = close[j] > ema10[j]
                vr_ok = vol[j]/(vol[max(0, j-10):j].mean()+1e-9) > 0.8
                if not (slope_ok and ema_ok and vr_ok):
                    exit_day, exit_px, reason = j, close[j], '✅到站止盈'
                    break
                pend = 1          # 三条件过，进入连续2日站稳确认
                continue
            else:
                if close[j] > ema10[j]:
                    pend += 1
                    if pend >= 3:  # 到站日 + 2日确认
                        hold = True
                    continue
                else:
                    exit_day, exit_px, reason = j, close[j], '✅确认失败离场'
                    break
        if hold:
            if close[j] < anchor:
                exit_day, exit_px, reason = j, close[j], '保本离场'
                break
            cnt2 = cnt2+1 if close[j] < ema10[j] else 0
            if cnt2 >= 2:
                exit_day, exit_px, reason = j, close[j], '🏁趋势终结'
                break
        if j - i0 >= HARD_CAP:
            exit_day, exit_px, reason = j, close[j], '硬顶'
            break
    return exit_day, exit_px, reason



def _sig_post(sig, high, low, close, openp, vol, atr, cci, ema10, n, dates,
              d_i, lo_i, hi_i, dead_px, anchor_px=None):
    """展示层信号后处理（v1.7.13 自原内联块提取，普通触轨与 G 路径共用）:
    破位/收复状态机(容忍1次+2天观察+收复信号区上沿复活) > ✅死锚标记 > 🏁趋势终结(FLAG_LINGER 出清)。
    d_i=信号日下标; lo_i=止损线; hi_i=收复参考线(信号区上沿); dead_px=死锚出场价。
    返回 True=保留, False=出清。"""
    state, breaks, brk_j, rec_j = 'live', 0, None, None
    killed = False
    for j in range(d_i+1, n):
        if np.isnan(atr[j]) or np.isnan(cci[j]): continue
        # v1.7.38: 保险丝(锚×0.8)盘中 low 触及→⛔结局（与账本机同步，盘中-only）；live态触丝视为确认破位入观察流（v1.7.34a 堵永久滞留泄漏）
        if anchor_px is not None and low[j] <= anchor_px*0.8:
            sig['brk_expire'] = True; sig['exit_kind'] = 'fuse'
            if state != 'broken':
                state, brk_j = 'broken', j
            break
        back = close[j] > hi_i
        pen = lo_i - close[j]
        if state == 'broken' and back:
            state, rec_j = 'recovered', j
            continue
        if pen <= 0.3*atr[j]: continue
        rng_j = high[j]-low[j]+1e-9
        cp_j = (close[j]-low[j])/rng_j
        vr_j = vol[j]/(vol[max(0, j-10):j].mean()+1e-9)
        conf = sum([vr_j > 3.0, cp_j < 0.3, cci[j] < -100])
        if conf >= 1 and state != 'broken':
            # v1.7.22(b): 口径注释——「再破」=复活（recovered）后的再次确认破位 → breaks=2 杀卡；
            # 观察期内持续破位不另算（连续阴跌≠二次事件），期满自然离场。账本机已同步此口径。
            breaks += 1
            if breaks >= 2:
                killed = True
                sig['killed'] = True   # v1.7.30: 展示层元数据——复活后再破被杀卡（纯展示标注，判定逻辑不读；供 supersede 血缘标⛔）
                break
            state, brk_j = 'broken', j
    if killed: return False
    if state == 'broken':
        lag = (n-1) - brk_j
        if lag > 2 + EXPIRE_LINGER: return False    # v1.7.25: 停留 EXPIRE_LINGER 天后出清
        if lag > 2:
            sig['brk_expire'] = True    # v1.7.25: 期满真破位·结局停留日——不设⚠️观察警告（避免假警报位），改挂「⛔真破位·期满已离场」红旗并归🏁出清组
        elif not sig.get('exit_kind'):   # v1.7.34a(B②): fuse/deep 结局卡不挂 ⚠️观察中
            sig['warn'] = (sig['warn'] + f' ⚠️破位{dates[brk_j][5:]}观察中').strip()
            sig['brk_day'] = dates[brk_j]   # v1.7.43 乙: 破位日期定格（风控区「新→旧取3」排序键，纯展示元数据）
    elif state == 'recovered':
        # v1.7.42 改动一（废除下影>0.4 主信号判定，交易三席终裁 agent-0d6d0908）：
        # 删除 sh_r=(min(close,open)−low)/(high−low)>0.4 的主信号判定代码路径——
        # 原逻辑=恢复日下影>40% 才定🥈复活，否则 return False 出清；现收复信号区上沿即复活，
        # 恢复卡一律 ·级（🥈分级同步废除=改动二）。G 路径启明星形态判定系另一套在册机制，未动。
        sig['grade'] = '·'
        sig['cci'] = cci[rec_j]
    sig['dead_px'] = round(float(dead_px), 2)
    dead_j = None
    for j in range(d_i+1, n):
        if high[j] >= dead_px:
            dead_j = j; break
    flag_j = None
    if dead_j is not None:
        sig['dead'] = f" ✅行程已走完({dates[dead_j][5:]})"
        cnt = 0
        for j in range(dead_j+1, n):
            cnt = cnt+1 if close[j] < ema10[j] else 0
            if cnt >= 2:
                flag_j = j
                sig['flag'] = f" 🏁趋势终结({dates[j][5:]})"
                break
    if flag_j is not None and (n-1) - flag_j > FLAG_LINGER:
        return False    # 🏁回看期满 → 出清
    return True


def analyse(sym, bars, now_day):
    """单标的：返回 (最新展示信号|None, 候选列表, 信号日集合, last_close)。

    候选 = 2×HARD_CAP(60) 天扫描窗内每个合格触及事件（硬顶 HARD_CAP 天退出，v1.7.21） + 单标的全生命周期推演
    （⚠️破位止损 > ✅走默认留例外 > 保本/🏁 > 30天硬顶；组合级约束由 main 叠加）。
    """
    if len(bars) < 40:
        return None, [], set(), 0.0, set(), {}
    dates = [str(b['time'])[:10] for b in bars]
    high = np.array([float(b['high']) for b in bars])
    low = np.array([float(b['low']) for b in bars])
    close = np.array([float(b['close']) for b in bars])
    openp = np.array([float(b['open']) for b in bars])
    vol = np.array([float(b.get('volume') or 0) for b in bars])
    n = len(bars)
    # v1.7.36: forming bar 不参与卡龄链路——末根bar日期=now_day(UTC)即为当日进行中bar，
    # 卡龄与破位状态机一律止于最后一个完整交易日 lc_idx（修复晚间拉取含forming bar导致的
    # 卡龄漂移±1与 held_old/brk_expire 随盘中价闪断；now_day=None 时行为与旧版完全一致）
    lc_idx = n - 1
    if now_day and dates[-1] == now_day:
        lc_idx = n - 2
    ema10 = ema(close, 10)
    tr = np.maximum(high[1:], close[:-1]) - np.minimum(low[1:], close[:-1])
    tr = np.concatenate([[high[0]-low[0]], tr])
    atr = np.full(n, np.nan)
    for i in range(14, n): atr[i] = tr[i-14:i].mean()
    tp = (high+low+close)/3
    cci = np.full(n, np.nan)
    for i in range(19, n):
        w = tp[i-19:i+1]; m = w.mean(); cci[i] = (tp[i]-m)/(0.015*np.abs(w-m).mean()+1e-9)
    cand_win = n - 2 * HARD_CAP    # v1.7.21: 候选扫描窗=2×硬顶，覆盖信号全生命周期（修复硬顶分支不可达：原 n−30 与 j−i0≥30 互斥，硬顶从未真实触发）
    f_t3 = t3(wpr(high, low, close, 14), 3, 0.7)
    s_t3 = t3(wpr(high, low, close, 96), 3, 0.7)

    def env_at(i):
        if np.isnan(f_t3[i]) or np.isnan(s_t3[i]): return '无'
        if f_t3[i] <= -90 and s_t3[i] <= -90: return '强'
        if s_t3[i] <= -90: return '弱'
        if f_t3[i] >= -10 and s_t3[i] >= -10: return '超买'
        return '无'

    sigs = []
    sig_by_day = {}   # v1.7.30: 展示层状态索引 {信号日: sig}——含被出清的卡（brk_expire/killed/🏁回看清零），供 supersede 血缘读取与卡面同源的旧卡状态
    candidates = []
    touch_days = set()
    last = -99
    for i in range(20, n-1):
        if np.isnan(ema10[i]) or np.isnan(atr[i]) or np.isnan(cci[i]): continue
        if not (low[i] <= ema10[i]-atr[i]) or i - last <= 2: continue
        rng_i = high[i]-low[i]+1e-9
        cp_i = (close[i]-low[i])/rng_i
        if cp_i <= 0.3:
            # v1.7.13 G路径(启明星/跨K线确认): 瘫脚触轨后3日内出现企稳阳柱
            # (中间仅十字星/小实体), 信号日=确认日j, 锚=确认日次日开盘, 止损=确认日最低。
            # 回测 n=1191 均值+1.44% PF1.41（主信号 n=1601 +2.16% PF1.70）。
            # 审查修复#1: G 触发时设 last(触轨去重)、受 hard 窗口约束、确认日计入 touch_days。
            for j in range(i+1, min(i+4, n-1)):
                body_j = abs(close[j]-openp[j])/(high[j]-low[j]+1e-9)
                cpj = (close[j]-low[j])/(high[j]-low[j]+1e-9)
                if close[j] > openp[j] and cpj > 0.3 and not np.isnan(cci[j]):
                    last = i                    # G 触发同计触轨去重（同一次下跌只记一次）
                    if i < cand_win: break      # v1.7.21: 超扫描窗触轨不产 G 信号
                    touch_days.add(dates[j])    # 确认日=真实买入触发日, 计入孤星/批量统计
                    if _is_sat(dates[j]): break    # v1.7.15: 周六新信号下册（市况统计仍计入）
                    g_g = '·'    # v1.7.42 改动二: 🥈主信号分级废除（用户验收 2026-10-16，主管席 agent-7f2a447d）——新信号不再打🥈；G 路径启明星形态判定本身保留（改动一边界）
                    anchor_j = float(openp[j+1])
                    stop_j = float(low[j])
                    dead_j = float(ema10[i]+atr[i])
                    sig_g = {'day': dates[j], 'side': 'buy', 'grade': g_g, '_idx': j,
                             'anchor': anchor_j, 'zone': f"[{low[i]:.2f}~{ema10[i]-atr[i]:.2f}]",
                             'cci': float(cci[i]), 'warn': '',
                             'env': env_at(j), 'stop': stop_j}
                    sig_g['stop_eff'] = round(float(stop_j - 0.3*atr[j]), 2)    # v1.7.15
                    # v1.7.23: E1 周一干净桶——确认日(信号日)为周一、j>=2 且前两根 bar 均未触轨（nan 视为未触轨）
                    if _wd(dates[j]) == 0 and j >= 2:
                        _t1 = (not np.isnan(ema10[j-1]) and not np.isnan(atr[j-1])
                               and low[j-1] <= ema10[j-1]-atr[j-1])
                        _t2 = (not np.isnan(ema10[j-2]) and not np.isnan(atr[j-2])
                               and low[j-2] <= ema10[j-2]-atr[j-2])
                        if not _t1 and not _t2:
                            sig_g['mon_clean'] = True
                    # 审查修复#2: G 信号与普通信号同走展示后处理（破位状态机+✅+🏁出清）
                    _g_keep = _sig_post(sig_g, high, low, close, openp, vol, atr, cci, ema10, lc_idx + 1, dates,
                                        j, stop_j, ema10[i]-atr[i], dead_j, anchor_px=anchor_j)
                    sig_by_day[dates[j]] = sig_g   # v1.7.30: 无论去留全量登记（出清卡带 brk_expire/killed 状态供血缘读取）
                    if _g_keep:
                        sigs.append(sig_g)
                    sd_j = max(0.015, (anchor_j-stop_j)/anchor_j)
                    if sd_j <= 0.08:
                        ed, ep, rs = _simulate(high, low, close, vol, ema10, atr, cci, n, dates,
                                               i0=j, ei=j+1, stop=stop_j, dead=dead_j, anchor=anchor_j,
                                               rec_ref=ema10[i]-atr[i])
                        candidates.append({'day': dates[j], 'grade': g_g, 'env': env_at(j),
                                           'anchor': anchor_j, 'stop': stop_j, 'stop_dist': sd_j,
                                           'idx': j, 'n': n, 'src': 'G',
                                           'dead_px': round(float(dead_j), 2),   # v1.7.29: 信号日定格死锚（展示层元数据，供顶替明示的距到站%；判定逻辑不读）
                                           'mon_clean': bool(sig_g.get('mon_clean')),   # v1.7.23: E1 G 候选同口径 mon_clean（供影子统计）
                                           'exit_day': ed,
                                           'exit_date': dates[ed] if ed is not None else None,
                                           'exit_px': ep, 'reason': rs,
                                           'ret': (ep/anchor_j-1)*100 if ed is not None else None})
                    break
                elif body_j <= 0.3:
                    continue          # 十字星/小实体过渡, 允许
                else:
                    break             # 大实体非企稳 = 下跌中继, 放弃
            continue
        last = i
        if i < cand_win: continue    # v1.7.21: 扫描窗放宽至2×硬顶
        touch_days.add(dates[i])
        if _is_sat(dates[i]): continue    # v1.7.15: 周六新信号下册（市况统计仍计入）
        rng = high[i]-low[i]+1e-9
        cp = (close[i]-low[i])/rng
        vr = vol[i]/(vol[max(0, i-10):i].mean()+1e-9)
        c = cci[i]
        # v1.7.42 改动一+二（终裁 agent-0d6d0908 / agent-7f2a447d）: 删除 shadow=(min(close,open)−low)/(high−low)>0.4
        # 对主信号/主信号子集的构成作用——下影不再决定分级，全信号统一 ·级
        grade = '·'
        lo_i, hi_i = low[i], ema10[i]-atr[i]
        anchor = openp[i+1]
        sig = {'day': dates[i], 'side': 'buy', 'grade': grade, '_idx': i, 'anchor': anchor,
               'zone': f"[{lo_i:.2f}~{hi_i:.2f}]", 'cci': c,
               'warn': '', 'env': env_at(i), 'stop': lo_i}
        sig['stop_eff'] = round(float(lo_i - 0.3*atr[i]), 2)    # v1.7.15: 有效止损=止损−0.3×ATR（死区透明化）
        # v1.7.23: E1 周一干净桶——信号日为周一、i>=2 且前两根 bar 均未触轨（nan 视为未触轨）
        if _wd(dates[i]) == 0 and i >= 2:
            _t1 = (not np.isnan(ema10[i-1]) and not np.isnan(atr[i-1])
                   and low[i-1] <= ema10[i-1]-atr[i-1])
            _t2 = (not np.isnan(ema10[i-2]) and not np.isnan(atr[i-2])
                   and low[i-2] <= ema10[i-2]-atr[i-2])
            if not _t1 and not _t2:
                sig['mon_clean'] = True

        _keep = _sig_post(sig, high, low, close, openp, vol, atr, cci, ema10, lc_idx + 1, dates,
                          i, lo_i, hi_i, ema10[i]+atr[i], anchor_px=anchor)
        sig_by_day[dates[i]] = sig   # v1.7.30: 无论去留全量登记（出清卡带 brk_expire/killed 状态供血缘读取）
        if not _keep:
            continue    # 破位观察期满/二次确认/🏁回看期满 → 出清
        sigs.append(sig)
    sigs.sort(key=lambda s: s['day'], reverse=True)

    # ---- 候选（模拟仓推演，单标的无约束口径）----
    last_c = -99
    for i in range(20, n-1):
        if np.isnan(ema10[i]) or np.isnan(atr[i]) or np.isnan(cci[i]): continue
        if not (low[i] <= ema10[i]-atr[i]) or i - last_c <= 2: continue
        # v1.7.41: 取消入场cp>0.3过滤（用户验收2026-10-16，主管席终裁agent-f80e6cea，CI闸门+0.726pp/CI[0.116,1.361]下界>0/7季全正；翻案判据=滚动30票优势<0.5pp即回退）——触下轨即成立入场，其余条件（冷却/扫描窗/周六/新卡/批量/孤星/分层）不变；破位机三确认的cp<0.3（出场侧）不动
        last_c = i
        if i < cand_win: continue    # v1.7.21: 扫描窗放宽至2×硬顶
        if _is_sat(dates[i]): continue    # v1.7.15: 周六新信号不入账本
        # v1.7.42 改动二: 🥈分级废除（agent-7f2a447d）——候选环 grade 仅作展示字段，不再参与分级/准入
        grade = '·'
        anchor = openp[i+1]
        stop = low[i]
        stop_dist = max(STOP_NEAR, (anchor-stop)/anchor)
        cand = {'day': dates[i], 'grade': grade, 'env': env_at(i), 'anchor': anchor,
                'stop': stop, 'stop_dist': stop_dist, 'idx': i, 'n': n, 'src': '触轨',
                'dead_px': round(float(ema10[i]+atr[i]), 2)}   # v1.7.29: 信号日定格死锚（展示层元数据，供顶替明示的距到站%；判定逻辑不读）
        # v1.7.23: E1 候选环同口径 mon_clean（供影子统计；本环过滤逻辑零改动）
        if _wd(dates[i]) == 0 and i >= 2:
            _t1 = (not np.isnan(ema10[i-1]) and not np.isnan(atr[i-1])
                   and low[i-1] <= ema10[i-1]-atr[i-1])
            _t2 = (not np.isnan(ema10[i-2]) and not np.isnan(atr[i-2])
                   and low[i-2] <= ema10[i-2]-atr[i-2])
            if not _t1 and not _t2:
                cand['mon_clean'] = True
        # 生命周期推演（统一容忍口径：⚠️首破观察2天+收复信号区上沿复活，观察期满/再破离场；✅默认走须三条件+连续2日站稳确认）
        exit_day, exit_px, reason = _simulate(
            high, low, close, vol, ema10, atr, cci, n, dates,
            i0=i, ei=i+1, stop=low[i], dead=ema10[i]+atr[i], anchor=anchor,
            rec_ref=ema10[i]-atr[i])
        if exit_day is not None:
            cand.update({'exit_day': exit_day, 'exit_date': dates[exit_day],
                         'exit_px': exit_px, 'reason': reason,
                         'ret': (exit_px/anchor-1)*100})
        else:
            cand.update({'exit_day': None, 'exit_date': None, 'exit_px': None,
                         'reason': '在仓', 'ret': None})
        candidates.append(cand)
    # v1.7.21(🟠1): 展示窗=硬顶窗——信号龄>HARD_CAP 的卡不上展示（它们必然已硬顶出清）
    # v1.7.23: E2 不再 pop _idx——保留供展示排序的新鲜度键（新→旧）；展示窗过滤语义不变
    sigs = sorted((s for s in sigs if (n - 1) - s['_idx'] <= HARD_CAP),
                  key=lambda x: x['day'], reverse=True)
    latest = sigs[0] if sigs else None
    return latest, candidates, touch_days, close[-1], set(dates), sig_by_day   # v1.7.30: +sig_by_day 展示层状态索引


def push_summary(lines, webhook, snap_name):
    """企微精简推送（可选，默认关闭）：只推头部+模拟账户+在仓前5+⚠️/🏁行，不推全文。

    目的：jsDelivr 对固定文件名 purge 按路径限流（实测 throttlingReset≈598s），
    页面无法保证分钟级新鲜；推送走企微直达，不受任何 CDN 缓存影响。
    """
    head = lines[:6]
    acct = [l for l in lines if l.startswith('💼')][:1]
    pos = [l for l in lines if l.strip().startswith('▶')][:5]
    alert = [l for l in lines if ('⚠️破位' in l or '🏁' in l or '⛔' in l)][:5]
    body = "\n".join(head + ([""] + acct if acct else []) + (["", "▶ 在仓(前5):"] + pos if pos else [])
                     + (["", "⚡ 需处理:"] + alert if alert else ["", "（无⚠️/🏁告警）"])
                     + ["", f"完整页面: status/{snap_name}（带时间戳，永不缓存）"])
    try:
        r = requests.post(webhook, json={"msgtype": "text", "text": {"content": body[:3800]}},
                          timeout=15)
        print(f"[replica] 企微推送: {'OK' if r.status_code == 200 else f'HTTP {r.status_code}'}")
    except Exception as e:
        print(f"[replica] 企微推送异常: {e}")


def tier_of(grade, lay, env):
    """v1.7.42: 废除🥈主信号分级（用户验收 2026-10-16，主管席 agent-7f2a447d，翻案判据=批量日≥30样本p<0.05且样本外通过）。
    推荐口径=「通过全部禁入门槛的信号全集」单档中仓 6%；禁入门槛不变：孤星日禁入。
    grade/env 不再参与分级（🥈/· 差异废除），签名保留以兼容调用点。"""
    if lay == '孤星':
        return '禁入'
    return '中仓'    # v1.7.42: 全信号单档（原 🥈批量=中/轻、🥈常规=轻、无牌禁入 三分支删除）


def score_of(grade, lay, env, day=None, mon_clean=False):
    g = TIER_MAIN    # v1.7.42: 全信号统一乘子 1.0（🥈主信号分级废除，agent-7f2a447d；原 {'🥇':2.0,'🥈':TIER_MAIN}.get(grade,TIER_DOT) 删除）
    l = 1.2 if lay == '批量' else 1.0    # v1.7.22(g): 批量加成 1.5→1.2（行业性共振下跌中批量是同一次下跌的投影；同行业>5 失效条件留研究课题）
    if mon_clean:
        l *= 1.3    # v1.7.23: E1 周一干净桶 ×1.3（乘在层系数上；叠加顺序=先批量1.2→再周一1.3→封顶→再周日0.5）
    l = max(0.7, min(l, 1.8))    # v1.7.23: E1 合成层乘数封顶区间 [0.7,1.8]（只约束批量×周一合成；周日 0.5 为 v1.7.15 冻结独立乘数，在封顶之后叠加不受此区间约束）
    if day is not None and _is_sun(day):
        l *= 0.5    # v1.7.15: 周日信号降权 0.5（预注册复评：n≥60 或满一季度仍负→自动下册；v1.7.23 复核确认在封顶之后叠加）
    e = ENV_MULT    # v1.7.40: 环境乘子强1.2/弱1.0 等全部封存1.0（单源 ENV_MULT）
    return round(g*l*e, 2)


def is_fuse_ending(x):
    """v1.7.43 丙4: 保险丝结局卡判定（主列表下架用，单源）——brk_expire 且 exit_kind=fuse。
    ⛔期满卡（exit_kind 非 fuse）不在内=保持 v1.7.37 现状不回退。"""
    return bool(x.get('brk_expire') and x.get('exit_kind') == 'fuse')


RISK_ZONE_CAP = 3   # v1.7.43 乙: ⚠️固定风控区上限（主管席 agent-b3d7f773 批准条件：固定风控区限3张）


def risk_zone_keys(rows, cap=RISK_ZONE_CAP):
    """v1.7.43 乙: ⚠️风控区成员选定——⚠️确认破位·观察期卡按破位日期新→旧取前 cap 张
    入固定风控区（risk=0），其余 ⚠️卡回落常规排序（risk=1，不删除不隐藏仅不占风控位）；
    观察期不足 cap 张时风控区只占实际数。⛔brk_expire 卡无 warn 本就不占 ⚠️ 位（v1.7.25）。
    返回 {(sym, day)} 集合供 row_sort_key 消费；破位日期缺失时回退信号日。"""
    warn_rows = [r for r in rows if r[2].get('warn')]
    warn_rows.sort(key=lambda r: (r[2].get('brk_day') or r[2]['day'], r[2].get('_idx', 0)), reverse=True)
    return {(r[1], r[2]['day']) for r in warn_rows[:cap]}


def row_sort_key(r, closes, risk_keep=None):
    """v1.7.23: E2 在册排序多键（锁死）：⚠️置顶 → 状态分组 → -评分 → -盈亏比rr → -新鲜度(_idx新→旧) → 字母序。
    分组：1=持有中(无dead无flag) 2=✅已到站(dead非空) 3=🏁离场(flag非空，dead+flag同有归3) 9=禁入沉底。
    rr=(dead_px-close)/(close-stop_eff)；任一缺失或 close<=stop_eff 时 rr=-999（排组内最后）。
    v1.7.43 乙: risk_keep={(sym,day)}=⚠️固定风控区成员（risk_zone_keys 选定，上限3张）——
    区外 ⚠️卡 risk=1 回落常规排序；risk_keep=None（未传）保持旧全置顶行为。"""
    _, sym, x, _, _, tier, score = r
    in_risk = bool(x.get('warn')) and (risk_keep is None or (sym, x['day']) in risk_keep)
    risk = 0 if in_risk else 1
    if x.get('brk_expire') or x.get('flag'):
        group = 3    # v1.7.25: 期满真破位停留卡归🏁出清组（不占⚠️风控位）
    elif x.get('dead'):
        group = 2
    elif tier == '禁入':
        group = 9
    else:
        group = 1
    close = closes.get(sym, 0)
    dead_px = x.get('dead_px')
    stop_eff = x.get('stop_eff')
    if dead_px is None or stop_eff is None or not close or close <= stop_eff:
        rr = -999.0
    else:
        rr = (dead_px - close) / (close - stop_eff)
    return (risk, group, -score, -rr, -x.get('_idx', 0), sym)



def _wd(dstr):
    """UTC 日期串 -> weekday()（0=周一..5=周六, 6=周日）。"""
    import datetime as _dt
    return _dt.date(int(dstr[:4]), int(dstr[5:7]), int(dstr[8:10])).weekday()


def _is_sat(dstr):
    return _wd(dstr) == 5


def _is_sun(dstr):
    return _wd(dstr) == 6


REASON_EMO = {'⚠️破位止损': '⛔', '🏁趋势终结': '🏁', '✅到站止盈': '✅', '硬顶': '⏹', '保本离场': '⚖️', '✅确认失败离场': '❌'}   # v1.7.33
REASON_SHORT = {'⛔保险丝': '保险丝', '⚠️破位止损': '破位止损', '🏁趋势终结': '趋势终结', '✅到站止盈': '到站止盈', '硬顶': '硬顶', '保本离场': '保本', '✅确认失败离场': '确认失败'}   # v1.7.33
REASON_CLS = {'⚠️破位止损': 'red', '🏁趋势终结': 'grn', '✅到站止盈': 'grn', '硬顶': '', '保本离场': '', '✅确认失败离场': 'red'}   # v1.7.33


def collect_recent_exits(sym_cands, max_days=7):
    """v1.7.33: 📋 近日出清面板数据（纯展示层）——近 max_days 个交易日（按数据内实际出场日取最近7个不同日）的全部出清结局；
    (sym, day) 去重防触轨+G 同日碰撞；同日按收益升序（亏的先看）。返回 [{date,sym,reason,ret}] 按 date 新→旧"""
    seen, by_day = set(), {}
    for sym, cands in sym_cands.items():
        for c in cands:
            ed = c.get('exit_date')
            if not ed or c.get('ret') is None: continue
            key = (sym, c.get('day'))
            if key in seen: continue
            seen.add(key)
            by_day.setdefault(ed, []).append((sym, c['reason'], float(c['ret'])))
    if not by_day: return []
    days = sorted(by_day, reverse=True)[:max_days]
    out = []
    for ed in days:
        for sym, reason, ret in sorted(by_day[ed], key=lambda x: x[2]):
            out.append({'date': ed, 'sym': sym, 'reason': reason, 'ret': ret})
    return out


def exits_panel_text(exits, total_closed=None, max_rows=None):
    """v1.7.33: 文本页面板行（纯展示）。
    v1.7.43 丙（主管席 agent-b3d7f773 终裁）: ①行数上限 40→动态不截断（近7日滚动窗内全量
    在册，杜绝 40 行截断静默丢存量——选动态化而非提至80：窗本身限7日，行数硬上限是唯一丢存量点，
    全量展示成本可控）②保险丝结局行首加 ⚡ 醒目标记（多头条件）    ③保留当日/累计出清计数与
    当日最亏摘要（空头条件；摘要取面板内最近交易日 ret 最低一笔，同日按收益升序首条）。max_rows 参数保留兼容，None=不截断。"""
    if not exits: return ["📋 近日出清: 近 7 个交易日无出清"]
    from collections import Counter
    cnt = Counter(x['reason'] for x in exits)
    head = (f"📋 近日出清（近7个交易日）: 共 {len(exits)} 笔（"
            + " ".join(f"{REASON_SHORT[k]}{v}" for k, v in cnt.most_common()) + "）")
    out = [head]
    _last_day = max(x['date'] for x in exits)
    _today_n = sum(1 for x in exits if x['date'] == _last_day)
    _tot_s = str(total_closed) if total_closed is not None else '—'
    out.append(f"  当日出清 {_today_n} 笔({_last_day[5:]}) | 累计出清 {_tot_s} 笔 | "
               f"保险丝结局 {cnt.get('⛔保险丝', 0)} 笔 | 当日最亏: "
               f"{exits[0]['sym']} {exits[0]['date'][5:]} {REASON_SHORT.get(exits[0]['reason'], exits[0]['reason'])} {exits[0]['ret']:+.1f}%")
    for x in exits[:max_rows] if max_rows else exits:   # v1.7.43 丙1: 全量在册（默认不截断）
        _mark = '⚡' if x['reason'] == '⛔保险丝' else ''   # v1.7.43 丙2: 保险丝结局醒目标记
        out.append(f"  {_mark}{REASON_EMO.get(x['reason'], '·')} {x['sym']} {x['date'][5:]} {REASON_SHORT.get(x['reason'], x['reason'])} {x['ret']:+.1f}%")
    return out


def esc(s):
    return html.escape(str(s))


def render_html(rows, closes, open_pos, st):
    """卡片版 view.html（v1.7.9，丁导K线交易系统）。
    信号卡与模拟仓卡同款字段；纯渲染层，判定逻辑与文本页完全同源。"""

    def zone_s(x):
        z = x.get('zone')
        if isinstance(z, (list, tuple)):
            return f"[{z[0]:.2f}~{z[1]:.2f}]" if len(z) == 2 else '~'.join(str(v) for v in z)
        return str(z) if z else '—'

    def card(sym, lc, anchor, stop_eff, dead, zone, age_num='', warn_ch='', drop='', sup=''):
        # v1.7.45: 箱体引擎卡面（十四轮用户原话逐字定稿）——标题行+箱体轨道条+关键数字行。
        # 砍=头行现浮/评分、8格全套（保险丝/仓位·杠杆/距死锚/距信号区上沿）、状态小标注全套
        # （持有中/死区挣扎/破位观察/到站/趋势终结/禁入说明/放弃长文——放弃与禁入仅存短标）；
        # 轨道=[收盘止损线(轨底) → 死锚出场(轨顶)]，现价打点（红=现价<锚/绿=现价≥锚），锚位白刻线；
        # 顶替短行只留「🔁 顶替 MM-DD 旧卡」。纯渲染层，判定/账本零接触。
        def _f(v):
            if not isinstance(v, (int, float)):
                return '—'
            return f'{v:.1f}' if abs(v) >= 1000 else f'{v:.2f}'

        _fill = _tick = _dot = ''
        if (isinstance(stop_eff, (int, float)) and isinstance(dead, (int, float))
                and dead > stop_eff > 0):
            _span = dead - stop_eff
            if lc:
                _pos = max(0.0, min(100.0, (lc - stop_eff) / _span * 100.0))
                _dotc = '#2ecc71' if (isinstance(anchor, (int, float)) and lc >= anchor) else '#e74c3c'
                _fill = f'<div class="bfill" style="width:{_pos:.1f}%"></div>'
                _dot = f'<div class="bdot" style="left:{_pos:.1f}%;background:{_dotc}"></div>'
            if isinstance(anchor, (int, float)) and stop_eff < anchor < dead:
                _ap = (anchor - stop_eff) / _span * 100.0
                _tick = f'<div class="btick" style="left:{_ap:.1f}%"></div>'
        _drop_html = f'<span class="tag" style="color:{"#ff3b30" if "放弃" in drop else "#ff9f43"}">{esc(drop)}</span>' if drop else ''
        _warn_html = f'<span style="color:#ff3b30;font-weight:800;font-size:16px">{warn_ch}</span>' if warn_ch else ''
        _px = _f(lc) if lc else '—'
        return f'''<div class="card">
  <div class="card-h">{_warn_html}<b>{esc(sym)}</b><span class="locktag">箱体锁定</span>{_drop_html}</div>
  <div class="boxbar">{_fill}{_tick}{_dot}<span class="blab l">轨底 {_f(stop_eff)}</span><span class="blab r">死锚 {_f(dead)}</span></div>
  <div class="nums">轨底 {_f(stop_eff)} ｜ 锚 {_f(anchor)} ｜ 死锚 {_f(dead)} ｜ 信号区 {esc(zone)} ｜ {esc(age_num)} ｜ 现价 <b>{_px}</b></div>
  {(f'<div class="note">{esc(sup)}</div>') if sup else ''}
</div>'''

    sig_cards = []
    jin_cards = []   # v1.7.14: 禁入卡沉底展示（用户拍板：无仓位建议的卡不占前排）

    def warn_ch_of(x):
        """v1.7.45: 单字前缀（状态长文全砍后唯一状态通道）——⛔期满 > ⚠️观察 > 🏁终结 > ✅走完。"""
        if x.get('brk_expire'): return '⛔'
        if x.get('warn'): return '⚠️'
        if x.get('flag'): return '🏁'
        if x.get('dead'): return '✅'
        return ''

    for _, sym, x, cd, lay, tier, score in rows:
        lc = closes.get(sym, 0)
        se = x.get('stop_eff') if isinstance(x.get('stop_eff'), (int, float)) else None
        _base = dict(lc=lc, anchor=x['anchor'], stop_eff=se, dead=x.get('dead_px'),
                     zone=zone_s(x), age_num=f"信号日 {x['day'][5:]}",
                     warn_ch=warn_ch_of(x))
        if tier == '禁入':
            jin_cards.append(card(sym, drop='禁入', **_base))
            continue
        sig_cards.append(card(sym, **_base))

    sig_by_sym = {sym: x for _, sym, x, _, _, _, _ in rows}
    sim_cards = []
    for p in sorted(open_pos, key=lambda q: -q['score']):
        x = sig_by_sym.get(p['sym'])
        se_s = x.get('stop_eff') if x and isinstance(x.get('stop_eff'), (int, float)) else p['stop']
        _plc = closes.get(p['sym'], 0)
        _age = p.get('age')
        _age_s = f"持仓 {_age}/{HARD_CAP}天" if isinstance(_age, int) else "持仓 —"
        sim_cards.append(card(p['sym'], _plc, p['anchor'], se_s,
                              x.get('dead_px') if x else None, zone_s(x) if x else '—',
                              age_num=_age_s))    # v1.7.45: 箱体卡（现浮/仓位/管理中note/跳过事实随状态小标注全砍）

    sample_note = '' if st['n_closed'] >= 100 else '（样本不足，&lt;100笔不构成有效性证据）'
    _gb = st.get('gate_banner', '') or ''
    # v1.7.44 块一: 牛闸横幅独立 div——红/绿描边双通道（关=红/开=绿/带内=琥珀），W3 黄标随文案
    gate_html = (f'<div class="banner" style="border:2px solid {st.get("gate_border", "#ff3b30")};'
                 f'margin-bottom:8px;font-size:13.5px;color:#dbe2ee;font-weight:700">{esc(_gb)}</div>') if _gb else ''
    banner = f'''{gate_html}<div class="banner"><b>丁导K线交易系统 · v1.7.45（引擎v{st["ver"]}）</b> · {esc(st["up_ts"])} 北京时间更新（每日 00:35/04:35/08:35/12:35/16:35/20:35 六轮）<br>
{esc(st["expo_line"])}<br>
市况: {esc(st["market_banner"])} ｜ 扫描{st["pool_n"]} · 在册{st["hit_n"]} · ⚠️{st["warn"]}<br>
约束: 并发≤8·单票≤10%·总敞口≤50%·杠杆≤5×·止损距离&gt;8%放弃·同日≤3只·孤星日禁入·周六不入册<br>
📌 每标的只显示最新一条信号 ｜ 极端行情任何止损价都可能被跳空击穿</div>'''

    sim_html = chr(10).join(sim_cards)
    sig_html = chr(10).join(sig_cards + jin_cards)   # 禁入卡沉底
    obs_html = f'<p class="note">{esc(st.get("obs", ""))}</p>' if st.get('obs') else ''    # v1.7.39: 观察期监控指标行（页脚，空则略去）
    shadow_html = f'<p class="note">{esc(st.get("shadow", ""))}</p>' if st.get('shadow') else ''    # v1.7.23: E6 影子观察行（页脚免责上一行，空则略去）
    tail_html = f'<p class="note">{st.get("tail15_html", "")}</p>' if st.get('tail15_html') else ''    # v1.7.44 块三 T6: 尾部缩放比只读行（红字随文案自带 span）
    cov_html = f'<p class="note">{esc(st.get("cov", ""))}</p>' if st.get('cov') else ''    # v1.7.44 块三 T3: 影子覆盖率只读行
    _ex = st.get('recent_exits') or []    # v1.7.33: 📋 近日出清面板（纯展示）
    if _ex:
        from collections import Counter as _C
        _cnt = _C(x['reason'] for x in _ex)
        _dist = " ".join(f"{REASON_SHORT[k]}{v}" for k, v in _cnt.most_common())   # v1.7.43 丙6: 七类结局分布（复用同源 _cnt，most_common 排序+REASON_SHORT[k]{v} 空格连接，与文本通道 head 同格式同信息）
        _last_day = max(x['date'] for x in _ex)   # v1.7.43 丙3: 当日=面板内最近交易日
        _today_n = sum(1 for x in _ex if x['date'] == _last_day)
        _tot = st.get('exits_total_closed')
        _tot_s = str(_tot) if _tot is not None else '—'
        _ex_rows = "".join(
            f'<div style="display:flex;gap:8px;font-size:13px;line-height:1.9">'
            f'<span style="width:18px">{("⚡" if x["reason"] == "⛔保险丝" else "")}{REASON_EMO.get(x["reason"], "·")}</span>'
            f'<b style="min-width:96px">{esc(x["sym"])}</b>'
            f'<span style="color:#7c869c;width:44px">{esc(x["date"][5:])}</span>'
            f'<span style="width:72px">{REASON_SHORT.get(x["reason"], esc(x["reason"]))}</span>'
            f'<span class="{REASON_CLS.get(x["reason"], "")}" style="margin-left:auto;font-weight:700">{x["ret"]:+.1f}%</span></div>'
            for x in _ex)    # v1.7.43 丙1: 40 行截断删除——近7日窗内全量在册；丙2: 保险丝结局 ⚡ 醒目标记
        _ex_sum = (f'<div style="color:#7c869c;font-size:12px;margin:0 0 6px">'
                   f'当日出清 {_today_n} 笔({_last_day[5:]}) ｜ 累计出清 {_tot_s} 笔 ｜ '
                   f'保险丝结局 {_cnt.get("⛔保险丝", 0)} 笔 ｜ 当日最亏: {esc(_ex[0]["sym"])} {esc(_ex[0]["date"][5:])} '
                   f'{REASON_SHORT.get(_ex[0]["reason"], esc(_ex[0]["reason"]))} {_ex[0]["ret"]:+.1f}%</div>')   # v1.7.43 丙3；丙5: 摘要 date/reason 回退补 esc（对齐 1069-1071 行 esc 纪律；get 命中值系 REASON_SHORT 常量，不重复转义）
        exits_html = (f'<h2>📋 近日出清（近7个交易日·共 {len(_ex)} 笔·{_dist}）</h2><div class="card">{_ex_sum}{_ex_rows}</div>')
    else:
        exits_html = '<h2>📋 近日出清</h2><div class="card" style="color:#7c869c">近 7 个交易日无出清</div>'
    return f'''<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>丁导K线交易系统</title>
<style>
*{{box-sizing:border-box}}body{{margin:0;background:#0e1117;color:#dbe2ee;
font:15px/1.5 -apple-system,'PingFang SC','Microsoft YaHei',sans-serif;padding:14px}}
.wrap{{max-width:640px;margin:0 auto}}
.banner{{background:#171c26;border:1px solid #232a38;border-radius:12px;padding:14px 16px;
margin-bottom:14px;font-size:13px;color:#7c869c;line-height:1.9}}
.banner b{{color:#dbe2ee;font-size:17px}}
h2{{font-size:16px;margin:20px 0 10px}}
.grid2{{display:grid;grid-template-columns:1fr;gap:14px}}
.card{{background:#171c26;border:1px solid #232a38;border-radius:12px;padding:14px 16px}}
.card-h{{display:flex;align-items:center;gap:8px;flex-wrap:wrap}}
.tag{{font-size:14px;font-weight:700;border:1px solid #2b3446;border-radius:6px;padding:1px 6px}}.card-h b{{font-size:18px}}
.locktag{{font-size:12px;color:#8b93a1;border:1px solid #2b3446;border-radius:6px;padding:1px 6px}}
.env{{font-size:13px;font-weight:600}}
.boxbar{{position:relative;height:24px;background:#21262d;border-radius:6px;margin:10px 0 6px}}
.bfill{{position:absolute;left:0;top:0;bottom:0;background:linear-gradient(90deg,#e74c3c44,#2ecc7155);border-radius:6px 0 0 6px}}
.btick{{position:absolute;top:-2px;bottom:-2px;width:2px;background:#dbe2ee;opacity:.75;transform:translateX(-50%);z-index:1}}
.bdot{{position:absolute;top:50%;width:10px;height:10px;border-radius:50%;transform:translate(-50%,-50%);border:2px solid #0e1117;z-index:2}}
.blab{{position:absolute;top:3px;font-size:10px;color:#9aa4b5;padding:0 5px;z-index:1}}
.blab.l{{left:0}}.blab.r{{right:0}}
.nums{{font-size:12.5px;color:#aab3c5;line-height:1.8}}.nums b{{color:#dbe2ee}}
.grn{{color:#2ecc71}}.red{{color:#e74c3c}}.sm{{font-size:13px}}
.note{{margin-top:10px;color:#7c869c;font-size:13px;border-top:1px dashed #232a38;padding-top:8px}}
.mk{{margin-top:6px;color:#7c869c;font-size:12px;line-height:1.7}}
</style></head><body><div class="wrap">
{banner}
<h2>💼 模拟账户（在仓 {st["n_open"]}）</h2><div class="grid2">{sim_html}</div>
<h2>📋 在册信号（{len(sig_cards)}）</h2><div class="grid2">{sig_html}</div>
{shadow_html}
{tail_html}
{cov_html}
{exits_html}
{obs_html}
<p class="note">⚠️ 以上为历史统计规则输出，非投资建议；仓位与杠杆自定，极端行情下任何止损价都可能被跳空击穿。模拟成交假设 T+1 开盘价、无滑点与流动性约束；展示口径与模拟口径不同，模拟仓更保守。</p>
</div></body></html>'''

def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    print(f"[replica] 包代码版本 v{__version__}")
    tok = os.environ.get("KX_GH_TOKEN", "")
    cli = KxClient(signal_age_days=16, timeout=30, retries=3, retry_delay=2.0)
    items = cli.get_signals('futures', '1d', 1, 500).get('items') or []
    names = {it['symbol']: (it.get('name') or '') for it in items
             if (it.get('underlying_type') or '') == 'EQUITY' and it.get('symbol')}
    pool = sorted(names)
    now_day = datetime.now(timezone.utc).strftime('%Y-%m-%d')   # v1.7.36: 前置——analyse 需据此识别末根forming bar

    def one(sym):
        try:
            d = cli.get_kline(sym, 'futures', '1d', BARS)
            sig, cands, tdays, lc, dset, sig_by_day = analyse(sym, d.get('bars') or [], now_day)
            dc = {}    # v1.7.44 块一: 日收盘序列（供牛闸池水位），close≤0 脏 bar 剔除
            for b in (d.get('bars') or []):
                try:
                    _t = str(b.get('time', ''))[:10]
                    _c = float(b.get('close') or 0)
                    # v1.7.44 块二 W1: `_t < now_day` 截断——forming bar 永不入 idx，
                    # 同一 UTC 日内任意轮 idx/ma50/闸态逐位恒定（=只在 08:35 轮动）
                    if _t and _t < now_day and _c > 0:
                        dc[_t] = _c
                except Exception:
                    pass
            return sym, sig, cands, tdays, lc, dset, sig_by_day, dc
        except Exception:
            return sym, 'ERR', [], set(), 0, set(), {}, {}

    with ThreadPoolExecutor(WORKERS) as ex:
        results = list(ex.map(one, pool))

    day_trig = Counter()
    sym_cands, sigs, closes, sig_by_days = {}, {}, {}, {}   # v1.7.30: +sig_by_days 展示层状态索引（sym→{day: sig}）
    daycloses = {}    # v1.7.44 块一: sym→{day: close} 供牛闸合成池水位
    calendar = set()
    for sym, sig, cands, tdays, lc, dset, sig_by_day, dc in results:
        if sig == 'ERR': continue
        sigs[sym] = sig
        sym_cands[sym] = cands
        closes[sym] = lc
        sig_by_days[sym] = sig_by_day   # v1.7.30
        daycloses[sym] = dc    # v1.7.44 块一
        calendar |= dset
        for d in tdays: day_trig[d] += 1
    cal = sorted(calendar)
    pool_n = max(1, len(pool))

    # ---- v1.7.44 块一: MA50 牛闸（等权 idx / ma50 / ±2% 迟滞 / 冷启动关闸 / T−1 打标 / 只禁建新仓）----
    GATE_ENABLED = os.environ.get('KX_GATE_ENABLED', '1') == '1'
    gate_snap_missing = False    # v1.7.44 块二 W3: 黄标旗
    gate_line = ''
    gate_border = '#ff3b30'
    if GATE_ENABLED:
        def build_gate(dcl, min_days=GATE_MIN_DAYS, band=GATE_BAND):
            """池=全部 EQUITY−GATE_EXCLUDE（T2 生产口径，无 min_bars 过滤）；
            idx=当日有效收盘等权平均（当日有效标的≥max(30,池半数) 才计入）；
            ma50=最近 min_days 个有效日简单均线（只用≤t，防前视）；±2% 迟滞状态机；冷启动<min_days=关闸。
            返回 (state{day:bool}, idx{day:float}, ma{day:float|None}, days[list])。"""
            src_maps = {s: m for s, m in dcl.items() if s not in GATE_EXCLUDE}
            days = sorted({d for m in src_maps.values() for d in m})
            idx_by_day = {}
            for d in days:
                vals = [m[d] for s, m in src_maps.items() if d in m]
                n = len(vals)
                if n >= max(30, int(0.5 * len(src_maps))):    # 当日有效标的下限：池半数且≥30
                    idx_by_day[d] = sum(vals) / n             # 等权平均（用户拍板，中位数废弃）
            sdays = sorted(idx_by_day)
            state, idx_ok, ma_ok = {}, {}, {}
            cur = False    # 冷启动：有效日<50=关闸
            for i, d in enumerate(sdays):
                if i + 1 < min_days:
                    state[d] = False; idx_ok[d] = idx_by_day[d]; ma_ok[d] = None; continue
                ma = sum(idx_by_day[x] for x in sdays[i + 1 - min_days:i + 1]) / min_days
                idx_ok[d] = idx_by_day[d]; ma_ok[d] = ma
                if cur:
                    if idx_by_day[d] < ma * (1 - band): cur = False
                else:
                    if idx_by_day[d] > ma * (1 + band): cur = True
                state[d] = cur
            return state, idx_ok, ma_ok, sdays

        gate_state, gate_idx, gate_ma, gate_days = build_gate(daycloses)

        def gate_ok(entry_day):
            """T−1 打标：入场日 d 用前一有效指数日的收盘后闸门状态。返回 (放行?, idx, ma50)。"""
            import bisect
            k = bisect.bisect_left(gate_days, entry_day)
            if k <= 0: return False, None, None
            pd_ = gate_days[k - 1]
            return gate_state[pd_], gate_idx.get(pd_), gate_ma.get(pd_)

        gate_now = gate_state[gate_days[-1]] if gate_days else False
        gate_idx_now = gate_idx.get(gate_days[-1]) if gate_days else None
        gate_ma_now = gate_ma.get(gate_days[-1]) if gate_days else None

        # ---- v1.7.44 块二 W2/W3: 08:35 定版冻结快照（status/gate_freeze.json）----
        _out_dir = os.environ.get('KX_LOCAL_OUT') or 'status'
        _freeze_path = os.path.join(_out_dir, 'gate_freeze.json')
        snap = None
        try:
            with open(_freeze_path, encoding='utf-8') as _f:
                snap = json.load(_f)
        except FileNotFoundError:
            snap = None
        except Exception as _e:
            print(f"[replica][WARN] gate_freeze.json 损坏（{_e}）→ 按截断口径补算")    # W3: 不静默不 crash
            snap = None
        _snap_valid = isinstance(snap, dict) and snap.get('day') == now_day \
            and isinstance(snap.get('idx'), (int, float)) and isinstance(snap.get('ma'), (int, float)) \
            and 'open' in snap
        if _snap_valid:
            _si, _sm, _so = float(snap['idx']), float(snap['ma']), bool(snap['open'])
            if gate_idx_now is not None and gate_ma_now is not None and \
               (abs(gate_idx_now - _si) > 1e-6 or abs(gate_ma_now - _sm) > 1e-6 or gate_now != _so):
                # W2: 08:35 定版后全天不该变——以冻结值为准显示 + WARN（判定层 gate_ok 仍走截断自算，口径恒定）
                print(f"[replica][WARN] 同日快照与自算不一致（idx 自算{gate_idx_now:.2f}/冻结{_si:.2f}，"
                      f"ma 自算{gate_ma_now:.2f}/冻结{_sm:.2f}）→ 横幅以冻结值为准")
                gate_now, gate_idx_now, gate_ma_now = _so, _si, _sm
        else:
            if snap is not None:
                print(f"[replica][WARN] gate_freeze.json 非本日快照（day={snap.get('day') if isinstance(snap, dict) else '无效'}）→ 本轮按截断口径定版并落盘")
            else:
                print("[replica][WARN] gate_freeze.json 缺失 → 按截断口径补算")
                gate_snap_missing = True    # W3: 横幅黄标（文件不存在/损坏=异常路径；隔日快照=正常晨间定版不亮标）
        if gate_idx_now is not None and gate_ma_now is not None:
            try:
                os.makedirs(_out_dir, exist_ok=True)
                if not _snap_valid:    # 同日已有快照以冻结为准不覆盖；新日/缺失才落盘
                    with open(_freeze_path, 'w', encoding='utf-8') as _f:
                        json.dump({'day': now_day, 'idx': gate_idx_now, 'ma': gate_ma_now,
                                   'open': gate_now, 'pool_n': pool_n,
                                   'ts': datetime.now(timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M:%S')}, _f)
            except Exception as _e:
                print(f"[replica][WARN] gate_freeze.json 落盘失败: {_e}")

        gate_blocked_n = 0
        if gate_idx_now is None or gate_ma_now is None:    # 冷启动/样本不足
            gate_line = "🐂 牛闸：样本不足·关闸（宁可不赚不赔）"
            gate_border = '#ff3b30'
        else:
            _pct = (gate_idx_now / gate_ma_now - 1) * 100
            _trig = gate_ma_now * 1.02
            _snap_mark = '（快照缺失·按截断口径补算）' if gate_snap_missing else ''
            _w4 = '｜ idx/ma50 每日08:35定版冻结，盘中轮不动'    # v1.7.44 块二 W4
            if abs(_pct) <= 2:
                gate_line = (f"🐂 牛闸：⚪ 带内维持（{'开启·允许开新仓' if gate_now else '关闭·禁止开新仓'}）｜ "
                             f"全场水位 {gate_idx_now:.2f} vs 50日线 {gate_ma_now:.2f}（±2%带内不变闸）{_snap_mark}{_w4}")
                gate_border = '#2ecc71' if gate_now else '#ff3b30'
            elif gate_now:
                gate_line = (f"🐂 牛闸：🟢 开启·允许开新仓 ｜ 全场水位 {gate_idx_now:.2f} ＞ 50日线 {gate_ma_now:.2f}"
                             f"（偏高 {_pct:.1f}%）{_snap_mark}{_w4}")
                gate_border = '#2ecc71'
            else:
                gate_line = (f"🐂 牛闸：⛔ 关闭·禁止开新仓 ｜ 全场水位 {gate_idx_now:.2f} ＜ 50日线 {gate_ma_now:.2f}"
                             f"（偏低 {abs(_pct):.1f}%，涨回 {( _trig / gate_idx_now - 1) * 100:+.1f}% 到 {_trig:.2f} 自动开闸）{_snap_mark}{_w4}")
                gate_border = '#ff3b30'
    else:
        gate_state, gate_idx, gate_ma, gate_days = {}, {}, {}, []

        def gate_ok(entry_day):
            return True, None, None    # KX_GATE_ENABLED=0: 一键回退=无闸基线，逐笔还原

    def layer_prev(dstr):
        """T-1 自然交易日触发数→层（日历化，零触发日=孤星；归一化：孤星<1.5%池，批量>8%池）。"""
        import bisect
        k = bisect.bisect_left(cal, dstr)
        if k <= 0: return '常规'
        cnt = day_trig.get(cal[k-1], 0)
        if cnt < 0.015*pool_n: return '孤星'
        if cnt > 0.08*pool_n: return '批量'
        return '常规'

    def lay_of_latest():
        """今日市况 = 最近一个已收盘交易日的 T-1。"""
        import bisect
        k = bisect.bisect_left(cal, now_day)
        if k == 0: return '常规'
        ref = cal[k-1] if (k < len(cal) and cal[k] == now_day) else cal[-1]
        k2 = cal.index(ref)
        if k2 <= 0: return '常规'
        cnt = day_trig.get(cal[k2-1], 0)
        if cnt < 0.015*pool_n: return '孤星'
        if cnt > 0.08*pool_n: return '批量'
        return '常规'

    # ---- 组合级模拟（时间序 sweep + 熔断 + 行业分散）----
    # 持仓自开仓日起占用名义额度，直到 exit_date（含）后下一候选日起释放——
    # 保证总敞口/行业敞口在持仓重叠期真实生效（技术评审 #1 修复）。
    active, closed = [], []
    skip_n = Counter()
    day_new = Counter()
    cands_all = []
    for sym, cands in sym_cands.items():
        for cd in cands:
            cd['sym'] = sym
            cd['sector'] = sector_of(names.get(sym, ''))
            # v1.7.44 块三 T3: 影子观测字段（纯追加，下单零变化；skip_reason 复用 skip_n 通路键名）
            cd.setdefault('target_weight', None)
            cd.setdefault('filled_weight', 0.0)
            cd.setdefault('skip_reason', None)
            cands_all.append(cd)
    cands_all.sort(key=lambda x: (x['day'], x['sym'], 1 if x.get('src') == 'G' else 0))   # 决胜键: 同日同标普通信号优先于G

    def sweep(day):
        """回收 exit_date<=day 的在仓仓位（当日收盘已平，次日额度释放）。"""
        for p in active[:]:
            if p['exit_date'] and p['exit_date'] <= day:
                active.remove(p)    # v1.7.21: 删 sector_state 死代码（仅递减从未递增，行业限额实际用实时 sum(active)，此缓存从未生效且键缺失会 KeyError）

    for cd in cands_all:
        sweep(cd['day'])
        sym = cd['sym']
        if GATE_ENABLED and not gate_ok(cd['day'])[0]:    # v1.7.44 块一: 牛闸受理短路（循环最前，只禁建新仓——出场/止损/仓位零接触）
            skip_n['牛闸拦截'] += 1; gate_blocked_n += 1
            cd['skip_reason'] = '牛闸拦截'    # T3 影子观测
            continue
        if any(p['sym'] == sym for p in active):
            skip_n['已有持仓'] += 1
            cd['skip_reason'] = '已有持仓'    # T3
            continue
        lay = layer_prev(cd['day'])
        tier = tier_of(cd['grade'], lay, cd['env'])
        if tier == '禁入':
            skip_n['禁入'] += 1; cd['skip_reason'] = '禁入'; continue    # T3
        notional, lev, sz_reason = pos_size(tier, cd['stop_dist'], _is_sun(cd['day']))   # v1.7.39: 仓位/杠杆单源——单票≤CAP_TICKER、杠杆≤MAX_LEV、止损距离>MAX_STOP 在此放弃
        if sz_reason:
            skip_n[sz_reason] += 1; cd['skip_reason'] = sz_reason; cd['target_weight'] = notional; continue    # T3
        cd['target_weight'] = notional    # T3: 意向名义（pos_size 已过）
        reason = portfolio_admit(active, sym, notional, day_new[cd['day']])   # v1.7.39: 中间态准入真执行——并发≤CAP_CONCURRENCY/总敞口≤CAP_GROSS/同日≤CAP_DAY_NEW
        if reason:
            skip_n[reason] += 1; cd['skip_reason'] = reason; continue    # T3
        # TODO(行业分散·暂缓): 原行业限额块（CAP_SECTOR/CAP_SECTOR_N/CAP_SECTOR_DAY）v1.7.39 停用——无行业数据源，接入后恢复（见常量区 TODO）
        b = cd.get('sector', '宽基')
        pos = {'sym': sym, 'day': cd['day'], 'anchor': cd['anchor'], 'tier': tier,
               'notional': notional, 'lev': lev, 'stop': cd['stop'], 'sector': b, 'age': cd['n'] - 1 - cd['idx'],   # v1.7.22(i): cd['n']=该标的K线总数
               'score': score_of(cd['grade'], lay, cd['env'], cd['day']),
               'exit_date': cd.get('exit_date'), 'exit_px': cd.get('exit_px'),
               'exit_idx': cd.get('exit_day'),
               'reason': cd.get('reason'), 'ret': cd.get('ret'),
               'open_idx': cd['idx'], 'n': cd['n']}
        active.append(pos)
        cd['filled_weight'] = notional    # v1.7.44 块三 T3: 影记成交（准入成功）
        day_new[cd['day']] += 1
        # v1.7.39: 行业同日新开计数随行业限额块一并停用（TODO 见常量区）
        # 平仓结算：推演已定退出日的，按当时价格入账（占用已由 sweep 释放）
        if pos['exit_date'] is not None:
            days_held = max(1, (pos['exit_idx'] or pos['open_idx']) - pos['open_idx'])
            pos['pnl'] = (pos['ret'] or 0)*notional/100 - notional*FUND_FEE_DAY*days_held
            pos['days_held'] = days_held
            closed.append(pos)
            # v1.7.21(🟠2): 不立即移出 active——由 sweep 在 exit_date 到期时释放，
            # 保持同标不重叠占位与 sector 占用直到真实退出日（修复持有期内新候选绕过 skip）
    # 数据末端仍未退出的 = 真在仓
    open_pos = [p for p in active if p['exit_date'] is None]
    for p in open_pos:
        lc = closes.get(p['sym'], 0)
        p['live_ret'] = (lc/p['anchor']-1)*100 if lc and p['anchor'] else 0.0

    realized = [p['pnl'] for p in closed]
    win = sum(1 for x in realized if x > 0)
    cum = sum(realized)

    # ---- v1.7.44 块三 T6: tail15_scale 只读指标（尾笔=已平 ret≥15%，scale=Σ(w·r)/Σr，w=notional/100；wf9_lib.tail_pack 同口径）----
    def tail15_scale():
        rows = sorted((p for p in closed if p.get('ret') is not None),
                      key=lambda p: (p.get('day') or '', p.get('sym') or ''))
        idxs = [k for k, p in enumerate(rows) if p['ret'] >= 15.0]
        raw = sum(rows[k]['ret'] for k in idxs)
        wt = sum((rows[k]['notional'] / 100.0) * rows[k]['ret'] for k in idxs)
        n_tail = len(idxs)
        if not idxs or raw <= 0:
            return None, n_tail, raw
        return wt / raw, n_tail, raw
    t15, t15_n, t15_raw = tail15_scale()
    if t15 is None:
        tail15_line = "尾部缩放比(T6·只读): 样本不足（无 ret≥15% 已平尾笔）"
        tail15_html = "尾部缩放比(T6·只读): 样本不足（无 ret≥15% 已平尾笔）"
    else:
        _t15_s = f"尾部缩放比(T6·只读): tail15_scale={t15:.4f}（尾笔{t15_n}·尾Σr {t15_raw:.1f}%）"
        if t15 < 0.90:    # 单档 6% 引擎结构性≈0.05~0.06，恒<0.90——仅披露，触发签字对象为研究侧变体（T1_T7_rerun CEO 裁决3）
            tail15_line = _t15_s + " 🟥 <0.90｜变体间对比指标·单档引擎结构性偏低·仅披露非缺陷"
            tail15_html = (_t15_s + ' <span style="color:#ff3b30">🟥 &lt;0.90</span>'
                           "｜变体间对比指标·单档引擎结构性偏低·仅披露非缺陷")
        else:
            tail15_line = _t15_s
            tail15_html = _t15_s

    # ---- v1.7.44 块三 T3: 影子覆盖率（页脚只读行；字段已逐笔落在候选上）----
    _n_cand = len(cands_all)
    _n_fill = sum(1 for c in cands_all if c.get('filled_weight'))
    cov_line = (f"影子观测(T3): 候选 {_n_cand}｜影记 {_n_cand}｜覆盖率 "
                f"{(_n_cand and 100.0) or 0:.1f}%｜影记成交 {_n_fill}")

    # ---- v1.7.44 块三 T7: 实时敞口行（取 portfolio_admit 既有输入，零新逻辑）----
    _gross_now = sum(p['notional'] for p in open_pos)
    expo_line = (f"📊 敞口: 并发 {len(open_pos)}/{CAP_CONCURRENCY} ｜ 总敞口 {_gross_now:.1f}%/{CAP_GROSS * 100:.0f}%"
                 f" ｜ 当日新开 {day_new.get(now_day, 0)}/{CAP_DAY_NEW}")

    # ---- v1.7.39: 60 交易日观察期监控指标（页脚输出）——条款：单日DD>20%→次日降杠杆50% / PF<1.0→停机 / 期满 PF≥1.3→转正 ----
    def obs_metrics():
        """单日DD=按 exit_date 聚合已平盈亏的逐日净值单日最大跌幅；PF=总盈利/总亏损（已平，含资金费）；
        观察交易日数=首仓开仓日→now_day 的日历交易日跨度（封顶 60 显示）。"""
        day_pnl = {}
        for p in closed:
            _d = p.get('exit_date')
            if _d: day_pnl[_d] = day_pnl.get(_d, 0.0) + p['pnl']
        prev_eq, max_dd = 100.0, 0.0
        for _d in sorted(day_pnl):
            eq = prev_eq + day_pnl[_d]
            if prev_eq > 0: max_dd = max(max_dd, max(0.0, (prev_eq - eq) / prev_eq))
            prev_eq = eq
        _gw = sum(x for x in realized if x > 0)
        _gl = -sum(x for x in realized if x < 0)
        pf = (_gw / _gl) if _gl > 1e-12 else None
        _first = min((p['day'] for p in closed + open_pos), default=None)
        n_obs = (len([d for d in cal if _first <= d <= now_day]) - 1) if (_first and cal) else 0
        return max(0, n_obs), max_dd, pf
    obs_days, obs_dd, obs_pf = obs_metrics()
    _pf_s = '—' if obs_pf is None else ('∞' if obs_pf > 100 else f"{obs_pf:.2f}")
    obs_line = (f"观察期监控（60交易日条款·中间态单档）: 交易日 {min(obs_days, 60)}/60 | "
                f"单日最大DD {obs_dd:.1%}（>20%→次日降杠杆50%）| PF {_pf_s}（<1.0→停机；期满≥1.3→转正）")

    # ---- 全历史战绩（诚实口径：全部候选含已平，v1.7.22 横幅主口径）----
    _all_rets = np.array([c['ret'] for cs in sym_cands.values() for c in cs if c.get('ret') is not None]) / 100.0
    hist_n = int(len(_all_rets))
    hist_win = float((_all_rets > 0).mean() * 100) if hist_n else 0.0
    hist_avg = float(_all_rets.mean() * 100) if hist_n else 0.0
    hist_med = float(np.median(_all_rets) * 100) if hist_n else 0.0

    # ---- v1.7.23: E6 影子观察统计（标签≠推荐强度）——只用 ret 非 None 的已平候选，n=0 的桶略去 ----
    def _shadow_stats():
        buckets = {'周一干净桶': [], 'G路径': []}
        for cs in sym_cands.values():
            for c in cs:
                if c.get('ret') is None:
                    continue
                if c.get('mon_clean'):
                    buckets['周一干净桶'].append(c['ret'])
                if c.get('src') == 'G':
                    buckets['G路径'].append(c['ret'])
        parts = []
        for _name, _rets in buckets.items():
            if not _rets:
                continue
            _arr = np.array(_rets)
            parts.append(f"{_name} n={len(_arr)} 胜率{(_arr > 0).mean()*100:.0f}% 均值{_arr.mean():+.2f}%")
        return ("影子观察（标签≠推荐强度）: " + " ｜ ".join(parts)) if parts else ""
    shadow_line = _shadow_stats()

    # ---- 展示 ----
    hit = {s: v for s, v in sigs.items() if v}
    warn = sum(1 for v in hit.values() if v['warn'])
    rank = {'⚠️': 0, '·': 9}   # v1.7.42 起 grade 恒 '·'（🥈废除），🥇/🥈/🥉 死键随十六轮清除
    rows = []
    for sym in sorted(hit):
        x = hit[sym]
        if is_fuse_ending(x):
            continue    # v1.7.43 丙4: 保险丝结局卡不入主列表（双保险——EXPIRE_LINGER=0 主路径已在 _sig_post 出清，此处防御 hit 直通）；结局可见性由 📋出清面板承接
        # v1.7.31(b): 「·」级无警示卡暂不在此过滤——若顶替了存活旧卡（血缘段判 held_old）则沉底保留
        #（用户拍板方案A，ORCL 案例：旧卡 10-09 活卡被 · 级新卡顶替+新卡被过滤=整页消失）；无存活旧卡的仍隐藏（下方剔除）。
        cands = sym_cands.get(sym) or []
        cd = next((cc for cc in cands if cc['day'] == x['day']), None)
        lay = layer_prev(x['day'])
        tier = tier_of(x['grade'], lay, x['env'])
        score = score_of(x['grade'], lay, x['env'], x['day'], mon_clean=x.get('mon_clean', False))    # v1.7.23: E1 传周一干净桶旗标
        rows.append((rank.get('⚠️' if x['warn'] else x['grade'], 9), sym, x, cd, lay, tier, score))
    # v1.7.31(a): 期满红旗升权（用户拍板 2026-10-14「提升期满的权重新信号给他让路带一天」）——
    # 被新信号顶替的 brk_expire 卡同屏展示一天（归🏁出清组沉底，不占⚠️位）；
    # 期满次日引擎 lag≥4 自动出清，恢复正常「每标的仅最新一条」顶替。纯展示层。
    for sym, sbd in sig_by_days.items():
        x_cur = hit.get(sym)
        for _d, _x in sbd.items():
            if _x.get('brk_expire') and not (x_cur and x_cur.get('day') == _d):
                if is_fuse_ending(_x):
                    continue    # v1.7.43 丙4: 保险丝结局卡下架主列表（与 v1.7.37 期满卡同路径的渲染过滤——期满卡保持 v1.7.37 现状不回退）；结局可见性由 📋出清面板承接（文本+HTML 双通道）
                _cands = sym_cands.get(sym) or []
                _cd = next((cc for cc in _cands if cc['day'] == _d), None)
                _lay = layer_prev(_d)
                rows.append((rank.get(_x['grade'], 9), sym, _x, _cd, _lay,
                             tier_of(_x['grade'], _lay, _x.get('env', '')),
                             score_of(_x['grade'], _lay, _x.get('env', ''), _x['day'], mon_clean=_x.get('mon_clean', False))))
    _rk = risk_zone_keys(rows)    # v1.7.43 乙: ⚠️固定风控区成员（上限3张，破位日期新→旧）
    rows.sort(key=lambda r: row_sort_key(r, closes, _rk))    # v1.7.23: E2 多键排序锁死（⚠️置顶→状态分组→评分→盈亏比→新鲜度→字母序）
    # v1.7.29(b): 顶替明示——展示信号顶替同标旧候选时必须可见（血缘红线）。
    # v1.7.45+16轮: 用户砍顶替血缘显示与 supersede 字段生成 → 本循环仅保留 held_old（动词降级判定，判定语义不受影响）。
    for _r in rows:
        _sym, _x = _r[1], _r[2]
        _olds = sorted([cc for cc in (sym_cands.get(_sym) or []) if cc['day'] < _x['day']], key=lambda c: c['day'])
        if _olds:
            _o = _olds[-1]
            _sig0 = (sig_by_days.get(_sym) or {}).get(_o['day'])   # 旧卡展示层状态（与卡面同源，含出清卡）
            if not _o.get('exit_date') and _sig0 is not None \
                    and not (_sig0.get('brk_expire') or _sig0.get('killed')) \
                    and '观察中' not in (_sig0.get('warn') or '') \
                    and not (_sig0.get('dead') or _sig0.get('flag')):
                _x['held_old'] = True   # 旧卡在仓 → 用户可能仍持有，新卡动词降级为在册监控（德鲁肯米勒裁决：旧仓存活期禁出加仓暗示）
    # v1.7.42: 原「·级无警示卡剔除规则」（v1.7.31b）随🥈分级废除停用（agent-7f2a447d）——
    # 推荐口径改为「通过全部禁入门槛的信号全集」，全信号 ·级，若保留剔除则整页清空；
    # 禁入兜底由 tier_of 孤星门槛+沉底展示承接，⚠️/血缘/卡龄通道不受影响。
    _rk = risk_zone_keys(rows)    # v1.7.43 乙: 重选风控区（血缘 supersede/held_old 已就位）
    rows.sort(key=lambda r: row_sort_key(r, closes, _rk))    # v1.7.31(b): 重排（血缘 supersede/held_old 已就位）

    tz8 = timezone(timedelta(hours=8))
    up_ts = datetime.now(tz8).strftime('%Y-%m-%d %H:%M')
    today_lay = lay_of_latest()
    banner = {'孤星': '⛔ 今日孤星市况·不适合抄底，仅观察，勿开新仓',
              '批量': '🟢 今日批量出清市况·β修复窗口，优选评分最高者',
              '常规': '市况：常规日，按评分与档位正常筛选'}[today_lay]

    # ---- v1.7.44: 横幅区定稿 10 行（deploy_ui_verdict §四逐字；gate 行=块一三态横幅，KX_GATE_ENABLED=0 时不显示）----
    lines = []
    if gate_line:
        lines.append(gate_line)    # 块一: 三态横幅（文本通道；W3 黄标/W4 冻结文案随 gate_line）
    lines += [f"丁导K线交易系统 · v1.7.45（引擎v{__version__}） · {up_ts} 北京时间更新（每日 00:35/04:35/08:35/12:35/16:35/20:35 六轮）",
             expo_line,    # 块三 T7
             f"市况: {banner} ｜ 扫描{len(pool)} · 在册{len(hit)} · ⚠️{warn}",
             # v1.7.45: 「页面读法」「挂单」两行随卡面重构砍除（引用的保险丝/状态词已不上卡面=过时，用户原话①）
             "约束: 并发≤8·单票≤10%·总敞口≤50%·杠杆≤5×·止损距离>8%放弃·同日≤3只·孤星日禁入·周六不入册",
             "📌 每标的只显示最新一条信号 ｜ 极端行情任何止损价都可能被跳空击穿",
             "=" * 46]
    if shadow_line:    # v1.7.23: E6 影子观察统计行插在「约束」行之后
        _ci = next(i for i, l in enumerate(lines) if l.startswith('约束'))
        lines.insert(_ci + 1, shadow_line)
    if closed:
        sample_note = '' if len(closed) >= 100 else '（样本不足，<100笔不构成有效性证据）'
        lines.append(f"💼 模拟账户（规则化全量模拟，无幸存者偏差）: 已平 {len(closed)} 笔 | "
                     f"胜率 {win/len(closed):.0%} | 单笔均值 {np.mean(realized):+.3f}% | 累计 {cum:+.2f}%（含资金费）{sample_note}")
    else:
        lines.append("💼 模拟账户：暂无已平仓位（合格信号出现后自动开仓跟踪）")
    for p in sorted(open_pos, key=lambda x: -x['score']):
        _plc = closes.get(p['sym'], 0)
        lines.append(f"  ▶ 在仓 {p['sym']} 锚{p['anchor']:.2f} 止损{p['stop']:.2f} 开仓{p['day'][5:]} 现价{_plc if _plc else '—'}")    # v1.7.45: 现浮/仓位杠杆砍（与卡面同口径）
    lines.append("=" * 46)
    for _, sym, x, cd, lay, tier, score in rows:
        # v1.7.45/16轮: 文本页卡行与箱体卡同口径——砍 保险丝/评分/仓位杠杆/状态词/卡龄/⚡共振/顶替血缘/过宽放弃行，
        # 保留=单字前缀(⛔⚠️🏁✅)+标的+动词+日期+锚+信号区+轨底(收盘止损线)+死锚+现价；└行仅存 禁入 短标
        price_s = f"{x['anchor']:.2f}" if x['anchor'] < 1000 else f"{x['anchor']:.1f}"
        _verb = '在册监控' if x.get('held_old') else '买入'   # v1.7.29: 旧卡在仓时新卡动词降级（德鲁肯米勒：旧仓存活期禁出加仓暗示）
        _lc = closes.get(sym, 0)
        _pre = ('⛔' if x.get('brk_expire') else '⚠️' if x['warn'] else '🏁' if x.get('flag') else '✅' if x.get('dead') else '')
        _se = x.get('stop_eff', '—')
        _se_s = f"{_se:.2f}" if isinstance(_se, (int, float)) else '—'
        _dd = x.get('dead_px')
        _dd_s = f"{_dd:.2f}" if isinstance(_dd, (int, float)) else '—'
        lines.append(f"{_pre}{sym} {_verb} {x['day']} 锚{price_s} 信号区{x['zone']} "
                     f"轨底{_se_s} 死锚{_dd_s} 现价{_lc if _lc else '—'}")
        if tier == '禁入':
            lines.append("   └ 禁入")    # v1.7.45: 禁入长文砍，存短标（说明归使用说明）
    if not rows:
        lines.append("（当前无在册信号）")
    _recent_exits = collect_recent_exits(sym_cands)   # v1.7.33: 📋 近日出清面板（纯展示，页面尾部；计算一次双通道复用）
    lines.extend(exits_panel_text(_recent_exits, total_closed=len(closed)))   # v1.7.43 丙1/丙3: 全量在册不截断+当日/累计计数+最近一单摘要
    lines.append(obs_line)    # v1.7.39: 60交易日观察期监控指标（页脚输出）
    lines.append(tail15_line)    # v1.7.44 块三 T6: 尾部缩放比只读行（双通道）
    lines.append(cov_line)    # v1.7.44 块三 T3: 影子覆盖率只读行（双通道）
    lines.append(f"拦截统计: " + " ".join(f"{k}{v}" for k, v in skip_n.most_common()) if skip_n else "")
    text = "\n".join(lines) + "\n"
    text += ("\n⚠️ 以上为历史统计规则输出，非投资建议；仓位与杠杆自定，极端行情下任何止损价都可能被跳空击穿。\n"
             "⚠️ 模拟成交假设 T+1 开盘价、无滑点与流动性约束；破位统一容忍口径（首破观察2天，收复信号区上沿=复活）；展示与模拟同口径(v1.7.14)。\n")
    print(f"[replica] {now_day} 状态页生成: {len(hit)} 标的 / {len(rows)} 推荐 / {len(text.encode())//1024}KB")

    # ---- v1.7.9 卡片版 view.html（渲染层，判定与文本页同源）----
    html_text = render_html(rows, closes, open_pos, {
        'ver': __version__, 'up_ts': up_ts, 'market_banner': banner,
        'gate_banner': gate_line if GATE_ENABLED else '', 'gate_border': gate_border,    # v1.7.44 块一: 牛闸横幅双通道（红/绿描边）；gate=0 不显示
        'expo_line': expo_line,    # v1.7.44 块三 T7
        'pool_n': len(pool), 'hit_n': len(hit), 'warn': warn,
        'hist_n': hist_n, 'hist_win': hist_win, 'hist_avg': hist_avg, 'hist_med': hist_med,
        'n_open': len(open_pos), 'n_closed': len(closed),
        'shadow': shadow_line,    # v1.7.23: E6 影子观察统计行送 HTML 页脚
        'tail15_html': tail15_html,    # v1.7.44 块三 T6: 尾部缩放比送 HTML 页脚（红字自带 span）
        'cov': cov_line,    # v1.7.44 块三 T3: 影子覆盖率送 HTML 页脚
        'obs': obs_line,    # v1.7.39: 60交易日观察期监控指标送 HTML 页脚
        'exits_total_closed': len(closed),    # v1.7.43 丙3: 累计出清计数（HTML 面板摘要）
        'recent_exits': _recent_exits,    # v1.7.33: 📋 近日出清面板数据（纯展示，复用文本页同一次计算）
        'win': win if closed else 0, 'avg': float(np.mean(realized)) if realized else 0.0,
        'cum': cum})
    print(f"[replica] view.html 卡片版生成: {len(rows)} 信号卡 / {len(open_pos)} 模拟仓卡 / {len(html_text.encode())//1024}KB")

    if os.environ.get('KX_LOCAL_OUT'):    # v1.7.44 块一: 本地部署产出（不上传；gate_freeze.json 已在 W2 落盘同目录）
        _lo = os.environ['KX_LOCAL_OUT']; os.makedirs(_lo, exist_ok=True)
        open(os.path.join(_lo, 'live.txt'), 'w', encoding='utf-8').write(text)
        open(os.path.join(_lo, 'view.html'), 'w', encoding='utf-8').write(html_text)
        print(f"[replica] 本地输出: {_lo}/live.txt view.html")

    if tok:
        hdr = {"Authorization": f"Bearer {tok}"}
        hhmm = datetime.now(tz8).strftime('%m%d-%H%M')
        for fname in (f"status/daily-{hhmm}.txt", "status/view.html", "status/latest.txt", "status/live.txt"):
            try:
                g = requests.get(f"{GH_API}/{fname}", headers=hdr, timeout=15)
                payload = html_text if fname == "status/view.html" else text
                data = {"message": f"replica status {now_day}", "content": base64.b64encode(payload.encode()).decode()}
                if g.status_code == 200 and g.json().get("sha"): data["sha"] = g.json()["sha"]
                p = requests.put(f"{GH_API}/{fname}", headers=hdr, json=data, timeout=30)
                print(f"[replica] 上传 {fname}: {'OK' if p.status_code in (200, 201) else f'HTTP {p.status_code}'}")
            except Exception as e:
                print(f"[replica] 上传 {fname} 异常: {e}")
        time.sleep(15)   # ★ 上传完等 GitHub 提交传播，再 purge 防竞态钉死旧缓存（评审 #10）
        # ---- 缓存交付：四通道统一 purge + 新鲜度自检（SRE 方案 A，2026-10-11）----
        # 根因：jsDelivr 对高频更新的固定文件名，purge 可能被节点钉住/限流；
        # 对策：不再依赖单通道，四通道全刷，并回读校验，哪个通道旧一目了然。
        mirrors = ('cdn.jsdelivr.net', 'fastly.jsdelivr.net',
                   'gcore.jsdelivr.net', 'testingcf.jsdelivr.net')
        # ⚠️ purge 按路径限流（实测 throttlingReset≈600s）：每轮每路径只请求一次，
        #    不做镜像预热 GET——多发只会打满配额让刷新彻底失效（2026-10-11 实测教训）
        for fname in ('status/live.txt', 'status/latest.txt', 'status/view.html'):
            try:
                p = requests.get(f"https://purge.jsdelivr.net/gh/Llng125256/kx-combo@main/{fname}", timeout=15)
                th = 'throttled' if 'throttled' in p.text else 'ok'
                print(f"[replica] purge {fname}: {th}")
            except Exception:
                pass
        expect = f"v{__version__}"
        state = {h: '旧' for h in mirrors}
        for attempt in range(3):        # purge 传播需要时间：三轮轮询，最长约 90 秒判定
            time.sleep(25)
            for host in mirrors:
                if state[host] == '新':
                    continue
                try:
                    r = requests.get(f"https://{host}/gh/Llng125256/kx-combo@main/status/live.txt", timeout=15)
                    state[host] = '新' if expect in r.text[:80] else ('旧' if r.status_code == 200 else '异常')
                except Exception:
                    state[host] = '超时'
            if all(v == '新' for v in state.values()):
                break
        print(f"[replica] 缓存校验: " + " ".join(f"{h.split('.')[0]}={v}" for h, v in state.items())
              + f"（目标版本 {expect}，旧=该通道 CDN 缓存未刷新，页面首行时间戳为准）")
        # 可选直达通道：设置 KX_WECHAT_WEBHOOK 即推精简版到企微，绕过 CDN 缓存
        wh = os.environ.get("KX_WECHAT_WEBHOOK", "")
        if wh:
            push_summary(lines, wh, f"daily-{hhmm}.txt")
    return 0


if __name__ == "__main__":
    sys.exit(main())
