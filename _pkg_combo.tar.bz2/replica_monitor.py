#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""K线导演·复刻监控（自研引擎，纯文本状态页）

【v1.1 2026-10-11】破位/收复状态机：触及后逐日复检——收盘破区间→⚠️破位观察(2天)；收盘收复→重跑分级复活；满2天未收复或二次破位→删除。
  【v1.0 2026-10-10】基于复刻引擎的每日监控：
  · Lucy 信号 = 肯特纳双轨触及（支撑线 EMA10−ATR14 / 阻力线 EMA10+ATR14）
  · 金银铜牌质量分级（1082 事件回测定版）：
      🥇 CCI<-150 + 收盘位>0.3（67%/+4.28%）  🥈 长影线>50%（62%）
      🥉 超跌/超涨>10% + 收盘位达标（62%）    ⚠️ 爆量3倍+收盘瘫脚=破位警告
  · 新鲜度：信号距最新交易日 ≤15 天（体积裁剪：超龄全丢，每标的最多 3 条）
  · 先不推送企微，只产出纯文本状态页上传仓库 status/（latest + 当日存档）
  · 无状态纯函数：每轮全量重算，无跨轮依赖（后续加推送再上状态机）
"""
from __future__ import annotations

import base64
import json
import logging
import math
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

import requests
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kx_client import KxClient  # noqa: E402

__version__ = "1.1"
GH_API = "https://api.github.com/repos/Llng125256/kx-combo/contents"
FRESH_DAYS = 15          # 信号新鲜度上限（体积裁剪）
MAX_PER_SYM = 1          # 每标的最多显示条数
WORKERS = 16
BARS = 150


def ema(x, n):
    a = 2/(n+1); out = np.full(len(x), np.nan); out[0] = x[0]
    for i in range(1, len(x)): out[i] = a*x[i] + (1-a)*out[i-1]
    return out


def analyse(sym, bars, now_day):
    """单标的：返回 15 天内触发的信号列表（含分级）。"""
    if len(bars) < 40:
        return []
    dates = [str(b['time'])[:10] for b in bars]
    high = np.array([float(b['high']) for b in bars])
    low = np.array([float(b['low']) for b in bars])
    close = np.array([float(b['close']) for b in bars])
    openp = np.array([float(b['open']) for b in bars])
    vol = np.array([float(b.get('volume') or 0) for b in bars])
    n = len(bars)
    ema10 = ema(close, 10)
    tr = np.maximum(high[1:], close[:-1]) - np.minimum(low[1:], close[:-1])
    tr = np.concatenate([[high[0]-low[0]], tr])
    atr = np.full(n, np.nan)
    for i in range(14, n): atr[i] = tr[i-14:i].mean()
    # CCI20
    tp = (high+low+close)/3
    cci = np.full(n, np.nan)
    for i in range(19, n):
        w = tp[i-19:i+1]; m = w.mean(); md = np.abs(w-m).mean()
        cci[i] = (tp[i]-m)/(0.015*md+1e-9)
    cutoff = n - FRESH_DAYS
    sigs = []
    last = -99
    for side, touch, band_of in (('buy', lambda i: low[i] <= ema10[i]-atr[i], lambda i: ema10[i]-atr[i]),
                                 ('sell', lambda i: high[i] >= ema10[i]+atr[i], lambda i: ema10[i]+atr[i])):
        last = -99
        for i in range(20, n-1):
            if np.isnan(ema10[i]) or np.isnan(atr[i]): continue
            if not touch(i) or i - last <= 2: continue
            rng_i = high[i]-low[i]+1e-9
            cp_i = (close[i]-low[i])/rng_i
            if cp_i <= 0.3: continue                     # ★ 企稳确认：触及日收盘瘫脚的不算（回测破位率砍半）
            last = i
            if i < cutoff: continue                      # ★ 体积裁剪：15 天外直接丢
            rng = high[i]-low[i]+1e-9
            cp = (close[i]-low[i])/rng                   # 收盘位置
            shadow = ((np.minimum(close[i], openp[i])-low[i]) if side == 'buy'
                      else (high[i]-np.maximum(close[i], openp[i])))/rng
            vr = vol[i]/(vol[max(0, i-10):i].mean()+1e-9)
            drop = (close[i]/close[max(0, i-10)]-1)*100  # 前10日涨跌
            c = cci[i]
            if side == 'buy':
                grade = ('🥇' if (c < -150 and cp > 0.3) else
                         '🥈' if shadow > 0.5 else
                         '🥉' if (drop < -10 and cp > 0.3) else '·')
                lo_i, hi_i = low[i], band_of(i)          # 区间数值（破位/收复判定用）
                zone = f"[{lo_i:.2f}~{hi_i:.2f}]"
            else:
                new_hi = high[i] >= high[max(0, i-20):i+1].max() - 1e-9   # 创20日新高
                grade = ('🥈' if (shadow > 0.5 or new_hi) else
                         '🥉' if (drop > 10 and cp < 0.7) else '·')
                lo_i, hi_i = band_of(i), high[i]
                zone = f"[{lo_i:.2f}~{hi_i:.2f}]"
            warn = ' ⚠️爆量瘫脚警告' if (vr > 3 and cp < 0.3) else ''
            sig = {'day': dates[i], 'side': side, 'grade': grade,
                   'price': openp[i+1] if i+1 < n else close[i],
                   'zone': zone, 'close': close[i], 'cci': c, 'warn': warn, 'note': ''}

            # ---- 破位/收复状态机（触及后逐日复检，BNC 案例补丁 v1.1）----
            state, breaks, brk_j, rec_j = 'live', 0, None, None
            killed = False
            for j in range(i+1, n):
                below = close[j] < lo_i if side == 'buy' else close[j] > hi_i   # 收盘跌破区间
                above = close[j] > hi_i if side == 'buy' else close[j] < lo_i   # 收盘收复区间上/下沿
                if state == 'live' and below:
                    breaks += 1
                    if breaks >= 2:                 # 收复后再破位 → 反复横跳，直接踢出
                        killed = True; break
                    state, brk_j = 'broken', j
                elif state == 'broken' and above:
                    state, rec_j = 'recovered', j   # 收盘站回区间 → 判定复活
            if killed:                              # last=i 已生效，直接丢弃
                continue
            if state == 'broken':
                if (n-1) - brk_j > 2:               # 破位观察满2天后仍未收复 → 从页面删除
                    continue
                sig['warn'] = (sig['warn'] + f' ⚠️破位{dates[brk_j][5:]}观察中').strip()
            elif state == 'recovered':
                # 复活：用收复当根重跑分级（够哪级恢复哪级）
                rng_r = high[rec_j]-low[rec_j]+1e-9
                cp_r = (close[rec_j]-low[rec_j])/rng_r
                sh_r = ((np.minimum(close[rec_j], openp[rec_j])-low[rec_j]) if side == 'buy'
                        else (high[rec_j]-np.maximum(close[rec_j], openp[rec_j])))/rng_r
                dr_r = (close[rec_j]/close[max(0, rec_j-10)]-1)*100
                if side == 'buy':
                    g2 = ('🥇' if (cci[rec_j] < -150 and cp_r > 0.3) else
                          '🥈' if sh_r > 0.5 else
                          '🥉' if (dr_r < -10 and cp_r > 0.3) else '·')
                else:
                    nh_r = high[rec_j] >= high[max(0, rec_j-20):rec_j+1].max() - 1e-9
                    g2 = ('🥈' if (sh_r > 0.5 or nh_r) else
                          '🥉' if (dr_r > 10 and cp_r < 0.7) else '·')
                if g2 == '·':                       # 收复但不够任何牌级 → 不再显示
                    continue
                sig['grade'] = g2
                sig['cci'] = cci[rec_j]
                sig['note'] = f"（{dates[rec_j][5:]}已收复，恢复{g2}）"
            sigs.append(sig)
    sigs.sort(key=lambda s: s['day'], reverse=True)
    return sigs[:MAX_PER_SYM], close[-1]


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    print(f"[replica] 包代码版本 v{__version__}")
    tok = os.environ.get("KX_GH_TOKEN", "")
    cli = KxClient(signal_age_days=16, timeout=30, retries=3, retry_delay=2.0)
    pool = sorted({it['symbol'] for it in (cli.get_signals('futures', '1d', 1, 500).get('items') or [])
                   if (it.get('underlying_type') or '') == 'EQUITY' and it.get('symbol')})

    def one(sym):
        try:
            d = cli.get_kline(sym, 'futures', '1d', BARS)
            sigs, last_close = analyse(sym, d.get('bars') or [], None)
            return sym, sigs, last_close
        except Exception as e:
            return sym, [{'day': 'ERR', 'side': 'err', 'grade': '', 'price': 0, 'zone': str(e)[:50], 'close': 0, 'cci': 0, 'warn': ''}], 0

    with ThreadPoolExecutor(WORKERS) as ex:
        rows = {sym: (sigs, lc) for sym, sigs, lc in ex.map(one, pool)}

    now_day = datetime.now(timezone.utc).strftime('%Y-%m-%d')
    now_dt = datetime.strptime(now_day, '%Y-%m-%d')
    closes = {s: lc for s, (v, lc) in rows.items()}
    hit = {s: v for s, (v, lc) in rows.items() if v and v[0]['day'] != 'ERR'}
    n_buy = sum(1 for v in hit.values() for x in v if x['side'] == 'buy')
    n_sell = sum(1 for v in hit.values() for x in v if x['side'] == 'sell')
    g1 = sum(1 for v in hit.values() for x in v if x['grade'] == '🥇')
    warn = sum(1 for v in hit.values() for x in v if x['warn'])

    rank = {'⚠️': 0, '🥇': 1, '🥈': 2, '🥉': 3, '·': 9}
    side_cn = {'buy': '买入', 'sell': '卖出'}
    rows = []
    for sym in sorted(hit):
        v = hit[sym]
        if v and v[0]['day'] == 'ERR': continue
        v = [x for x in v if x['grade'] != '·' or x['warn']]   # 只显示有牌/警告信号
        for x in v:
            price_s = f"{x['price']:.2f}" if x['price'] < 1000 else f"{x['price']:.1f}"
            g = '⚠️' if x['warn'] else x['grade']
            rows.append((rank.get(g, 9), sym, x, g, price_s))
    rows.sort(key=lambda r: (r[0], r[1]))
    # ---- 信号收益追踪（前向实盘验证）----
    track = {"signals": []}
    hdr8 = {"Authorization": f"Bearer {tok}"} if tok else None
    if tok:
        try:
            g = requests.get(f"{GH_API}/status/track.json", headers=hdr8, timeout=15)
            if g.status_code == 200:
                track = json.loads(base64.b64decode(g.json()['content']))
        except Exception as e:
            print(f"[replica] 追踪表读取失败: {e}")
    existing = {(s['sym'], s['side'], s['day']): s for s in track.get('signals', [])}
    for sym, sigs in hit.items():
        lc = closes.get(sym, 0)
        for x in sigs:
            if x['day'] == 'ERR': continue
            key = (sym, x['side'], x['day'])
            rec = existing.get(key)
            if rec is None:
                rec = {'sym': sym, 'side': x['side'], 'day': x['day'],
                       'price': round(x['price'], 4), 'grade': x['grade']}
                track['signals'].append(rec); existing[key] = rec
            try:
                days = (now_dt - datetime.strptime(x['day'], '%Y-%m-%d')).days
            except ValueError:
                days = 0
            if lc:
                rec['live'] = round(((lc/x['price']-1) if x['side'] == 'buy' else (x['price']-lc)/x['price'])*100, 2)
            if days >= 5 and 'settle5' not in rec and lc: rec['settle5'] = rec['live']
            if days >= 10 and 'settle10' not in rec and lc: rec['settle10'] = rec['live']
            rec['days'] = days
    # 体积裁剪：10日已结算且超25天的移出
    track['signals'] = [s for s in track['signals']
                        if not (s.get('settle10') is not None and s.get('days', 99) > 25)]
    track['updated'] = now_day

    # 追踪统计（按牌级，只算已结算的）
    stats_lines = []
    settled = [s for s in track['signals'] if s.get('settle5') is not None]
    stats_lines.append(f"📊 信号追踪（前向实盘，{track['updated']} 更新）: 在册 {len(track['signals'])} 个")
    for gname in ('🥇', '🥈', '🥉', '⚠️'):
        grp = [s for s in settled if s.get('grade') == gname]
        if len(grp) < 3:
            stats_lines.append(f"  {gname} 5日结算: {len(grp)} 个（样本积累中）"); continue
        w5 = sum(1 for s in grp if s['settle5'] > 0) / len(grp)
        a5 = sum(s['settle5'] for s in grp) / len(grp)
        ten = [s for s in grp if s.get('settle10') is not None]
        s10 = f" | 10日 {sum(1 for s in ten if s['settle10']>0)/len(ten):.0%}/{sum(s['settle10'] for s in ten)/len(ten):+.2f}%" if len(ten) >= 3 else ''
        stats_lines.append(f"  {gname} 5日结算 {len(grp)} 个: 胜率 {w5:.0%} 均值 {a5:+.2f}%{s10}")
    if not settled:
        stats_lines.append("  （5日结算样本积累中，信号出现后第5天自动入账）")

    tz8 = timezone(timedelta(hours=8))
    up_ts = datetime.now(tz8).strftime('%Y-%m-%d %H:%M')
    lines = [f"【K线复刻监控 · 自研引擎 v{__version__}】{now_day} (UTC)",
             f"⏱️ 本次更新: {up_ts} 北京时间（每天 05/11/17/23 点更新，此时间变了=发版正常）",
             f"扫描 {len(pool)} 标的 | 15天内有信号: {len(hit)} 个 | 买入 {n_buy} / 卖出 {n_sell} | 🥇金牌 {g1} | ⚠️破位警告 {warn}",
             "=" * 46] + stats_lines + ["=" * 46]
    live_map = {(s['sym'], s['side'], s['day']): s.get('live') for s in track['signals']}
    for _, sym, x, g, price_s in rows:
        lv = live_map.get((sym, x['side'], x['day']))
        lv_s = f" 现收益{lv:+.1f}%" if lv is not None else ""
        lines.append(f"{g} {sym} {side_cn[x['side']]} {x['day']} 锚{price_s} 支撑阻力区{x['zone']} CCI{x['cci']:.0f}{lv_s}{x['warn']}{x.get('note', '')}")
    if not rows:
        lines.append("（15 天内无触发信号）")
    text = "\n".join(lines) + "\n"
    print(f"[replica] {now_day} 状态页生成: {len(hit)} 标的 / {n_buy}b+{n_sell}s / {len(text.encode())//1024}KB")

    if tok:
        hdr = {"Authorization": f"Bearer {tok}"}
        tz8 = timezone(timedelta(hours=8))   # 北京时间命名，用户可预测
        hhmm = datetime.now(tz8).strftime('%m%d-%H%M')
        for fname in (f"status/daily-{hhmm}.txt", "status/view.html", "status/latest.txt"):
            try:
                g = requests.get(f"{GH_API}/{fname}", headers=hdr, timeout=15)
                data = {"message": f"replica status {now_day}", "content": base64.b64encode(text.encode()).decode()}
                if g.status_code == 200 and g.json().get("sha"): data["sha"] = g.json()["sha"]
                p = requests.put(f"{GH_API}/{fname}", headers=hdr, json=data, timeout=30)
                ok = p.status_code in (200, 201)
                print(f"[replica] 上传 {fname}: {'OK' if ok else f'HTTP {p.status_code}'}")
            except Exception as e:
                print(f"[replica] 上传 {fname} 异常: {e}")
        if tok:
            try:
                g = requests.get(f"{GH_API}/status/track.json", headers=hdr, timeout=15)
                tdata = {"message": f"track {now_day}",
                         "content": base64.b64encode(json.dumps(track, ensure_ascii=False).encode()).decode()}
                if g.status_code == 200 and g.json().get("sha"): tdata["sha"] = g.json()["sha"]
                tp = requests.put(f"{GH_API}/status/track.json", headers=hdr, json=tdata, timeout=30)
                print(f"[replica] 追踪表写回: {'OK' if tp.status_code in (200,201) else f'HTTP {tp.status_code}'} ({len(track['signals'])} 条)")
            except Exception as e:
                print(f"[replica] 追踪表写回异常: {e}")
        try:
            requests.get("https://purge.jsdelivr.net/gh/Llng125256/kx-combo@main/status/latest.txt", timeout=15)
            print("[replica] jsDelivr 缓存已刷新")
        except Exception:
            pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
