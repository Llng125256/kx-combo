#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""K线导演·复刻监控（自研引擎，纯文本状态页）

【v1.6 2026-10-11】卖出侧并入买入行（用户拍板）：
  · 卖出独立信号砍掉（身份不自洽：止盈 or 做空无法判定，美股做空逆势）
  · ✅行程已走完 = 高水位摸过「信号日死锚上轨」（EMA10+ATR14 固定锚，到站提示不催走）
  · 🏁趋势终结 = 死锚后连续 2 日收盘跌破 EMA10（回测：触发后15日 +2.83% vs 未触发 +8.42%，
    区分度 5.6 个百分点，为全网格最优参数；离场线语义=挪仓机会成本，非崩盘报警）
  · ⚡haos超买共振 = 双威廉≥-10（对称买入侧超卖，挂行尾做止盈环境提醒）
  · 展示规则（终局驱动，纯函数无状态）：距信号日≤15天必显示；15~30天未终局（无🏁未破位删除）
    继续显示；🏁后再留5天回看；30天硬顶无条件出清（防僵尸）
  · 参数回测：148标的/3273信号/死锚命中68%，网格24组+出场参数6组，2026-10-11 定版
  【v1.5】⚡haos强/弱共振叠加标记（强=双线≤-90当前状态；弱=仅慢线且进入≤15天）
  【v1.2】破位/收复状态机：容差0.3×ATR + 三确认项（爆量/瘫脚/动能），收复复活，二次破位删除
  【v1.0】Lucy=肯特纳双轨触及；🥇CCI<-150+收盘位>0.3 🥈长影线>50% 🥉超跌>10%+收盘位
"""
from __future__ import annotations

import base64
import logging
import math
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

import requests
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kx_client import KxClient  # noqa: E402

__version__ = "1.6"
GH_API = "https://api.github.com/repos/Llng125256/kx-combo/contents"
FRESH_DAYS = 15          # 新信号基础展示期（天）
HARD_CAP = 30            # 终局驱动硬顶（防僵尸，天）
FLAG_LINGER = 5          # 🏁终局后回看期（天）
MAX_PER_SYM = 1          # 每标的只显示 1 条：日期最新的那条买入信号
WORKERS = 16
BARS = 150


def ema(x, n):
    a = 2/(n+1); out = np.full(len(x), np.nan); out[0] = x[0]
    for i in range(1, len(x)): out[i] = a*x[i] + (1-a)*out[i-1]
    return out


def ema_nan(x, n):
    """EMA（首有效值起算，供含 NaN 前缀的 WPR 序列用）。"""
    a = 2.0/(n+1)
    out = np.full(len(x), np.nan)
    idx = np.where(~np.isnan(x))[0]
    if len(idx) == 0: return out
    s = idx[0]; out[s] = x[s]
    for i in range(s+1, len(x)): out[i] = a*x[i] + (1-a)*out[i-1]
    return out


def wpr(high, low, close, n):
    """威廉 %R(n)，值域 [-100, 0]。"""
    hh = np.full(len(close), np.nan); ll = np.full(len(close), np.nan)
    for i in range(n-1, len(close)):
        hh[i] = high[i-n+1:i+1].max(); ll[i] = low[i-n+1:i+1].min()
    rng = hh - ll
    out = np.where(rng == 0, -50.0, (hh-close)/np.where(rng == 0, 1, rng)*-100.0)
    out[:n-1] = np.nan
    return out


def t3(x, n, v):
    """Tillson T3：六重 EMA 加权。"""
    e1 = ema_nan(x, n); e2 = ema_nan(e1, n); e3 = ema_nan(e2, n)
    e4 = ema_nan(e3, n); e5 = ema_nan(e4, n); e6 = ema_nan(e5, n)
    return (-v**3)*e6 + (3*v**2+3*v**3)*e5 + (-6*v**2-3*v-3*v**3)*e4 + (1+3*v+v**3+3*v**2)*e3


def haos_tag(high, low, close, fresh_days=FRESH_DAYS):
    """haos 环境标记（叠加制）：强共振=双线当前≤-90（状态自带新鲜度）；
    弱共振=仅慢线≤-90 且状态进入首日距今≤fresh_days 天。返回行尾标记串。"""
    if len(close) < 120: return ''
    f = t3(wpr(high, low, close, 14), 3, 0.7)
    s = t3(wpr(high, low, close, 96), 3, 0.7)
    if np.isnan(f[-1]) or np.isnan(s[-1]): return ''
    if f[-1] <= -90 and s[-1] <= -90:
        return ' ⚡haos强共振'
    if s[-1] <= -90:
        j = len(close) - 1
        while j > 0 and not np.isnan(s[j-1]) and s[j-1] <= -90: j -= 1   # 回溯到本段进入首日
        if (len(close)-1) - j <= fresh_days:
            return ' ⚡haos弱共振'
    return ''


def haos_tag_ob(high, low, close):
    """haos 超买共振（对称买入侧）：双线当前≥-10 → 止盈环境提醒。"""
    if len(close) < 120: return ''
    f = t3(wpr(high, low, close, 14), 3, 0.7)
    s = t3(wpr(high, low, close, 96), 3, 0.7)
    if np.isnan(f[-1]) or np.isnan(s[-1]): return ''
    if f[-1] >= -10 and s[-1] >= -10:
        return ' ⚡haos超买共振'
    return ''


def analyse(sym, bars, now_day):
    """单标的：返回 15 天内触发的信号列表（含分级）。"""
    if len(bars) < 40:
        return []
    dates = [str(b['time'])[:10] for b in bars]
    high = np.array([float(b['high']) for b in bars])
    low = np.array([float(b['low']) for b in bars])
    close = np.array([float(b['close']) for b in bars])
    openp = np.array([float(b['open']) for b in bars])
    vol = np.array([float(b.get('volume') or 0) for b in bars])
    n = len(bars)
    ema10 = ema(close, 10)
    tr = np.maximum(high[1:], close[:-1]) - np.minimum(low[1:], close[:-1])
    tr = np.concatenate([[high[0]-low[0]], tr])
    atr = np.full(n, np.nan)
    for i in range(14, n): atr[i] = tr[i-14:i].mean()
    # CCI20
    tp = (high+low+close)/3
    cci = np.full(n, np.nan)
    for i in range(19, n):
        w = tp[i-19:i+1]; m = w.mean(); md = np.abs(w-m).mean()
        cci[i] = (tp[i]-m)/(0.015*md+1e-9)
    hard = n - HARD_CAP
    htag = haos_tag(high, low, close) + haos_tag_ob(high, low, close)   # 环境标记（互斥，叠加制）
    sigs = []
    last = -99
    for i in range(20, n-1):
        if np.isnan(ema10[i]) or np.isnan(atr[i]): continue
        if not (low[i] <= ema10[i]-atr[i]) or i - last <= 2: continue
        rng_i = high[i]-low[i]+1e-9
        cp_i = (close[i]-low[i])/rng_i
        if cp_i <= 0.3: continue                     # ★ 企稳确认：触及日收盘瘫脚的不算（回测破位率砍半）
        last = i
        if i < hard: continue                        # ★ 30天硬顶（防僵尸）
        rng = high[i]-low[i]+1e-9
        cp = (close[i]-low[i])/rng                   # 收盘位置
        shadow = (np.minimum(close[i], openp[i])-low[i])/rng
        vr = vol[i]/(vol[max(0, i-10):i].mean()+1e-9)
        drop = (close[i]/close[max(0, i-10)]-1)*100  # 前10日涨跌
        c = cci[i]
        grade = ('🥇' if (c < -150 and cp > 0.3) else
                 '🥈' if shadow > 0.5 else
                 '🥉' if (drop < -10 and cp > 0.3) else '·')
        lo_i, hi_i = low[i], ema10[i]-atr[i]         # 区间数值（破位/收复/死锚判定用）
        zone = f"[{lo_i:.2f}~{hi_i:.2f}]"
        warn = ' ⚠️爆量瘫脚警告' if (vr > 3 and cp < 0.3) else ''
        sig = {'day': dates[i], 'side': 'buy', 'grade': grade,
               'price': openp[i+1] if i+1 < n else close[i],
               'zone': zone, 'close': close[i], 'cci': c, 'warn': warn, 'note': '',
               'haos': htag}

        # ---- 破位/收复状态机（触及后逐日复检 v1.2，买侧口径）----
        # 容差：收盘超出区间沿 > 0.3×ATR14 才算有效破位
        # 确认项：①爆量 vr>3 ②收盘瘫脚 cp<0.3 ③动能同向极端 CCI<-100
        state, breaks, brk_j, rec_j = 'live', 0, None, None
        killed = False
        for j in range(i+1, n):
            if np.isnan(atr[j]) or np.isnan(cci[j]):
                continue
            back = close[j] > hi_i                              # 收盘收复区间沿
            pen = lo_i - close[j]
            if state == 'broken' and back:
                state, rec_j = 'recovered', j                   # 收盘站回区间 → 判定复活
                continue
            if pen <= 0.3*atr[j]:                               # 容差内，不算破
                continue
            rng_j = high[j]-low[j]+1e-9
            cp_j = (close[j]-low[j])/rng_j
            vr_j = vol[j]/(vol[max(0, j-10):j].mean()+1e-9)
            conf = sum([vr_j > 3.0, cp_j < 0.3, cci[j] < -100])
            if conf >= 1 and state != 'broken':                 # 有效破位（≥1确认）；持续破位不重复算
                breaks += 1
                if breaks >= 2:                                 # 收复后再破位 → 反复横跳，直接踢出
                    killed = True; break
                state, brk_j = 'broken', j
        if killed:
            continue
        if state == 'broken':
            if (n-1) - brk_j > 2:                               # 破位观察满2天未收复 → 删除
                continue
            sig['warn'] = (sig['warn'] + f' ⚠️破位{dates[brk_j][5:]}观察中').strip()
        elif state == 'recovered':
            # 复活：用收复当根重跑分级（够哪级恢复哪级）
            rng_r = high[rec_j]-low[rec_j]+1e-9
            cp_r = (close[rec_j]-low[rec_j])/rng_r
            sh_r = (np.minimum(close[rec_j], openp[rec_j])-low[rec_j])/rng_r
            dr_r = (close[rec_j]/close[max(0, rec_j-10)]-1)*100
            g2 = ('🥇' if (cci[rec_j] < -150 and cp_r > 0.3) else
                  '🥈' if sh_r > 0.5 else
                  '🥉' if (dr_r < -10 and cp_r > 0.3) else '·')
            if g2 == '·':                                       # 收复但不够任何牌级 → 不再显示
                continue
            sig['grade'] = g2
            sig['cci'] = cci[rec_j]
            sig['note'] = f"（{dates[rec_j][5:]}已收复，恢复{g2}）"

        # ---- ✅死锚到站 + 🏁趋势终结（v1.6，回测定版参数）----
        anchor = ema10[i] + atr[i]                              # 死锚上轨：信号日固定，不随轨道移动
        dead_j = None
        for j in range(i+1, n):
            if high[j] >= anchor:
                dead_j = j; break
        flag_j = None
        if dead_j is not None:
            sig['dead'] = f" ✅行程已走完({dates[dead_j][5:]})"
            cnt = 0
            for j in range(dead_j+1, n):                        # 连续2日收盘跌破EMA10 → 离场线
                cnt = cnt+1 if close[j] < ema10[j] else 0
                if cnt >= 2:
                    flag_j = j; break
            if flag_j:
                sig['flag'] = f" 🏁趋势终结({dates[flag_j][5:]})"

        # ---- 展示规则（终局驱动，纯函数）----
        age = (n-1) - i
        if flag_j is not None and (n-1) - flag_j > FLAG_LINGER: # 🏁回看期满 → 出清
            continue
        # （15天内必显示已由扫描范围保证；30天硬顶已在扫描入口过滤）
        sigs.append(sig)
    sigs.sort(key=lambda s: s['day'], reverse=True)
    return sigs[:MAX_PER_SYM], close[-1]


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    print(f"[replica] 包代码版本 v{__version__}")
    tok = os.environ.get("KX_GH_TOKEN", "")
    cli = KxClient(signal_age_days=16, timeout=30, retries=3, retry_delay=2.0)
    pool = sorted({it['symbol'] for it in (cli.get_signals('futures', '1d', 1, 500).get('items') or [])
                   if (it.get('underlying_type') or '') == 'EQUITY' and it.get('symbol')})

    def one(sym):
        try:
            d = cli.get_kline(sym, 'futures', '1d', BARS)
            sigs, last_close = analyse(sym, d.get('bars') or [], None)
            return sym, sigs, last_close
        except Exception as e:
            return sym, [{'day': 'ERR', 'side': 'err', 'grade': '', 'price': 0, 'zone': str(e)[:50], 'close': 0, 'cci': 0, 'warn': ''}], 0

    with ThreadPoolExecutor(WORKERS) as ex:
        rows = {sym: (sigs, lc) for sym, sigs, lc in ex.map(one, pool)}

    now_day = datetime.now(timezone.utc).strftime('%Y-%m-%d')
    hit = {s: v for s, (v, lc) in rows.items() if v and v[0]['day'] != 'ERR'}
    n_buy = sum(1 for v in hit.values() for x in v if x['side'] == 'buy')
    g1 = sum(1 for v in hit.values() for x in v if x['grade'] == '🥇')
    warn = sum(1 for v in hit.values() for x in v if x['warn'])

    rank = {'⚠️': 0, '🥇': 1, '🥈': 2, '🥉': 3, '·': 9}
    rows = []
    for sym in sorted(hit):
        v = hit[sym]
        if v and v[0]['day'] == 'ERR': continue
        v = [x for x in v if x['grade'] != '·' or x['warn']]   # 只显示有牌/警告信号
        for x in v:
            price_s = f"{x['price']:.2f}" if x['price'] < 1000 else f"{x['price']:.1f}"
            g = '⚠️' if x['warn'] else x['grade']
            rows.append((rank.get(g, 9), sym, x, g, price_s))
    rows.sort(key=lambda r: (r[0], r[1]))
    tz8 = timezone(timedelta(hours=8))
    up_ts = datetime.now(tz8).strftime('%Y-%m-%d %H:%M')
    lines = [f"【K线复刻监控 · 自研引擎 v{__version__}】{now_day} (UTC)",
             f"⏱️ 本次更新: {up_ts} 北京时间（每天 05/11/17/23 点更新，此时间变了=发版正常）",
             f"扫描 {len(pool)} 标的 | 在册买入信号 {n_buy} 个 | 🥇金牌 {g1} | ⚠️破位警告 {warn}",
             "📌 流水线：✅行程已走完=摸过信号日上轨(到站提示) | 🏁趋势终结=连续2日收盘跌破EMA10(离场线) | ⚠️=破位纪律 | ⚡=威廉环境",
             "=" * 46]
    for _, sym, x, g, price_s in rows:
        lines.append(f"{g} {sym} 买入 {x['day']} 锚{price_s} 支撑阻力区{x['zone']} CCI{x['cci']:.0f}{x['warn']}{x.get('note', '')}{x.get('haos', '')}{x.get('dead', '')}{x.get('flag', '')}")
    if not rows:
        lines.append("（当前无在册信号）")
    text = "\n".join(lines) + "\n"
    print(f"[replica] {now_day} 状态页生成: {len(hit)} 标的 / {n_buy}b / {len(text.encode())//1024}KB")

    if tok:
        hdr = {"Authorization": f"Bearer {tok}"}
        tz8 = timezone(timedelta(hours=8))   # 北京时间命名，用户可预测
        hhmm = datetime.now(tz8).strftime('%m%d-%H%M')
        for fname in (f"status/daily-{hhmm}.txt", "status/view.html", "status/latest.txt"):
            try:
                g = requests.get(f"{GH_API}/{fname}", headers=hdr, timeout=15)
                data = {"message": f"replica status {now_day}", "content": base64.b64encode(text.encode()).decode()}
                if g.status_code == 200 and g.json().get("sha"): data["sha"] = g.json()["sha"]
                p = requests.put(f"{GH_API}/{fname}", headers=hdr, json=data, timeout=30)
                ok = p.status_code in (200, 201)
                print(f"[replica] 上传 {fname}: {'OK' if ok else f'HTTP {p.status_code}'}")
            except Exception as e:
                print(f"[replica] 上传 {fname} 异常: {e}")
        try:
            requests.get("https://purge.jsdelivr.net/gh/Llng125256/kx-combo@main/status/latest.txt", timeout=15)
            print("[replica] jsDelivr 缓存已刷新")
        except Exception:
            pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
