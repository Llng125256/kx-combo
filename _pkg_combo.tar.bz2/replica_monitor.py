#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""K线导演·复刻监控（自研引擎 + 模拟持仓，纯文本状态页）

【v1.7.0 2026-10-11】推荐即模拟持仓（专家团联合设计，用户拍板）：
  · 评分排序 = 分级分 × 当日层分 × 威廉环境分（全部实测值映射）
      分级 🥇2.0/🥈1.6/🥉1.0/·1.1；层 批量1.5/常规1.0/孤星禁入；环境 强1.2/弱1.0/🥈弱0.8
  · 档位决策表：🥇批量=重/中仓，🥈批量=中/轻，🥇常规/🥈常规=轻，🥉批量=轻，
    孤星一律禁入，无牌禁入，🥉常规禁入（样本<30的格子按最差邻近处理）
  · 仓位：重10%/中6%/轻3% 名义；杠杆=风险预算÷(名义×止损距离)，封顶5×；
    风险预算 重1.0%/中0.6%/轻0.3%；止损距离<1.5%按1.5%计，>8%放弃信号
  · 止损=死区下沿+收盘确认（5规则回测帕累托最优：+1.35%，2×ATR方案-10.7%被否）
  · ✅走默认留例外（留须斜率>0+收盘>EMA10+量比>0.8）；✅后连续2日站稳EMA10→止损上移保本
  · 优先级 ⚠️>🏁>✅>30天硬顶；每轮重算只输出单一当前建议，旧建议自动隐藏
  · 【金融团队审计 2026-10-11】①模拟仓确认失败离场（到站后2日确认中收盘≤EMA10→当日平，
    命名「✅确认失败离场」，比设计默认走更早锁盈属保守化）②⚠️破位三确认≥1回填设计
    ③展示「⚠️观察中」时若模拟仓已离场→标注「模拟仓已按风控口径离场」④免责补两句
  ⑤模拟账户<100笔标注「样本不足，不构成有效性证据」
  · 行业分散：name括号解析→因果链归组，同大类≤2只/≤20%，同大类同日新开≤1只；
    解析失败进「未分类」桶同受约束；宽基ETF单列不计行业但计总敞口
  · 熔断：总敞口≤50%、单票≤15%、同日新开≤3只
  · 模拟盘=规则化全量模拟（每条合格信号必开仓、全约束），无幸存者偏差；
    资金费按0.01%/8h粗扣；跌穿止损按实际收盘记亏不美化
  · 市况横幅置顶：孤星日明示「今日不适合抄底」
  【双状态机说明（技术评审后刻意保留）】展示用破位机容忍 1 次破位（观察2天+收复复活），
  模拟仓推演是风控口径（1 次确认即离场）——两者口径不同是设计而非疏漏，改动时必须同步检查两处。
  【v1.6】卖出并入买入行：✅死锚到站 / 🏁EMA10离场线 / ⚡威廉环境 / 终局驱动展示
  【v1.2】破位/收复状态机：容差0.3×ATR+三确认（爆量/瘫脚/CCI）
  【v1.0】Lucy=肯特纳双轨触及；🥇CCI<-150+收盘位>0.3（样本外验证：仅近期市场状态有效）
  公式搜索结论（2026-10-11）：8候选企稳公式无一通过替换及格线，CCI守位。
"""
from __future__ import annotations

import base64
import logging
import os
import sys
import time
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

import requests
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kx_client import KxClient  # noqa: E402

__version__ = "1.7.4"
GH_API = "https://api.github.com/repos/Llng125256/kx-combo/contents"
FRESH_DAYS = 15
HARD_CAP = 30            # 信号/模拟仓硬顶（天）
FLAG_LINGER = 5
WORKERS = 16
BARS = 150
MAX_LEV = 5.0            # 杠杆封顶
STOP_FAR = 0.08          # 止损距离>8%放弃信号
STOP_NEAR = 0.015        # 止损距离<1.5%按1.5%计
TIERS = {'重仓': (10.0, 1.0), '中仓': (6.0, 0.6), '轻仓': (3.0, 0.3)}  # 名义%, 风险预算%
CAP_TOTAL = 50.0         # 总敞口%
CAP_SECTOR = 20.0        # 单行业敞口%
CAP_SECTOR_N = 2         # 同行业最多仓位数
CAP_DAY_NEW = 3          # 同日新开
CAP_SECTOR_DAY = 1       # 同行业同日新开
FUND_FEE_DAY = 0.0003    # 资金费 0.01%/8h ≈ 0.03%/天（名义占比）

SECTOR_KEYS = [
    ('宽基', ('ETF', '指数', '基金')),
    ('AI科技', ('半导体', '芯片', '光模块', 'AI', '算力', '数据中心', '云计算', '软件', '信息技术', '电子设计', '网络', '互联网')),
    ('汽车', ('汽车', '电动车', '整车', '自动驾驶')),
    ('医疗健康', ('医药', '生物', '医疗', '健康', '制药', '疗法', '诊断', '基因')),
    ('能源', ('石油', '天然气', '油气', '能源', '煤炭', '铀', '核能', '电力', '太阳能', '光伏', '新能源', '油田')),
    ('金融', ('银行', '保险', '证券', '金融', '支付', '交易所', '资管', '信贷')),
    ('消费', ('零售', '餐饮', '食品', '饮料', '咖啡', '服装', '消费', '家居', '电商', '旅游', '酒店', '度假', '博彩', '体育', '鞋', '啤酒', '美容', '化妆品', '宠物')),
    ('工业防务', ('航空', '航天', '国防', '军工', '防务', '机械', '制造', '工程', '建筑', '运输', '物流', '铁路', '卡车', '航运')),
    ('通信', ('电信', '通信', '运营商', '电话')),
    ('原材料', ('矿业', '稀土', '化工', '钢铁', '材料', '化肥', '造纸', '黄金', '白银', '铜', '铝')),
    ('媒体娱乐', ('媒体', '传媒', '影视', '流媒体', '游戏', '音乐', '视频', '娱乐')),
    ('房地产', ('房地产', '地产', 'REIT', '物业')),
]


def sector_of(name: str) -> str:
    """name 字段因果链归组：宽基最优先 → 关键词匹配 → 未分类。"""
    if not name:
        return '未分类'
    if 'ETF' in name or '指数' in name or '基金' in name:
        return '宽基'
    inner = name[name.find('（')+1:name.find('）')] if '（' in name and '）' in name else name
    text = inner + name
    for bucket, keys in SECTOR_KEYS:
        if bucket == '宽基':
            continue
        for kw in keys:
            if kw in text:
                return bucket
    return '未分类'


def ema(x, n):
    a = 2/(n+1); out = np.full(len(x), np.nan); out[0] = x[0]
    for i in range(1, len(x)): out[i] = a*x[i] + (1-a)*out[i-1]
    return out


def ema_nan(x, n):
    a = 2.0/(n+1)
    out = np.full(len(x), np.nan)
    idx = np.where(~np.isnan(x))[0]
    if len(idx) == 0: return out
    s = idx[0]; out[s] = x[s]
    for i in range(s+1, len(x)): out[i] = a*x[i] + (1-a)*out[i-1]
    return out


def wpr(high, low, close, n):
    hh = np.full(len(close), np.nan); ll = np.full(len(close), np.nan)
    for i in range(n-1, len(close)):
        hh[i] = high[i-n+1:i+1].max(); ll[i] = low[i-n+1:i+1].min()
    rng = hh - ll
    out = np.where(rng == 0, -50.0, (hh-close)/np.where(rng == 0, 1, rng)*-100.0)
    out[:n-1] = np.nan
    return out


def t3(x, n, v):
    e1 = ema_nan(x, n); e2 = ema_nan(e1, n); e3 = ema_nan(e2, n)
    e4 = ema_nan(e3, n); e5 = ema_nan(e4, n); e6 = ema_nan(e5, n)
    return (-v**3)*e6 + (3*v**2+3*v**3)*e5 + (-6*v**2-3*v-3*v**3)*e4 + (1+3*v+v**3+3*v**2)*e3


def haos_tag(high, low, close, fresh_days=FRESH_DAYS):
    """⚡强共振=双线当前≤-90；弱共振=仅慢线且进入≤15天。"""
    if len(close) < 120: return ''
    f = t3(wpr(high, low, close, 14), 3, 0.7)
    s = t3(wpr(high, low, close, 96), 3, 0.7)
    if np.isnan(f[-1]) or np.isnan(s[-1]): return ''
    if f[-1] <= -90 and s[-1] <= -90:
        return ' ⚡强共振'
    if s[-1] <= -90:
        j = len(close) - 1
        while j > 0 and not np.isnan(s[j-1]) and s[j-1] <= -90: j -= 1
        if (len(close)-1) - j <= fresh_days:
            return ' ⚡弱共振'
    return ''


def haos_tag_ob(high, low, close):
    """⚡超买共振：双线当前≥-10（止盈环境提醒）。"""
    if len(close) < 120: return ''
    f = t3(wpr(high, low, close, 14), 3, 0.7)
    s = t3(wpr(high, low, close, 96), 3, 0.7)
    if np.isnan(f[-1]) or np.isnan(s[-1]): return ''
    if f[-1] >= -10 and s[-1] >= -10:
        return ' ⚡超买共振'
    return ''


def analyse(sym, bars, now_day):
    """单标的：返回 (最新展示信号|None, 候选列表, 信号日集合, last_close)。

    候选 = 30 天窗口内每个合格触及事件 + 单标的全生命周期推演
    （⚠️破位止损 > ✅走默认留例外 > 保本/🏁 > 30天硬顶；组合级约束由 main 叠加）。
    """
    if len(bars) < 40:
        return None, [], set(), 0.0, set()
    dates = [str(b['time'])[:10] for b in bars]
    high = np.array([float(b['high']) for b in bars])
    low = np.array([float(b['low']) for b in bars])
    close = np.array([float(b['close']) for b in bars])
    openp = np.array([float(b['open']) for b in bars])
    vol = np.array([float(b.get('volume') or 0) for b in bars])
    n = len(bars)
    ema10 = ema(close, 10)
    tr = np.maximum(high[1:], close[:-1]) - np.minimum(low[1:], close[:-1])
    tr = np.concatenate([[high[0]-low[0]], tr])
    atr = np.full(n, np.nan)
    for i in range(14, n): atr[i] = tr[i-14:i].mean()
    tp = (high+low+close)/3
    cci = np.full(n, np.nan)
    for i in range(19, n):
        w = tp[i-19:i+1]; m = w.mean(); cci[i] = (tp[i]-m)/(0.015*np.abs(w-m).mean()+1e-9)
    hard = n - HARD_CAP
    f_t3 = t3(wpr(high, low, close, 14), 3, 0.7)
    s_t3 = t3(wpr(high, low, close, 96), 3, 0.7)

    def env_at(i):
        if np.isnan(f_t3[i]) or np.isnan(s_t3[i]): return '无'
        if f_t3[i] <= -90 and s_t3[i] <= -90: return '强'
        if s_t3[i] <= -90: return '弱'
        if f_t3[i] >= -10 and s_t3[i] >= -10: return '超买'
        return '无'

    sigs = []
    touch_days = set()
    last = -99
    for i in range(20, n-1):
        if np.isnan(ema10[i]) or np.isnan(atr[i]) or np.isnan(cci[i]): continue
        if not (low[i] <= ema10[i]-atr[i]) or i - last <= 2: continue
        rng_i = high[i]-low[i]+1e-9
        cp_i = (close[i]-low[i])/rng_i
        if cp_i <= 0.3: continue    # ★ 企稳确认：触及日瘫脚K线整体排除（回测破位率砍半）
        last = i
        if i < hard: continue
        touch_days.add(dates[i])
        rng = high[i]-low[i]+1e-9
        cp = (close[i]-low[i])/rng
        shadow = (np.minimum(close[i], openp[i])-low[i])/rng
        vr = vol[i]/(vol[max(0, i-10):i].mean()+1e-9)
        drop = (close[i]/close[max(0, i-10)]-1)*100
        c = cci[i]
        grade = ('🥇' if (c < -150 and cp > 0.3) else
                 '🥈' if shadow > 0.5 else
                 '🥉' if (drop < -10 and cp > 0.3) else '·')
        lo_i, hi_i = low[i], ema10[i]-atr[i]
        anchor = openp[i+1]
        sig = {'day': dates[i], 'side': 'buy', 'grade': grade, 'anchor': anchor,
               'zone': f"[{lo_i:.2f}~{hi_i:.2f}]", 'cci': c,
               'warn': '', 'note': '', 'haos': haos_tag(high, low, close) + haos_tag_ob(high, low, close),
               'env': env_at(i), 'stop': lo_i}

        # ---- 破位/收复状态机（v1.2 展示口径）----
        state, breaks, brk_j, rec_j = 'live', 0, None, None
        killed = False
        for j in range(i+1, n):
            if np.isnan(atr[j]) or np.isnan(cci[j]): continue
            back = close[j] > hi_i
            pen = lo_i - close[j]
            if state == 'broken' and back:
                state, rec_j = 'recovered', j
                continue
            if pen <= 0.3*atr[j]: continue
            rng_j = high[j]-low[j]+1e-9
            cp_j = (close[j]-low[j])/rng_j
            vr_j = vol[j]/(vol[max(0, j-10):j].mean()+1e-9)
            conf = sum([vr_j > 3.0, cp_j < 0.3, cci[j] < -100])
            if conf >= 1 and state != 'broken':
                breaks += 1
                if breaks >= 2:
                    killed = True; break
                state, brk_j = 'broken', j
        if killed: continue
        if state == 'broken':
            if (n-1) - brk_j > 2: continue
            sig['warn'] = (sig['warn'] + f' ⚠️破位{dates[brk_j][5:]}观察中').strip()
        elif state == 'recovered':
            rng_r = high[rec_j]-low[rec_j]+1e-9
            cp_r = (close[rec_j]-low[rec_j])/rng_r
            sh_r = (np.minimum(close[rec_j], openp[rec_j])-low[rec_j])/rng_r
            dr_r = (close[rec_j]/close[max(0, rec_j-10)]-1)*100
            g2 = ('🥇' if (cci[rec_j] < -150 and cp_r > 0.3) else
                  '🥈' if sh_r > 0.5 else
                  '🥉' if (dr_r < -10 and cp_r > 0.3) else '·')
            if g2 == '·': continue
            sig['grade'] = g2
            sig['cci'] = cci[rec_j]
            sig['note'] = f"（{dates[rec_j][5:]}已收复，恢复{g2}）"

        # ---- ✅死锚 + 🏁趋势终结（展示标记）----
        anchor_up = ema10[i] + atr[i]
        dead_j = None
        for j in range(i+1, n):
            if high[j] >= anchor_up:
                dead_j = j; break
        flag_j = None
        if dead_j is not None:
            sig['dead'] = f" ✅行程已走完({dates[dead_j][5:]})"
            cnt = 0
            for j in range(dead_j+1, n):
                cnt = cnt+1 if close[j] < ema10[j] else 0
                if cnt >= 2:
                    flag_j = j
                    sig['flag'] = f" 🏁趋势终结({dates[j][5:]})"
                    break
        if flag_j is not None and (n-1) - flag_j > FLAG_LINGER:
            continue    # 🏁回看期满 → 出清
        sigs.append(sig)
    sigs.sort(key=lambda s: s['day'], reverse=True)

    # ---- 候选（模拟仓推演，单标的无约束口径）----
    candidates = []
    last_c = -99
    for i in range(20, n-1):
        if np.isnan(ema10[i]) or np.isnan(atr[i]) or np.isnan(cci[i]): continue
        if not (low[i] <= ema10[i]-atr[i]) or i - last_c <= 2: continue
        rng = high[i]-low[i]+1e-9
        cp = (close[i]-low[i])/rng
        if cp <= 0.3: continue
        last_c = i
        if i < hard: continue
        shadow = (np.minimum(close[i], openp[i])-low[i])/rng
        drop = (close[i]/close[max(0, i-10)]-1)*100
        grade = ('🥇' if (cci[i] < -150 and cp > 0.3) else
                 '🥈' if shadow > 0.5 else
                 '🥉' if (drop < -10 and cp > 0.3) else '·')
        anchor = openp[i+1]
        stop = low[i]
        stop_dist = max(STOP_NEAR, (anchor-stop)/anchor)
        cand = {'day': dates[i], 'grade': grade, 'env': env_at(i), 'anchor': anchor,
                'stop': stop, 'stop_dist': stop_dist, 'idx': i, 'n': n}
        # 生命周期推演（风控口径：⚠️确认即离场；✅走默认留须三条件+连续2日站稳EMA10确认）
        exit_day, exit_px, reason = None, None, '在仓'
        hold, pend, cnt2 = False, 0, 0
        for j in range(i+1, n):
            if np.isnan(atr[j]) or np.isnan(cci[j]): continue
            # ⚠️破位止损（确认即离场，风控优先于一切止盈状态）
            pen = low[i] - close[j]
            if pen > 0.3*atr[j]:
                rng_j = high[j]-low[j]+1e-9
                cp_j = (close[j]-low[j])/rng_j
                vr_j = vol[j]/(vol[max(0, j-10):j].mean()+1e-9)
                if (vr_j > 3.0) + (cp_j < 0.3) + (cci[j] < -100) >= 1:
                    exit_day, exit_px, reason = j, close[j], '⚠️破位止损'
                    break
            # ✅到站：走默认；留=三条件满足后再连续2日收盘>EMA10 确认，确认失败即走
            if not hold and high[j] >= ema10[i]+atr[i]:
                if pend == 0:
                    slope_ok = (ema10[j]+atr[j]) > (ema10[j-1]+atr[j-1])
                    ema_ok = close[j] > ema10[j]
                    vr_ok = vol[j]/(vol[max(0, j-10):j].mean()+1e-9) > 0.8
                    if not (slope_ok and ema_ok and vr_ok):
                        exit_day, exit_px, reason = j, close[j], '✅到站止盈'
                        break
                    pend = 1          # 三条件过，进入连续2日站稳确认
                    continue
                else:
                    if close[j] > ema10[j]:
                        pend += 1
                        if pend >= 3:  # 到站日 + 2日确认
                            hold = True
                        continue
                    else:
                        exit_day, exit_px, reason = j, close[j], '✅确认失败离场'
                        break
            if hold:
                if close[j] < anchor:
                    exit_day, exit_px, reason = j, close[j], '保本离场'
                    break
                cnt2 = cnt2+1 if close[j] < ema10[j] else 0
                if cnt2 >= 2:
                    exit_day, exit_px, reason = j, close[j], '🏁趋势终结'
                    break
            if j - i >= HARD_CAP:
                exit_day, exit_px, reason = j, close[j], '30天硬顶'
                break
        if exit_day is not None:
            cand.update({'exit_day': exit_day, 'exit_date': dates[exit_day],
                         'exit_px': exit_px, 'reason': reason,
                         'ret': (exit_px/anchor-1)*100})
        else:
            cand.update({'exit_day': None, 'exit_date': None, 'exit_px': None,
                         'reason': '在仓', 'ret': None})
        candidates.append(cand)
    latest = sigs[0] if sigs else None
    return latest, candidates, touch_days, close[-1], set(dates)


def tier_of(grade, lay, env):
    """档位决策表（专家定稿）：重仓/中仓/轻仓/禁入。"""
    if lay == '孤星':
        return '禁入'
    if grade == '🥇':
        if lay == '批量':
            return '重仓' if env == '强' else '中仓'
        return '轻仓'
    if grade == '🥈':
        if lay == '批量':
            return '中仓' if env == '强' else '轻仓'
        return '轻仓'
    if grade == '🥉':
        return '轻仓' if lay == '批量' else '禁入'
    return '禁入'


def score_of(grade, lay, env):
    g = {'🥇': 2.0, '🥈': 1.6, '🥉': 1.0}.get(grade, 1.1)
    l = 1.5 if lay == '批量' else 1.0
    e = 0.8 if (grade == '🥈' and env == '弱') else (1.2 if env == '强' else 1.0)
    return round(g*l*e, 2)


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    print(f"[replica] 包代码版本 v{__version__}")
    tok = os.environ.get("KX_GH_TOKEN", "")
    cli = KxClient(signal_age_days=16, timeout=30, retries=3, retry_delay=2.0)
    items = cli.get_signals('futures', '1d', 1, 500).get('items') or []
    names = {it['symbol']: (it.get('name') or '') for it in items
             if (it.get('underlying_type') or '') == 'EQUITY' and it.get('symbol')}
    pool = sorted(names)

    def one(sym):
        try:
            d = cli.get_kline(sym, 'futures', '1d', BARS)
            sig, cands, tdays, lc, dset = analyse(sym, d.get('bars') or [], None)
            return sym, sig, cands, tdays, lc, dset
        except Exception:
            return sym, 'ERR', [], set(), 0, set()

    with ThreadPoolExecutor(WORKERS) as ex:
        results = list(ex.map(one, pool))

    now_day = datetime.now(timezone.utc).strftime('%Y-%m-%d')
    day_trig = Counter()
    sym_cands, sigs, closes = {}, {}, {}
    calendar = set()
    for sym, sig, cands, tdays, lc, dset in results:
        if sig == 'ERR': continue
        sigs[sym] = sig
        sym_cands[sym] = cands
        closes[sym] = lc
        calendar |= dset
        for d in tdays: day_trig[d] += 1
    cal = sorted(calendar)
    pool_n = max(1, len(pool))

    def layer_prev(dstr):
        """T-1 自然交易日触发数→层（日历化，零触发日=孤星；归一化：孤星<1.5%池，批量>8%池）。"""
        import bisect
        k = bisect.bisect_left(cal, dstr)
        if k <= 0: return '常规'
        cnt = day_trig.get(cal[k-1], 0)
        if cnt < 0.015*pool_n: return '孤星'
        if cnt > 0.08*pool_n: return '批量'
        return '常规'

    def lay_of_latest():
        """今日市况 = 最近一个已收盘交易日的 T-1。"""
        import bisect
        k = bisect.bisect_left(cal, now_day)
        if k == 0: return '常规'
        ref = cal[k-1] if (k < len(cal) and cal[k] == now_day) else cal[-1]
        k2 = cal.index(ref)
        if k2 <= 0: return '常规'
        cnt = day_trig.get(cal[k2-1], 0)
        if cnt < 0.015*pool_n: return '孤星'
        if cnt > 0.08*pool_n: return '批量'
        return '常规'

    # ---- 组合级模拟（时间序 sweep + 熔断 + 行业分散）----
    # 持仓自开仓日起占用名义额度，直到 exit_date（含）后下一候选日起释放——
    # 保证总敞口/行业敞口在持仓重叠期真实生效（技术评审 #1 修复）。
    active, closed = [], []
    skip_n = Counter()
    sector_state = {}
    day_new = Counter()
    cands_all = []
    for sym, cands in sym_cands.items():
        for cd in cands:
            cd['sym'] = sym
            cd['sector'] = sector_of(names.get(sym, ''))
            cands_all.append(cd)
    cands_all.sort(key=lambda x: (x['day'], x['sym']))   # 决胜键（评审 #8）

    def sweep(day):
        """回收 exit_date<=day 的在仓仓位（当日收盘已平，次日额度释放）。"""
        for p in active[:]:
            if p['exit_date'] and p['exit_date'] <= day:
                b = p['sector']
                if b != '宽基':
                    sector_state[b][0] -= 1
                    sector_state[b][1] -= p['notional']
                active.remove(p)

    for cd in cands_all:
        sweep(cd['day'])
        sym = cd['sym']
        if any(p['sym'] == sym for p in active):
            skip_n['已有持仓'] += 1; continue
        lay = layer_prev(cd['day'])
        tier = tier_of(cd['grade'], lay, cd['env'])
        if tier == '禁入':
            skip_n['禁入'] += 1; continue
        if cd['stop_dist'] > STOP_FAR:
            skip_n['止损过宽'] += 1; continue
        base, risk = TIERS[tier]
        notional = round(min(base, risk/cd['stop_dist']), 1)
        lev = round(max(1.0, min(MAX_LEV, risk/(notional*cd['stop_dist']))), 1)
        used = sum(p['notional'] for p in active)
        if used + notional > CAP_TOTAL:
            skip_n['总敞口满'] += 1; continue
        if day_new[cd['day']] >= CAP_DAY_NEW:
            skip_n['当日限额'] += 1; continue
        b = cd['sector']
        if b != '宽基':
            cnt_b = sum(1 for p in active if p['sector'] == b)
            not_b = sum(p['notional'] for p in active if p['sector'] == b)
            if cnt_b >= CAP_SECTOR_N or not_b + notional > CAP_SECTOR:
                skip_n[f'{b}限额'] += 1; continue
            if day_new[(cd['day'], b)] >= CAP_SECTOR_DAY:
                skip_n[f'{b}当日限额'] += 1; continue
        pos = {'sym': sym, 'day': cd['day'], 'anchor': cd['anchor'], 'tier': tier,
               'notional': notional, 'lev': lev, 'stop': cd['stop'], 'sector': b,
               'score': score_of(cd['grade'], lay, cd['env']),
               'exit_date': cd.get('exit_date'), 'exit_px': cd.get('exit_px'),
               'exit_idx': cd.get('exit_day'),
               'reason': cd.get('reason'), 'ret': cd.get('ret'),
               'open_idx': cd['idx'], 'n': cd['n']}
        active.append(pos)
        day_new[cd['day']] += 1
        if b != '宽基':
            day_new[(cd['day'], b)] += 1
        # 平仓结算：推演已定退出日的，按当时价格入账（占用已由 sweep 释放）
        if pos['exit_date'] is not None:
            days_held = max(1, (pos['exit_idx'] or pos['open_idx']) - pos['open_idx'])
            pos['pnl'] = (pos['ret'] or 0)*notional/100 - notional*FUND_FEE_DAY*days_held
            pos['days_held'] = days_held
            closed.append(pos)
            active.remove(pos)
    # 数据末端仍未退出的 = 真在仓
    open_pos = [p for p in active if p['exit_date'] is None]
    for p in open_pos:
        lc = closes.get(p['sym'], 0)
        p['live_ret'] = (lc/p['anchor']-1)*100 if lc and p['anchor'] else 0.0

    realized = [p['pnl'] for p in closed]
    win = sum(1 for x in realized if x > 0)
    cum = sum(realized)

    # ---- 展示 ----
    hit = {s: v for s, v in sigs.items() if v}
    g1 = sum(1 for v in hit.values() if v['grade'] == '🥇')
    warn = sum(1 for v in hit.values() if v['warn'])
    rank = {'⚠️': 0, '🥇': 1, '🥈': 2, '🥉': 3, '·': 9}
    rows = []
    for sym in sorted(hit):
        x = hit[sym]
        if x['grade'] == '·' and not x['warn']: continue
        cands = sym_cands.get(sym) or []
        cd = next((cc for cc in cands if cc['day'] == x['day']), None)
        lay = layer_prev(x['day'])
        tier = tier_of(x['grade'], lay, x['env'])
        score = score_of(x['grade'], lay, x['env'])
        rows.append((rank.get('⚠️' if x['warn'] else x['grade'], 9), sym, x, cd, lay, tier, score))
    rows.sort(key=lambda r: (r[0], r[1]))

    tz8 = timezone(timedelta(hours=8))
    up_ts = datetime.now(tz8).strftime('%Y-%m-%d %H:%M')
    today_lay = lay_of_latest()
    banner = {'孤星': '⛔ 今日孤星市况·不适合抄底，仅观察，勿开新仓',
              '批量': '🟢 今日批量出清市况·β修复窗口，优选评分最高者',
              '常规': '市况：常规日，按评分与档位正常筛选'}[today_lay]

    lines = [f"【K线复刻监控 · 自研引擎 v{__version__}】{now_day} (UTC)",
             f"⏱️ 本次更新: {up_ts} 北京时间（每天 08:35/17:35/21:35/23:35 点更新，此时间变了=发版正常）",
             banner,
             f"扫描 {len(pool)} 标的 | 在册 {len(hit)} | 🥇 {g1} | ⚠️ {warn} | 模拟仓: 在仓 {len(open_pos)} / 已平 {len(closed)}",
             "页面读法：⚡环境好 → 🥇位置对 → ✅到了可走可拿 → 🏁亮了挪仓 → ⚠️亮了止损",
             "约束：总敞口≤50% | 单票≤15% | 同日≤3只 | 同行业≤2只 | 孤星日禁入",
             "=" * 46]
    if closed:
        sample_note = '' if len(closed) >= 100 else '（样本不足，<100笔不构成有效性证据）'
        lines.append(f"💼 模拟账户（规则化全量模拟，无幸存者偏差）: 已平 {len(closed)} 笔 | "
                     f"胜率 {win/len(closed):.0%} | 单笔均值 {np.mean(realized):+.3f}% | 累计 {cum:+.2f}%（含资金费）{sample_note}")
    else:
        lines.append("💼 模拟账户：暂无已平仓位（合格信号出现后自动开仓跟踪）")
    for p in sorted(open_pos, key=lambda x: -x['score']):
        lines.append(f"  ▶ 在仓 {p['sym']} {p['tier']} {p['notional']}% {p['lev']}x 锚{p['anchor']:.2f} "
                     f"止损{p['stop']:.2f} 开仓{p['day'][5:]} 现浮 {p['live_ret']:+.1f}%")
    lines.append("=" * 46)
    for _, sym, x, cd, lay, tier, score in rows:
        price_s = f"{x['anchor']:.2f}" if x['anchor'] < 1000 else f"{x['anchor']:.1f}"
        lines.append(f"{('⚠️' if x['warn'] else x['grade'])} {sym} 买入 {x['day']} 锚{price_s} "
                     f"支撑阻力区{x['zone']} CCI{x['cci']:.0f}{x['warn']}{x.get('note', '')}{x.get('haos', '')}"
                     f"{x.get('dead', '')}{x.get('flag', '')}")
        if tier == '禁入':
            lines.append(f"   └ 评分{score} {lay}日 禁入（{x['grade']}|{lay} 不满足开仓条件）")
            continue
        if cd is None:
            lines.append(f"   └ 评分{score} {lay}日 {tier}（数据不足）")
            continue
        base, risk = TIERS.get(tier, (3.0, 0.3))
        stop_dist = max(STOP_NEAR, (cd['anchor']-cd['stop'])/cd['anchor'])
        if stop_dist > STOP_FAR:
            lines.append(f"   └ 评分{score} {lay}日 ⛔止损距离过宽({stop_dist:.1%})，放弃该信号")
            continue
        notional = round(min(base, risk/stop_dist), 1)
        lev = round(max(1.0, min(MAX_LEV, risk/(notional*stop_dist))), 1)
        if x.get('flag'): advice = '🏁离场：触发离场线，按纪律出局'
        elif x.get('warn'):
            advice = '⚠️破位观察：止损纪律优先'
            if cd and cd.get('reason') == '⚠️破位止损':
                advice += '（模拟仓已按风控口径离场）'
        elif x.get('dead'): advice = '✅已到站：默认走；趋势健在则留并上移止损至锚价'
        else: advice = '持有中，等 ✅/🏁/⚠️'
        lines.append(f"   └ 评分{score} {lay}日 {tier} {notional}% {lev}x | "
                     f"止损{cd['stop']:.2f}(收盘确认,距锚{stop_dist:.1%}) | {advice}")
    if not rows:
        lines.append("（当前无在册信号）")
    lines.append(f"拦截统计: " + " ".join(f"{k}{v}" for k, v in skip_n.most_common()) if skip_n else "")
    text = "\n".join(lines) + "\n"
    text += ("\n⚠️ 以上为历史统计规则输出，非投资建议；仓位与杠杆自定，极端行情下任何止损价都可能被跳空击穿。\n"
             "⚠️ 模拟成交假设 T+1 开盘价、无滑点与流动性约束；展示口径（⚠️含观察期与收复）与模拟口径（确认即离场）不同，模拟仓更保守。\n")
    print(f"[replica] {now_day} 状态页生成: {len(hit)} 标的 / {len(rows)} 推荐 / {len(text.encode())//1024}KB")

    if tok:
        hdr = {"Authorization": f"Bearer {tok}"}
        hhmm = datetime.now(tz8).strftime('%m%d-%H%M')
        for fname in (f"status/daily-{hhmm}.txt", "status/view.html", "status/latest.txt", "status/live.txt"):
            try:
                g = requests.get(f"{GH_API}/{fname}", headers=hdr, timeout=15)
                data = {"message": f"replica status {now_day}", "content": base64.b64encode(text.encode()).decode()}
                if g.status_code == 200 and g.json().get("sha"): data["sha"] = g.json()["sha"]
                p = requests.put(f"{GH_API}/{fname}", headers=hdr, json=data, timeout=30)
                print(f"[replica] 上传 {fname}: {'OK' if p.status_code in (200, 201) else f'HTTP {p.status_code}'}")
            except Exception as e:
                print(f"[replica] 上传 {fname} 异常: {e}")
        time.sleep(15)   # ★ 上传完等 GitHub 提交传播，再 purge 防竞态钉死旧缓存（评审 #10）
        # ---- 缓存交付：四通道统一 purge + 新鲜度自检（SRE 方案 A，2026-10-11）----
        # 根因：jsDelivr 对高频更新的固定文件名，purge 可能被节点钉住/限流；
        # 对策：不再依赖单通道，四通道全刷，并回读校验，哪个通道旧一目了然。
        mirrors = ('cdn.jsdelivr.net', 'fastly.jsdelivr.net',
                   'gcore.jsdelivr.net', 'testingcf.jsdelivr.net')
        for host in mirrors:
            for fname in ('status/live.txt', 'status/latest.txt'):
                try:
                    requests.get(f"https://purge.jsdelivr.net/gh/Llng125256/kx-combo@main/{fname}", timeout=15)
                    requests.get(f"https://{host}/gh/Llng125256/kx-combo@main/{fname}", timeout=15)
                except Exception:
                    pass
        expect = f"v{__version__}"
        state = []
        for host in mirrors:
            try:
                r = requests.get(f"https://{host}/gh/Llng125256/kx-combo@main/status/live.txt", timeout=15)
                state.append(f"{host.split('.')[0]}={'新' if expect in r.text[:60] else '旧'}")
            except Exception:
                state.append(f"{host.split('.')[0]}=超时")
        print(f"[replica] 缓存校验: {' '.join(state)}（目标版本 {expect}）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
